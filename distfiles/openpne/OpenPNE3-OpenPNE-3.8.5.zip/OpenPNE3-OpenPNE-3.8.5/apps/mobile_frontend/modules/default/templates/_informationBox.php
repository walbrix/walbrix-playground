<?php
op_include_parts('informationBox', 'information', array('body' => $gadget->getRawValue()->getConfig('value')))
?>
