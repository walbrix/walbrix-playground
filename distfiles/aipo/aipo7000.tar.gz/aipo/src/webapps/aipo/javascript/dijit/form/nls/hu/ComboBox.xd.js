dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.hu.ComboBox"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.hu.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "hu", {"previousMessage": "Előző menüpontok", "nextMessage": "További menüpontok"});
}});