<li><?php echo link_to(__('アプリケーションプラグイン設定'), 'plugin/list') ?></li>
<li><?php echo link_to(__('認証プラグイン設定'), 'plugin/list?type=auth') ?></li>
<li><?php echo link_to(__('スキンプラグイン設定'), 'plugin/list?type=skin') ?></li>
