<?php
/**
 * ヘッダー
 */
?>

<div id="Header">
    <div id="Header-page">
        <?php $bcBaser->element('search') ?>
        <h1><?php $bcBaser->link($bcBaser->siteConfig['name'],'/') ?></h1>
    </div>
</div><!--Header-->