<?php

return array(
  'status' => 'success',
  'data' => $count->getRawValue(),
);
