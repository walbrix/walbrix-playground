dojo.provide("aipo.activity");
aipo.activity.setListSize=function(){if(dojo.isIE){dojo.query(".activityList li").forEach(function(A){A.style.width="394px"
})
}};