<div class="body">
<?php echo $options->getRaw('body') ?>
</div>
