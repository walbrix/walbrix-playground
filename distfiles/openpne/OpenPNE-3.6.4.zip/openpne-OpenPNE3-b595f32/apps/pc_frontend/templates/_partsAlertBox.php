<table>
<tr>
<th><?php echo op_image_tag('icon_alert.gif') ?></th>
<td><?php echo $options->getRaw('body') ?></td>
</tr>
</table>
