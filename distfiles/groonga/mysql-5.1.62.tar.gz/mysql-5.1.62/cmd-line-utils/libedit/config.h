#include "my_config.h"
#include "sys.h"
#ifndef NARROW_WRAPPER
#define WIDECHAR
#endif
