FactoryGirl.define do
  factory(:user_password_reset_nonce)
end
