<?php
/* SVN FILE: $Id$ */
/**
 * Twitterコントローラー
 *
 * PHP versions 4 and 5
 *
 * Baser :  Basic Creating Support Project <http://basercms.net>
 * Copyright 2008 - 2011, Catchup, Inc.
 *								18-1 nagao 1-chome, fukuoka-shi
 *								fukuoka, Japan 814-0123
 *
 * @copyright		Copyright 2008 - 2011, Catchup, Inc.
 * @link			http://basercms.net BaserCMS Project
 * @package			twitter.controllers
 * @since			Baser v 0.1.0
 * @version			$Revision$
 * @modifiedby		$LastChangedBy$
 * @lastmodified	$Date$
 * @license			http://basercms.net/license/index.html
 */
/**
 * Twitterコントローラー
 *
 * @package			twitter.controllers
 */
class TwitterController extends AppController {
/**
 * コントローラー名
 * @var		string
 * @access	public
 */
	var $name = 'Twitter';
/**
 * コンポーネント
 * @var		array
 * @access	public
 */
	var $components = array('RequestHandler');
/**
 * [AJAX] Twitterのステータスを更新する（ツイート）
 * @return	mixid	TwitterユーザープロフィールへのURL / false
 * @access	public
 */
	function admin_update(){

		if(!$this->data){
			$this->notFound();
		}else{
			
			$result = false;
			if(!empty($this->data['Twitter']['status'])){
				if($this->Twitter->setupTwitterBehavior()){
					$result = $this->Twitter->update($this->data['Twitter']['status']);
					
					if($result){
						$result = json_decode($result);
						if(isset($result->user->screen_name)) {
							$result = 'http://twitter.com/'.$result->user->screen_name;
						} else {
							$result = false;
						}
					}
				}
			}
			$this->set('result',$result);
		}
		Configure::write('debug', 0);
		$this->render('ajax_result');
		
	}
/**
 * [AJAX] URLを短いURLに変換する（tinyurl）
 * @return	mixed	変換後のURL / false
 * @access	public
 */
	function admin_tinyurl(){
		if(!$this->data){
			$this->notFound();
		}else{
			$url = $this->_convertTinyurl($this->data['Twitter']['url']);
			if($url){
				$this->set('result', $url);
			}else{
				$this->set('result', false);
			}
		}
		$this->render('ajax_result');
	}
/**
 * TinyUrlのWebサービスを利用して短いURLに変換する
 * TinyUrlのサイトに接続できなかった場合は変換せずに返却
 * @param	string	$url
 * @return	string	成功した場合は変換後のURL / 失敗した場合は元のURL
 * @access	public
 */
	function _convertTinyurl($url){
		$requestUrl = 'http://tinyurl.com/api-create.php?url='.$url;
		App::import('Core','HttpSocket');
		$sock = new HttpSocket();
		$tinyurl = $sock->get($requestUrl);
		if($tinyurl) {
			return $tinyurl;
		} else {
			return $url;
		}
	}

}
?>