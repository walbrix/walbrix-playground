dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.it.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.it.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "it", {"iframeTitle1": "modifica area", "iframeTitle2": "modifica frame area"});
}});