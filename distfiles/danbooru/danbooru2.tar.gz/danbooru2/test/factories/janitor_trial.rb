FactoryGirl.define do
  factory(:janitor_trial) do
    user
  end
end
