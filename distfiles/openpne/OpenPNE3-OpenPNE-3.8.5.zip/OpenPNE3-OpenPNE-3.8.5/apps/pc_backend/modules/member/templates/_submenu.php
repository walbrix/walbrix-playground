<li><?php echo link_to(__('Members'), 'member/list') ?></li>
<li><?php echo link_to(__('Invite Members'), 'member/invite') ?></li>
<li><?php echo link_to(__('Blacklist Management'), 'member/blacklist') ?></li>
