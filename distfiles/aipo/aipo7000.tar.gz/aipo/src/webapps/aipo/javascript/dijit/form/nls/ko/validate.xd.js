dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.ko.validate"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.ko.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "ko", {"rangeMessage": "* 이 값은 범위를 벗어납니다. ", "invalidMessage": "* 입력한 값이 유효하지 않습니다. ", "missingMessage": "* 이 값은 필수입니다. "});
}});