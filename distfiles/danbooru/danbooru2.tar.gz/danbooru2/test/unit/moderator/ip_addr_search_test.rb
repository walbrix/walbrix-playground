require "test_helper"

module Moderator
  class IpAddrSearchTest < ActiveSupport::TestCase
    context "an ip addr search" do
      setup do
        @user = FactoryGirl.create(:user)
        CurrentUser.user = @user
        CurrentUser.ip_addr = "127.0.0.1"
        Danbooru.config.stubs(:member_comment_time_threshold).returns(1.week.from_now)
        FactoryGirl.create(:comment)
        MEMCACHE.flush_all
      end
  
      teardown do
        CurrentUser.user = nil
        CurrentUser.ip_addr = nil
      end
    
      should "find by ip addr" do
        @search = IpAddrSearch.new(:ip_addr_eq => "127.0.0.1")
        assert_equal({@user.id.to_s => 2}, @search.execute)
      end
      
      should "find by user id" do
        @search = IpAddrSearch.new(:user_id_eq => @user.id.to_s)
        assert_equal({"127.0.0.1" => 2}, @search.execute)
      end

      should "find by user name" do
        @search = IpAddrSearch.new(:user_name_eq => @user.name)
        assert_equal({"127.0.0.1" => 2}, @search.execute)
      end
    end
  end
end
