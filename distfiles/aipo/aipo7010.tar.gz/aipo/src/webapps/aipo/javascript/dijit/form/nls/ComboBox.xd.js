dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.ComboBox"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "", {"previousMessage": "Previous choices", "nextMessage": "More choices"});
}});