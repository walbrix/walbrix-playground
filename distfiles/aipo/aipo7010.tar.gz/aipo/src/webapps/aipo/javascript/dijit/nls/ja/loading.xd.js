dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.ja.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.ja.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "ja", {"loadingState": "ロード中...", "errorState": "エラーが発生しました。"});
}});