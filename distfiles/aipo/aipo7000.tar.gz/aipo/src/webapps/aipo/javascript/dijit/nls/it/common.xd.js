dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.it.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.it.common");dojo._xdLoadFlattenedBundle("dijit", "common", "it", {"buttonCancel": "Annulla", "buttonSave": "Salva", "buttonOk": "OK"});
}});