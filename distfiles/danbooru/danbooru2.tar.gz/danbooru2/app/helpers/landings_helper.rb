module LandingsHelper
end
