dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.pl.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.pl.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "pl", {"loadingState": "Trwa ładowanie...", "errorState": "Niestety, wystąpił błąd"});
}});