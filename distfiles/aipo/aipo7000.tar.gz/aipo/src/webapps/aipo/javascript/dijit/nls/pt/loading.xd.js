dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.pt.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.pt.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "pt", {"loadingState": "Carregando...", "errorState": "Ocorreu um erro"});
}});