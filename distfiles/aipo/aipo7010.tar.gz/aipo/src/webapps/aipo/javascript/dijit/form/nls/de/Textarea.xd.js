dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.de.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.de.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "de", {"iframeTitle1": "Editierbereich", "iframeTitle2": "Rahmen für Editierbereich"});
}});