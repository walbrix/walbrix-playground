<?php echo op_include_form('passowrdResetForm', $form, array(
  'title' => __('Password Recovery'),
  'body' => __('Please input your new password.'),
)) ?>
