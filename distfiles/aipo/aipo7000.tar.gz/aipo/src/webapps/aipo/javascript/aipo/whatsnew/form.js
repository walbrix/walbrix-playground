dojo.provide("aipo.whatsnew");
aipo.whatsnew.onLoadWhatsnewDialog=function(A){var B=dojo.byId("whatsnew_name");
if(B){B.focus()
}aipo.portletReload("whatsnew")
};