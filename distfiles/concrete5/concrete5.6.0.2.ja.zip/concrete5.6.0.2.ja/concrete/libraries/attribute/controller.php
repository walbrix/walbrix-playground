<?php	
defined('C5_EXECUTE') or die("Access Denied.");

class AttributeTypeController extends Concrete5_Library_AttributeTypeController {}