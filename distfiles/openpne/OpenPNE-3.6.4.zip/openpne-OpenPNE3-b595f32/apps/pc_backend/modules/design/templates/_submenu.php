<li><?php echo link_to(__('ホーム画面レイアウト設定'), 'design/layout') ?></li>
<li><?php echo link_to(__('ガジェット設定'), 'design/gadget') ?></li>
<li><?php echo link_to(__('HTML挿入'), 'design/html') ?></li>
<li><?php echo link_to(__('バナー設定'), 'design/banner') ?></li>
<li><?php echo link_to(__('カスタム CSS 設定'), 'design/customCss') ?></li>
<li><?php echo link_to(__('携帯版配色設定'), 'design/mobileColorConfig') ?></li>
