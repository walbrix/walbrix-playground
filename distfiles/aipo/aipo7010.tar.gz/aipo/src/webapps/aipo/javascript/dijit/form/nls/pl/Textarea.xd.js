dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.pl.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.pl.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "pl", {"iframeTitle1": "edycja obszaru", "iframeTitle2": "edycja ramki obszaru"});
}});