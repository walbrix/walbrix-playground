dojo.provide("aipo.deletesample");
aipo.deletesample.onLoadDeleteSampleDialog=function(A){};