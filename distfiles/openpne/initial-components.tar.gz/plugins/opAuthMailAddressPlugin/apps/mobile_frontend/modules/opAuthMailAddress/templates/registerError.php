<?php echo __('Can access this registration URL with pc only.') ?>
