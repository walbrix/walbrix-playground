<?php echo nl2br($op_config['privacy_policy']) ?>
