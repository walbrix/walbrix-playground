module ForumPostsHelper
end
