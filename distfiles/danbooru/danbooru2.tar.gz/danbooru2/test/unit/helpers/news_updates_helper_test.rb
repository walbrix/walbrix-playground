require 'test_helper'

class NewsUpdatesHelperTest < ActionView::TestCase
end
