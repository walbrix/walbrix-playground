dojo.require("aipo.widget.MemberNormalSelectList");
dojo.provide("aipo.msgboard");
aipo.msgboard.onLoadMsgboardDetail=function(A){aipo.portletReload("whatsnew")
};
aipo.msgboard.onLoadMsgboardDialog=function(A){var B=dojo.byId("topic_name");
if(B){B.focus()
}};
aipo.msgboard.onChangeFilter=aipo.msgboard.onChangeSearch=function(A,C){var B=encodeURIComponent(dojo.byId("q").value);
A+="?template=MsgboardTopicListScreen";
A+="&filter="+dojo.byId("topic").value;
A+="&filtertype=category";
A+="&search="+B;
aipo.viewPage(A,C)
};
aipo.msgboard.onLoadCategoryDialog=function(E){var F=dojo.byId("category_name");
if(F){F.focus()
}var C=dijit.byId("membernormalselect");
if(C){var A=dojo.byId("init_memberlist");
var D;
var B=A.options;
if(B.length==1&&B[0].value==""){return 
}for(D=0;
D<B.length;
D++){C.addOptionSync(B[D].value,B[D].text,true)
}}};
aipo.msgboard.showMember=function(A){dojo.byId("Block-GroupMember-Show").style.display="";
dojo.byId("is_member").value="TRUE"
};
aipo.msgboard.hideMember=function(A){dojo.byId("Block-GroupMember-Show").style.display="none";
dojo.byId("member_to").options.length=0;
dojo.byId("is_member").value="FALSE"
};
aipo.msgboard.expandImageWidth=function(A){var B=A.className;
if(!B.match(/width_auto/i)){A.className=A.className.replace(/\bwidth_thumbs\b/g,"width_auto")
}else{A.className=A.className.replace(/\bwidth_auto\b/g,"width_thumbs")
}};
aipo.msgboard.formSwitchCategoryInput=function(A){if(A.form.is_new_category.value=="TRUE"||A.form.is_new_category.value=="true"){A.value=aimluck.io.escapeText("msgboard_val_switch1");
aipo.msgboard.formCategoryInputOff(A.form)
}else{A.value=aimluck.io.escapeText("msgboard_val_switch2");
aipo.msgboard.formCategoryInputOn(A.form)
}};
aipo.msgboard.formCategoryInputOn=function(A){dojo.byId("msgboardCategorySelectField").style.display="none";
dojo.byId("msgboardCategoryInputField").style.display="";
A.is_new_category.value="TRUE"
};
aipo.msgboard.formCategoryInputOff=function(A){dojo.byId("msgboardCategoryInputField").style.display="none";
dojo.byId("msgboardCategorySelectField").style.display="";
A.is_new_category.value="FALSE"
};
aipo.msgboard.onReceiveMessage=function(C){var A=dojo.byId("attachments_select");
if(typeof A!="undefined"&&A!=null){A.parentNode.removeChild(A)
}if(!C){var B=dijit.byId("modalDialog");
if(B){B.hide()
}aipo.portletReload("msgboard");
aipo.portletReload("timeline")
}if(dojo.byId("messageDiv")){dojo.byId("messageDiv").innerHTML=C
}};
aipo.msgboard.onListReceiveMessage=function(B){if(!B){var A=dijit.byId("modalDialog");
if(A){A.hide()
}aipo.portletReload("msgboard")
}if(dojo.byId("listmessageDiv")){dojo.byId("listmessageDiv").innerHTML=B
}};
aipo.msgboard.ajaxCheckboxDeleteSubmit=function(B,A,C,D,E){aimluck.io.ajaxVerifyCheckbox(B.form,aipo.msgboard.ajaxMultiDeleteSubmit,B,A,C,D,E)
};
aipo.msgboard.ajaxMultiDeleteSubmit=function(B,A,C,D,E){if(confirm("選択した"+B.form._name.value+"を削除してよろしいですか？なお、カテゴリに含まれるトピックはすべて削除されます。")){aimluck.io.disableForm(B.form,true);
aimluck.io.setHiddenValue(B);
B.form.action=A;
aimluck.io.submit(B.form,C,D,E)
}};
aipo.msgboard.ajaxDeleteSubmit=function(B,A,C,D,E){if(confirm("この"+B.form._name.value+"を削除してよろしいですか？なお、カテゴリに含まれるトピックはすべて削除されます。")){aimluck.io.disableForm(B.form,true);
aimluck.io.setHiddenValue(B);
B.form.action=A;
aimluck.io.submit(B.form,C,D,E)
}};