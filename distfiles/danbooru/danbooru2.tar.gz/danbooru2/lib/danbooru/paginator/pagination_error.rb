module Danbooru
  module Paginator
    class PaginationError < Exception
    end
  end
end
