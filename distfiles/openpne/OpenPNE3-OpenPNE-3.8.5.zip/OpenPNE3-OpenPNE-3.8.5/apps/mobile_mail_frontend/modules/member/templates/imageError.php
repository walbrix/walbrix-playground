<?php $sf_context->getResponse()->setTitle(sprintf('[%s]', $op_config['sns_name']).__('Some errors occurred while processing your mail')); ?>
<?php echo __('Cannot add an image any more.'); ?>
