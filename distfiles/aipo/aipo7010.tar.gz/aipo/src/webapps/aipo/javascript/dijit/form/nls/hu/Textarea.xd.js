dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.hu.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.hu.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "hu", {"iframeTitle1": "szerkesztési terület", "iframeTitle2": "szerkesztési terület keret"});
}});