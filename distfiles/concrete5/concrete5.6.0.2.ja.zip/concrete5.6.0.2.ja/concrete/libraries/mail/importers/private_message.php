<?php	

defined('C5_EXECUTE') or die("Access Denied.");

class PrivateMessageMailImporter extends Concrete5_Library_PrivateMessageMailImporter {}