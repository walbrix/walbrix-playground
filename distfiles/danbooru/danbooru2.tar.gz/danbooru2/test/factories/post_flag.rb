FactoryGirl.define do
  factory(:post_flag) do
    reason "xxx"
    is_resolved false
  end
end