if(!dojo._hasResource["dijit.themes.soria"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dijit.themes.soria"] = true;
dojo.provide("dijit.themes.soria");
/* theoritical implementation */

// dojo.requireCss(dojo.moduleUrl("dijit.themes.soria","soria.css");
// if (dojo.isRTL) { 
//	dojo.requireCss(dojo.moduleUrl("dijit.theme.soria","soria_rtl.css"));
// }
// if(dojo.isIE<7){ 
//	dojo.requireCss(dojo.moduleUrl("dijit.themes.soria","soria_ie6.css")); 
//	var imgList = ["images/arrows.png","images/gradientTopBg"]; // png's w/ alpha
//	// we'll take a hit performance wise with ie6, but such is life, right? and
//	// it allows us to take dj_ie6 classes out of the root css for performance 
//	// enhancement on sane/good browsers.
// 	dojo.addOnLoad(function(){
//		dojo.forEach(imgList,function(img){
//			filter(img);
//		});
// 	}
// }

}
