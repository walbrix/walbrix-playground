<h2>Installation is locked</h2>

please create file "install.me" in folder /files/temp in order to install ClipBucket