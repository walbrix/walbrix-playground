<?php
/* SVN FILE: $Id$ */
/**
 * [PUBLISH] ブログ最近の投稿
 * 
 * PHP versions 5
 *
 * baserCMS :  Based Website Development Project <http://basercms.net>
 * Copyright 2008 - 2012, baserCMS Users Community <http://sites.google.com/site/baserusers/>
 *
 * @copyright		Copyright 2008 - 2012, baserCMS Users Community
 * @link			http://basercms.net baserCMS Project
 * @package			baser.plugins.blog.views
 * @since			baserCMS v 0.1.0
 * @version			$Revision$
 * @modifiedby		$LastChangedBy$
 * @lastmodified	$Date$
 * @license			http://basercms.net/license/index.html
 */
include BASER_PLUGINS.'blog'.DS.'views'.DS.'elements'.DS.'widgets'.DS.'blog_recent_entries'.$this->ext;
?>