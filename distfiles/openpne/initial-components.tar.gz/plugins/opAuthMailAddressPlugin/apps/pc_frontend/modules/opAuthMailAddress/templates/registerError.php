<?php
$options = array(
  'title' => __('Errors'),
);
op_include_box('registerError', __('Can access this registration URL with mobile only.'), $options);
?>
