<?php
	define('VERSION', "1.7.4");
?>
