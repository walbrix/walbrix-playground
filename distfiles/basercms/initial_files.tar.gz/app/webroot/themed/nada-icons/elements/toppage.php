<?php
/**
 * toppage
 */
?>
		<?php $bcBaser->flash() ?>
        <div id="top-contents" >
            <div id="top-contents-main">
                <?php $bcBaser->content() ?>
            </div>
        </div>
        <div id="top-contents" >
            <div id="top-contents-main">
                <div id="top-bnr">
                    <div id="top-bnr-left">
                        <?php $bcBaser->img('./icons_banner_l_01.png', array('url' => '/#')); ?>
                        <p>紹介文が入ります紹介文が入ります紹介文が入ります紹介文が入ります紹介文が入ります紹介文が入ります紹介文が入ります</p>
                    </div>
                    <div id="top-bnr-right">
                        <?php $bcBaser->img('./icons_banner_l_02.png', array('url' => '/#')); ?>
                        <p>紹介文が入ります紹介文が入ります紹介文が入ります紹介文が入ります紹介文が入ります紹介文が入ります紹介文が入ります</p>
                    </div>
                </div>
            </div>

        </div><!-- top-contents -->