dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.hu.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.hu.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "hu", {"loadingState": "Betöltés...", "errorState": "Sajnálom, hiba történt"});
}});