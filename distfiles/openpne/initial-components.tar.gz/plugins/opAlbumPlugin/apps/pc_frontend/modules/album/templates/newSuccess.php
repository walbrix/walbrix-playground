<?php decorate_with('layoutC') ?>

<?php include_partial('form', array('form' => $form)) ?>
