dojo._xdResourceLoaded({depends:[["provide","aipo.calendar.weekly"],["require","aimluck.dnd.Draggable"],["require","aipo.widget.ToolTip"],["require","aipo.widget.MemberNormalSelectList"],["require","aipo.widget.GroupNormalSelectList"]],defineResource:function(B){if(!B._hasResource["aipo.calendar.weekly"]){B._hasResource["aipo.calendar.weekly"]=true;
B.provide("aipo.calendar.weekly");
B.require("aimluck.dnd.Draggable");
B.require("aipo.widget.ToolTip");
B.require("aipo.widget.MemberNormalSelectList");
B.require("aipo.widget.GroupNormalSelectList");
aipo.calendar.objectlist=Array();
aipo.calendar.maximum_to=30;
function A(F,E){return F.className.match(new RegExp("(\\s|^)"+E+"(\\s|$)"))
}function C(F,E){if(!this.hasClass(F,E)){F.className+=" "+E
}}function D(G,E){if(A(G,E)){var F=new RegExp("(\\s|^)"+E+"(\\s|$)");
G.className=G.className.replace(F," ")
}}aipo.calendar.changeDisypayPeriod=function(N,K){var G=B.byId("weeklyHeadRights-"+K).children;
var I=B.byId("weeklyTermRights-"+K).children;
var L=B.byId("weeklyRights-"+K).children;
B.byId("view_type_"+K).value=N;
var M=B.byId("indicateDate_"+K);
if(M==null){return 
}for(var J=0;
J<7;
J++){var F=G[J];
var H=L[J];
var E=I[J];
var O=B.byId("scheduleDivAdd0"+J+"_"+K);
switch(N){case"1":M.innerHTML="<span>1日</span>";
H.className="weeklyRight";
if(J==0){F.className="weeklyHeadRightR";
F.style.width="100%";
H.style.width="100%";
E.style.width="100%";
C(E,"weeklyTermRightR");
O.style.width="100%"
}else{F.className="weeklyHeadRight";
F.style.width="0%";
F.style.display="none";
H.style.width="0%";
H.style.display="none";
E.style.width="0%";
E.style.display="none";
D(E,"weeklyTermRightR");
O.style.width="0%";
O.style.display="none"
}break;
case"4":M.innerHTML="<span>4日</span>";
if(J==0){D(E,"weeklyTermRightR")
}if(J<=3){F.style.width="25%";
F.style.left=J*25+"%";
F.style.display="";
H.style.width="25%";
H.style.left=J*25+"%";
H.style.display="";
E.style.width="25%";
E.style.left=J*25+"%";
E.style.display="";
O.style.width="25%";
O.style.left=J*25+"%";
O.style.display="";
if(J<3){F.className="weeklyHeadRight"
}else{if(J==3){F.className="weeklyHeadRightR";
H.className="weeklyRightR";
C(E,"weeklyTermRightR")
}}}else{F.className="weeklyHeadRight";
F.style.width="0%";
F.style.display="none";
H.style.width="0%";
H.style.display="none";
E.style.width="0%";
E.style.display="none";
D(E,"weeklyTermRightR");
O.style.width="0%";
O.style.display="none"
}break;
case"7":M.innerHTML="<span>7日</span>";
F.style.left=J*(100/7)+"%";
F.style.display="";
F.style.width="14.2857%";
H.style.left=J*(100/7)+"%";
H.style.display="";
H.style.width="14.2857%";
E.style.left=J*(100/7)+"%";
E.style.display="";
E.style.width="14.2857%";
O.style.left=J*(100/7)+"%";
O.style.display="";
O.style.width="14.2857%";
if(J==0){D(E,"weeklyTermRightR")
}if(J<6){F.className="weeklyHeadRight";
H.className="weeklyRight";
D(E,"weeklyTermRightR")
}else{F.className="weeklyHeadRightR";
H.className="weeklyRightR";
C(E,"weeklyTermRightR")
}}}};
aipo.calendar.populateWeeklySchedule=function(I,J){var G;
var H=B.byId("member_to-"+I);
if(typeof J=="undefined"||typeof ptConfig[I].jsonData=="undefined"){G=""
}else{G=J
}var F=B.byId("secid-"+I);
if(F){G+="&secid="+F.value
}if(G.match(/ign_dup_f/)==null){if(H){var K=H.options;
to_size=K.length;
if(to_size==0){G+="&m_id="+aipo.schedule.login_id
}for(i=0;
i<to_size;
i++){K[i].selected=true;
G+="&m_id="+K[i].value
}}var E=B.byId("showAll-"+I);
if(E){G+="&s_all="+E.value
}}djConfig.usePlainJson=true;
ptConfig[I].reloadFunction=aipo.calendar.populateWeeklySchedule;
ptConfig[I].isTooltipEnable=false;
if(aipo.calendar.dummyDivObj){aipo.calendar.dummyDivObj.destroy();
aipo.calendar.dummyDivObj=null
}if(B.byId("groupselect-"+I).value=="pickup"){G+="&pickup=true"
}B.xhrGet({portletId:I,url:ptConfig[I].jsonUrl+G,encoding:"utf-8",handleAs:"json-comment-filtered",load:function(m,c){if(aipo.calendar.reloadMonthlyCalendar!=null){aipo.calendar.reloadMonthlyCalendar()
}obj_error=B.byId("error-"+I);
B.style(obj_error,"display","none");
if("PermissionError"==m[0]){B.style(obj_error,"display","block");
obj_error.innerHTML=m[1];
obj_content=B.byId("content-"+I);
B.style(obj_content,"display","none");
obj_indicator=B.byId("indicator-"+I);
B.style(obj_indicator,"display","none");
return 
}else{if(m.errList){if("duplicate_facility"==m.errList[0]){if(confirm("既に同じ時間帯に設備が予約されています。スケジュールを登録しますか？")){var M=G+"&ign_dup_f=true";
aipo.calendar.populateWeeklySchedule(I,M);
aipo.portletReload("schedule",I);
return 
}}if("UpdateError"==m.errList[0]){B.style(obj_error,"display","block");
obj_error.innerHTML='<ul><li><span class="caution">'+m.errList[1]+"</span></li></ul>";
obj_content=B.byId("content-"+I);
B.style(obj_content,"visibility","visible");
obj_indicator=B.byId("indicator-"+I);
B.style(obj_indicator,"display","none")
}}}var d;
if(!!aipo.calendar.objectlist){var e=aipo.calendar.objectlist.length;
for(d=0;
d<e;
d++){var Y=aipo.calendar.objectlist[d];
if(Y.portletId==I){Y.destroy()
}}}if(!aipo.errorTreatment(m,ptConfig[I].thisUrl)){return 
}ptConfig[I].jsonData=m;
var h=Array(ptConfig[I].scheduleDivDaySum);
for(var d=0;
d<ptConfig[I].scheduleDivDaySum;
d++){h[d]=Array()
}var P=0;
var l=0;
var V="";
var Q="";
var a="";
var X=[];
var W,U,T,S;
var f=m.startDate.substring(0,4)+"年"+parseInt(m.startDate.substring(5,7),10)+"月"+parseInt(m.startDate.substring(8,10),10)+"日"+m.dayOfWeek[0];
B.byId("viewWeekly-"+I).innerHTML=f;
var L="";
var b="";
if(B.byId("top_form_"+I).value=="simple"&&B.byId("view_type_"+this.portletId).value=="1"){L="width: 100%;";
b="width: 0%;display: none;"
}a+='<table cellspacing="0" cellpadding="0" border="0" width="100%"><tbody>';
var Z=B.byId("weeklyScrollPane_"+this.portletId);
if(Z.clientWidth==Z.offsetWidth){B.byId("weeklySpan-"+I).style.display="none";
if(B.byId("isMac").value!=0){B.byId("weeklyHeadRightborder-"+I).style.borderRight="none";
B.byId("termDay0-"+I).style.borderRight="none"
}}B.forEach(m.termSchedule,function(n){var o="";
var s="";
if(B.byId("top_form_"+I).value=="simple"&&B.byId("view_type_"+I).value=="1"||B.byId("top_form_"+I).value=="simple"&&B.byId("view_type_"+I).value=="4"){o=' style="display: none;"';
for(k=0;
k<n.length;
k++){q=n[k];
if(q.index==0||(B.byId("top_form_"+I).value=="simple"&&B.byId("view_type_"+I).value=="4"&&q.index<4)){o="";
s=" weeklyTermRightR";
break
}}}if(Z.clientWidth==Z.offsetWidth){s=" weeklyTermRightRnone";
if(B.byId("isMac").value!=0){B.byId("weeklyHeadRightborder-"+I).style.borderRight="none";
B.byId("termDay0-"+I).style.borderRight="none"
}}var q=null;
var p=(scheduleTooltipEnable!==true&&B.byId("top_form_"+I).value=="simple"&&B.byId("view_type_"+I).value=="1")?"border-right:0":"";
if(scheduleTooltipEnable!==true&&B.byId("top_form_"+I).value=="simple"&&B.byId("view_type_"+I).value=="1"){a+="<tr"+o+'><td width="50"><div class="weeklyTermLeft" id="weeklyTermLeft"><div class="weeklyTermLeftTop">&nbsp;</div></div></td><td  colspan="2" nowrap="nowrap" width="100%" valign="top"><div class="weeklyTermRights">'
}else{a+="<tr"+o+'><td width="50"><div class="weeklyTermLeft" id="weeklyTermLeft"><div class="weeklyTermLeftTop">&nbsp;</div></div></td><td nowrap="nowrap" width="100%" valign="top"><div class="weeklyTermRights">'
}if(B.byId("top_form_"+I).value=="simple"&&B.byId("view_type_"+I).value=="4"){a+='<div class="weeklyTermRight weeklyTermRightL'+s+'" id="termDay0-'+l+"-"+I+'" style="width: 25%;left: 0%;'+L+p+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight" id="termDay1-'+l+"-"+I+'" style="width: 25%;left: 25%;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight" id="termDay2-'+l+"-"+I+'" style="width: 25%;left: 50%;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight weeklyTermRightR" id="termDay3-'+l+"-"+I+'" style="width: 25%;left: 75%;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight" id="termDay4-'+l+"-"+I+'" style="left: 57.1429%;display:none;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight" id="termDay5-'+l+"-"+I+'" style="left: 71.4286%;display:none;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight weeklyTermRightR" id="termDay6-'+l+"-"+I+'" style="left: 85.7143%;display:none;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div id="termScheduleItemGarage-'+l+"-"+I+'" class="termScheduleGarage"> </div>'
}else{a+='<div class="weeklyTermRight weeklyTermRightL'+s+'" id="termDay0-'+l+"-"+I+'" style="left: 0%;'+L+p+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight" id="termDay1-'+l+"-"+I+'" style="left: 14.2857%;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight" id="termDay2-'+l+"-"+I+'" style="left: 28.5714%;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight" id="termDay3-'+l+"-"+I+'" style="left: 42.8571%;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight" id="termDay4-'+l+"-"+I+'" style="left: 57.1429%;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight" id="termDay5-'+l+"-"+I+'" style="left: 71.4286%;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div class="weeklyTermRight weeklyTermRightR" id="termDay6-'+l+"-"+I+'" style="left: 85.7143%;'+b+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
a+='<div id="termScheduleItemGarage-'+l+"-"+I+'" class="termScheduleGarage"> </div>'
}var r;
if(scheduleTooltipEnable!==true&&B.byId("top_form_"+I).value=="simple"&&B.byId("view_type_"+I).value=="1"||Z.clientWidth==Z.offsetWidth){r="</div></td></tr>"
}else{r='</div></td><td width="18"><div class="weeklyTermTail">&nbsp;</div></td></tr>'
}if(window.navigator.userAgent.toLowerCase().indexOf("ipad")!==-1&&B.byId("top_form_"+I).value!=="simple"&&B.byId("view_type_"+I).value=="1"){r='</div></td><td width="18"><div class="weeklyTermTail">&nbsp;</div></td></tr>'
}a+=r;
l++
});
a+="</tbody></table>";
B.byId("termScheduleGarage-"+I).innerHTML=a;
B.byId("termScheduleDivAdd_"+I).style.height=(18*(l+1))+"px";
for(var d=0;
d<ptConfig[I].scheduleDivDaySum;
d++){W=B.byId("weeklyDay"+d+"-"+I);
U=B.byId("weeklyHoliday"+d+"-"+I);
T=B.byId("weeklyRight"+d+"-"+I);
S=B.byId("termDay"+d+"-"+I);
W.innerHTML=parseInt(m.date[d].substring(8,10),10)+m.dayOfWeek[d];
U.innerHTML=m.holiday[d];
if(m.dayOfWeek[d]=="（土）"){B.addClass(W,"saturday");
B.addClass(U,"saturday");
B.addClass(T,"saturday");
B.addClass(S,"saturday")
}else{B.removeClass(W,"saturday");
B.removeClass(U,"saturday");
B.removeClass(T,"saturday");
B.removeClass(S,"saturday")
}if(m.dayOfWeek[d]=="（日）"){B.addClass(W,"sunday");
B.addClass(U,"sunday");
B.addClass(T,"sunday");
B.addClass(S,"sunday")
}else{B.removeClass(W,"sunday");
B.removeClass(U,"sunday");
B.removeClass(T,"sunday");
B.removeClass(S,"sunday")
}if(m.holiday[d]){B.addClass(W,"holiday");
B.addClass(U,"holiday");
B.addClass(T,"holiday");
B.addClass(S,"holiday")
}else{B.removeClass(W,"holiday");
B.removeClass(U,"holiday");
B.removeClass(T,"holiday");
B.removeClass(S,"holiday")
}}B.forEach(m.schedule,function(AD){var n=ptConfig[I].rowHeight;
var z=AD.startDateHour*n*2+AD.startDateMinute*n/30;
var AC=AD.endDateHour*n*2+AD.endDateMinute*n/30-z;
if(AC<=n){X[P]=AC;
AC=n
}else{X[P]=-1
}var s=100/ptConfig[I].scheduleDivDaySum*AD.index;
var q=100/ptConfig[I].scheduleDivDaySum*0.99;
var o=AD.name;
var r=X[P]==-1?((AD.startDateHour>9)?AD.startDate:"0"+AD.startDate):AD.name;
var x=X[P]==-1?((AD.endDateHour>9)?AD.endDate:"0"+AD.endDate):"";
var w=X[P]==-1?"-":"";
var y=AD.scheduleId;
var AA="0";
var t="";
var p=B.byId("member_to-"+I);
if(p){var u=p.options;
for(d=0;
d<u.length;
d++){if(((AD.type=="U")&&(AD.ownerId==u[d].value))||((AD.type=="F")&&(AD.ownerId==u[d].value))){AA=d%aipo.calendar.maximum_to
}if(AD.memberList){var v=0;
var AB=0;
for(j=0;
j<AD.memberList.length;
j++){if(AD.memberList[j].charAt(0)=="f"){AB++
}else{v++
}}}}var t;
if(AD.userCount>1){t="[共有]"
}if(AD.facilityCount>0){t+="[設備]"
}}if(!AD["public"]){o+='<img src="images/schedule/schedule_secret.gif" border="0" width="16" height="16" alt="非公開" title="非公開" align="top" class="icon" />'
}if(AD.duplicate){o+='<img src="images/schedule/schedule_duplicate.gif" border="0" width="16" height="16" alt="重複スケジュール" title="重複スケジュール" align="top" class="icon" />'
}if(AD.repeat){o+='<img src="images/schedule/schedule_repeat.gif" border="0" width="16" height="16" alt="繰り返し" title="繰り返し" align="top" class="icon" />'
}if(AD.tmpreserve){o+='<img src="images/schedule/schedule_tmpreserve.gif" border="0" width="16" height="16" alt="仮スケジュール" title="仮スケジュール" align="top" class="icon" />'
}V+='<div id="schedule-'+P+"-"+I+'" class="scheduleDiv color'+AA+'" style="top: '+z+"px; left: "+s+"%; height: "+(AC-1)+"px; width: "+q+'%; z-index: 0; visibility: hidden;"><div class="scheduleDivFirstLine color'+AA+'"><span id="scheduleDivStartTime-'+P+"-"+I+'" class="scheduleDivTime color'+AA+'">'+t+r+'</span><span id="scheduleDivSepalater-'+P+"-"+I+'"  class="scheduleDivSepalater color'+AA+'">'+w+'</span><span id="scheduleDivEndTime-'+P+"-"+I+'" class="scheduleDivTime color'+AA+'">'+x+'</span></div><div class="scheduleDivName color'+AA+'">'+o+'</div><div class="scheduleDivLastLine color'+AA+'"><center><div class="handleDiv color'+AA+'" align="center">&nbsp;</div></center></div></div>';
P++
});
V+='<div id="dummy_div_'+I+'" class="scheduleDivAdd dummy_div" style=" position:absolute; width: 0px; height : 0px; left: 0px; top: -10000px; Filter: Alpha(Opacity=10);opacity:.10; background-color:#FFFFFF; ">&nbsp;</div>';
B.byId("scheduleGarage-"+I).innerHTML=V;
var g=null;
var O,N;
var R=[];
P=0;
B.forEach(m.schedule,function(o){O=B.byId("schedule-"+P+"-"+I);
var n=o.scheduleId;
g=new aipo.calendar.WeeklyScheduleDraggable(O,{pid:I,sid:'"schedule-'+P+"-"+I+'"',handle:'"dummy_div_-'+I+'"'});
aipo.calendar.objectlist.push(g);
if(o.member||o.loginuser||o.owner||o["public"]){g.setDraggable(true)
}else{g.setDraggable(false)
}g.schedule=o;
g.tmpIndex=o.index;
g.count=P;
g.tmpHeight=X[P];
g.position=0;
g.division=1;
g.portletId=I;
h[o.index].push(O);
if(o["public"]||o.member){B.connect(O,"onclick",g,"onScheduleClick")
}B.connect(O,"onmouseover",g,"onScheduleOver");
P++
});
for(var d=0;
d<ptConfig[I].scheduleDivDaySum;
d++){aipo.calendar.relocation(I,h[d].length,h[d],100/ptConfig[I].scheduleDivDaySum*d);
h[d]=Array()
}P=0;
l=0;
B.forEach(m.termSchedule,function(w){var AB=null;
Q="";
for(var v=0;
v<ptConfig[I].scheduleDivDaySum;
v++){tmpNode5=B.byId("termDay"+v+"-"+l+"-"+I);
if(m.dayOfWeek[v]=="（土）"){B.addClass(tmpNode5,"saturday")
}else{B.removeClass(tmpNode5,"saturday")
}if(m.dayOfWeek[v]=="（日）"){B.addClass(tmpNode5,"sunday")
}else{B.removeClass(tmpNode5,"sunday")
}if(m.holiday[v]){B.addClass(tmpNode5,"holiday")
}else{B.removeClass(tmpNode5,"holiday")
}}for(k=0;
k<w.length;
k++){AB=w[k];
if(B.byId("top_form_"+I).value=="simple"&&B.byId("view_type_"+I).value=="4"){var y=AB.rowspan;
if(AB.rowspan+AB.index>4){y=y-(AB.rowspan+AB.index-4)
}var p=25*y;
var r=25*AB.index;
if(AB.index>4){p=0
}}else{var p=100/ptConfig[I].scheduleDivDaySum*AB.rowspan;
var r=100/ptConfig[I].scheduleDivDaySum*AB.index
}var q="";
if(B.byId("top_form_"+I).value=="simple"&&B.byId("view_type_"+I).value=="1"){p=100;
q=((AB.index==0)?"":"display: none;")
}var n=AB.name;
var x=AB.scheduleId;
var z="0";
var s="";
var o=B.byId("member_to-"+I);
if(o){var t=o.options;
for(v=0;
v<t.length;
v++){if(((AB.type=="U")&&(AB.ownerId==t[v].value))||((AB.type=="F")&&(AB.ownerId==t[v].value))){z=v%aipo.calendar.maximum_to
}if(AB.memberList){var u=0;
var AA=0;
for(j=0;
j<AB.memberList.length;
j++){if(AB.memberList[j].charAt(0)=="f"){AA++
}else{u++
}}}}var s;
if(u>1){s="[共有]"
}if(AA>0){s+="[設備]"
}}if(!AB["public"]){n+='<img src="images/schedule/schedule_secret.gif" border="0" width="16" height="16" alt="非公開" title="非公開" align="top" class="icon" />'
}if(AB.duplicate){n+='<img src="images/schedule/schedule_duplicate.gif" border="0" width="16" height="16" alt="重複スケジュール" title="重複スケジュール" align="top" class="icon" />'
}if(AB.repeat){n+='<img src="images/schedule/schedule_repeat.gif" border="0" width="16" height="16" alt="繰り返し" title="繰り返し" align="top" class="icon" />'
}if(AB.tmpreserve){n+='<img src="images/schedule/schedule_tmpreserve.gif" border="0" width="16" height="16" alt="仮スケジュール" title="仮スケジュール" align="top" class="icon" />'
}if(p==100){p="99.99999"
}Q+='<div id="termSchedule-'+P+"-"+I+'" class="termScheduleDiv termColor'+z+'" style="left: '+r+"%; width: "+p+"%;"+q+'"><div class="termScheduleDivHandleLeft" id="termScheduleDivHandleLeft-'+P+"-"+I+'">&nbsp;</div><div class="termScheduleDivNameDiv">'+s+n+'</div><div class="termScheduleDivHandleRight" id="termScheduleDivHandleRight-'+P+"-"+I+'">&nbsp;</div></div>';
P++
}B.byId("termScheduleItemGarage-"+l+"-"+I).innerHTML=Q;
l++
});
tableLeft=B.byId("weeklyTermLeft_"+I);
g=null;
P=0;
l=0;
B.forEach(m.termSchedule,function(n){var p=null;
for(k=0;
k<n.length;
k++){p=n[k];
var o=p.scheduleId;
O=B.byId("termSchedule-"+P+"-"+I);
N=B.byId("termScheduleDivHandleLeft-"+P+"-"+I);
draggable3=B.byId("termScheduleDivHandleRight-"+P+"-"+I);
g=new aipo.calendar.WeeklyTermScheduleDraggable(O,{pid:I,sid:"termSchedule-"+P+"-"+I});
aipo.calendar.objectlist.push(g);
g.schedule=p;
g.scheduleNode=O;
g.portletId=I;
g.termType="center";
B.connect(O,"onclick",g,"onScheduleClick");
O.style.zIndex=1;
if(p.indexReal>=0){tmpDraggable2=new aipo.calendar.WeeklyTermScheduleDraggable(N,{pid:I,sid:"termScheduleDivHandleLeft-"+P+"-"+I});
aipo.calendar.objectlist.push(tmpDraggable2);
tmpDraggable2.schedule=p;
tmpDraggable2.scheduleNode=O;
tmpDraggable2.portletId=I;
tmpDraggable2.termType="left";
if(p.member||p.loginuser||p.owner||p["public"]){tmpDraggable2.setDraggable(true)
}else{tmpDraggable2.setDraggable(false)
}}else{B.style(N,"cursor","pointer");
N.style.zIndex=1
}B.connect(N,"onclick",g,"onScheduleClick");
if(p.indexReal+p.colspanReal<=ptConfig[I].scheduleDivDaySum){tmpDraggable3=new aipo.calendar.WeeklyTermScheduleDraggable(draggable3,{pid:I,sid:"termScheduleDivHandleRight-"+P+"-"+I});
aipo.calendar.objectlist.push(tmpDraggable3);
tmpDraggable3.schedule=p;
tmpDraggable3.scheduleNode=O;
tmpDraggable3.portletId=I;
tmpDraggable3.termType="right";
if(p.member||p.loginuser||p.owner||p["public"]){tmpDraggable3.setDraggable(true)
}else{tmpDraggable3.setDraggable(false)
}}else{B.style(draggable3,"cursor","pointer");
draggable3.style.zIndex=1
}B.connect(draggable3,"onclick",g,"onScheduleClick");
B.connect(O,"onmouseover",g,"onScheduleOver");
if(p.member||p.loginuser||p.owner||p["public"]){g.setDraggable(true)
}else{g.setDraggable(false)
}P++
}l++
});
obj_content=B.byId("content-"+I);
B.style(obj_content,"visibility","visible");
obj_indicator=B.byId("indicator-"+I);
B.style(obj_indicator,"display","none");
B.removeClass(B.byId("tableWrapper_"+I),"hide");
if(!ptConfig[I].isScroll){B.byId("weeklyScrollPane_"+I).scrollTop=ptConfig[I].contentScrollTop;
ptConfig[I].isScroll=true
}ptConfig[I].isTooltipEnable=true
}})
};
aipo.calendar.relocation=function(F,E,U,V){var Q,P;
var T=0.99;
var M=100/7;
var S=0;
var L=0;
var J=0;
var I=0;
var K=new Array(E);
var G=new Array(E);
var R=new Array(E);
var N=1;
var O=0;
if(B.byId("view_type_"+F).value=="1"&&B.byId("top_form_"+F).value=="simple"){N=7.2
}else{if(B.byId("view_type_"+F).value=="4"){N=1.75;
if(V>57){V=100
}}}U.sort(aipo.calendar.sortByRegion);
for(Q=0;
Q<E;
Q++){U[Q].style.zIndex=Q+1
}for(Q=0;
Q<E;
Q=S){S=aipo.calendar.overlapSchedule(U,Q,Q,++S,E);
if(J<parseInt(B.getComputedStyle(U[Q]).top)){I=Q;
J=parseInt(B.getComputedStyle(U[I]).top);
L=0
}for(P=I;
P<S;
P++){var H=parseInt(B.getComputedStyle(U[P]).top)+parseInt(B.getComputedStyle(U[P]).height)
}if(J<H){J=H
}for(P=I;
P<S;
P++){G[P]=aipo.calendar.positionLeft(U,G,I,P,0);
if(G[P]>L){L=G[P]
}}for(P=I;
P<S;
P++){R[P]=aipo.calendar.positionRight(U,G,L,I,P)
}for(P=I;
P<S;
P++){K[P]=L
}}for(Q=0;
Q<E;
Q++){if(K[Q]!=0){if(G[Q]<G[Q+1]){B.style(U[Q],"width",(M*2/(K[Q]+1))*0.8*T*N+"%")
}else{if(R[Q]==0){B.style(U[Q],"width",(M-(M/(K[Q]+1))*G[Q])*T*N+"%")
}else{B.style(U[Q],"width",(M-(M/(K[Q]+1))*G[Q]-(M*2/(K[Q]+1))*0.2-(M/(K[Q]+1))*(R[Q]-1))*T*N+"%")
}}}else{B.style(U[Q],"width",M*T*N+"%")
}B.style(U[Q],"left",(V+((M/(K[Q]+1))*G[Q]))*N+"%");
B.style(U[Q],"visibility","visible")
}};
aipo.calendar.overlapSchedule=function(H,F,L,K,G){var J=parseInt(B.getComputedStyle(H[F]).top)+parseInt(B.getComputedStyle(H[F]).height);
var I=parseInt(B.getComputedStyle(H[L]).top)+parseInt(B.getComputedStyle(H[L]).height);
var E;
if(H[K]){E=parseInt(B.getComputedStyle(H[K]).top)
}else{E="NaN"
}if((K>G-1)||(J<E)||(I<E)){return K
}else{K=aipo.calendar.overlapSchedule(H,F,K,++K,G)
}K=aipo.calendar.overlapSchedule(H,F,L,K,G);
return K
};
aipo.calendar.positionLeft=function(J,I,L,K,F){var E=parseInt(B.getComputedStyle(J[K]).top);
for(i=L;
i<K;
i++){var H=parseInt(B.getComputedStyle(J[i]).top);
var G=H+parseInt(B.getComputedStyle(J[i]).height);
if((H<=E)&&(G>E)&&(I[i]==F)){F=aipo.calendar.positionLeft(J,I,L,K,++F)
}}return F
};
aipo.calendar.positionRight=function(E,I,K,H,L){var J=0;
var G=parseInt(B.getComputedStyle(E[L]).top);
for(i=H;
i<L;
i++){var F=parseInt(B.getComputedStyle(E[i]).top);
var M=F+parseInt(B.getComputedStyle(E[i]).height);
if((F<=G)&&(M>G)&&(I[i]>I[L])&&((K-I[i]+1)>J)){J=K-I[i]+1
}}return J
};
aipo.calendar.sortByRegion=function(G,F){var J=parseInt(B.getComputedStyle(G).top);
var I=parseInt(B.getComputedStyle(F).top);
var E=J+parseInt(B.getComputedStyle(G).height);
var H=E+parseInt(B.getComputedStyle(F).height);
if(J==I){return H-E
}else{return J-I
}};
aipo.calendar.getDate=function(E,F){tmpYear=parseInt(E.substring(0,4),10);
tmpMonth=parseInt(E.substring(5,7),10);
tmpDay=parseInt(E.substring(8,10),10);
if(F>0){do{tmpMonthDays=aipo.calendar.getDay(tmpYear,tmpMonth);
if(tmpDay+F<=tmpMonthDays){tmpDay=tmpDay+F;
if((tmpMonth<10)&&(tmpDay<10)){date=tmpYear+"-0"+tmpMonth+"-0"+tmpDay
}else{if((tmpMonth<10)&&!(tmpDay<10)){date=tmpYear+"-0"+tmpMonth+"-"+tmpDay
}else{if(!(tmpMonth<10)&&(tmpDay<10)){date=tmpYear+"-"+tmpMonth+"-0"+tmpDay
}else{date=tmpYear+"-"+tmpMonth+"-"+tmpDay
}}}F=-1
}else{F=F-(tmpMonthDays-tmpDay)-1;
if(tmpMonth==12){tmpYear++;
tmpMonth=1
}else{tmpMonth++
}tmpDay=1
}}while(F>=0)
}else{if(F<0){do{if(tmpDay+F>0){tmpDay=tmpDay+F;
if((tmpMonth<10)&&(tmpDay<10)){date=tmpYear+"-0"+tmpMonth+"-0"+tmpDay
}else{if((tmpMonth<10)&&!(tmpDay<10)){date=tmpYear+"-0"+tmpMonth+"-"+tmpDay
}else{if(!(tmpMonth<10)&&(tmpDay<10)){date=tmpYear+"-"+tmpMonth+"-0"+tmpDay
}else{date=tmpYear+"-"+tmpMonth+"-"+tmpDay
}}}F=1
}else{if(tmpMonth==1){tmpYear--;
tmpMonth=12
}else{tmpMonth--
}tmpMonthDays=aipo.calendar.getDay(tmpYear,tmpMonth);
F=F+tmpDay;
tmpDay=tmpMonthDays
}}while(F<=0)
}else{date=E
}}return date
};
aipo.calendar.getDay=function(E,F){if(F==2){if(!(E%4)&&((E%100)||!(E%400))){return 29
}else{return 28
}}else{if(F==4||F==6||F==9||F==11){return 30
}else{return 31
}}};
aipo.calendar.setGridArray=function(G,F){var E=0;
if(aipo.calendar.gridArray){delete (aipo.calendar.gridArray)
}aipo.calendar.gridArray=new Array(F);
for(i=0;
i<F;
i++){E=B._abs(B.byId("weeklyDay"+i+"-"+G),true).x;
aipo.calendar.gridArray[i]=E
}};
aipo.calendar.getCurrentMouseX=function(H,I){if(aipo.calendar.gridArray==null){return{index:-1,x:0}
}var F=aipo.calendar.gridArray[0];
var K=0;
var G;
if(I.pageX>F){var E=parseInt(aipo.calendar.gridArray.length)-1;
if(B.byId("view_type_"+H)&&B.byId("top_form_"+H).value=="simple"){E=parseInt(B.byId("view_type_"+H).value)-1
}for(G=E;
G>-1;
G--){if(I.pageX>aipo.calendar.gridArray[G]){K=G;
break
}}}else{K=0
}var J=aipo.calendar.gridArray[K]-F;
return{index:K,x:J}
};
aipo.calendar.onCloseMemberpicker=function(E){aipo.calendar.populateWeeklySchedule(E)
};
aipo.calendar.showTooltip=function(H,J,E){var I="";
var F="";
var G="";
var L="";
var K=function(N){var M=function(O){switch(O){case"<":return"&lt;";
case">":return"&gt;";
case"&":return"&amp;";
case"'":return"&#39;";
case'"':return"&quot;"
}return"?"
};
return String(N).replace(/[<>&"']/g,M)
};
B.style(E,"display","block");
B.xhrGet({portletId:J,url:H,encoding:"utf-8",handleAs:"json-comment-filtered",load:function(R,P){if(!R.id){B.style(E,"display","none");
return 
}if(!R.isSpan){I='<span style="font-size: 0.90em;">'+R.date+"</span><br/>"
}if(R.memberList){var O=R.memberList.length;
for(var M=0;
M<O;
M++){F+="<li>"+K(R.memberList[M].aliasName.value)+"</li>"
}}if(R.facilityList){var N=R.facilityList.length;
for(var M=0;
M<N;
M++){G+="<li>"+K(R.facilityList[M].facilityName.value)+"</li>"
}}if(R.place!=""){L='<span style="font-size: 0.90em;">場所</span><br/><ul><li>'+R.place+"</li></ul>"
}if(F!=""){F='<span style="font-size: 0.90em;">参加者</span><br/><ul>'+F+"</ul>"
}if(G!=""){G='<span style="font-size: 0.90em;">設備</span><br/><ul>'+G+"</ul>"
}var Q="<h4>"+R.name+"</h4>"+I+F+G+L;
E.innerHTML=Q
}})
};
B.declare("aipo.calendar.DummyDivObject",null,{portletId:null,parentnode:null,draggable:null,TooltipObject:null,constructor:function(E,F){this.portletId=F.pid;
this.parentnode=F.node;
this.node=B.byId(E);
this.events=[B.connect(this.node,"onmousedown",this,"onMouseDown"),B.connect(this.node,"onmouseover",this,"onMouseOver"),]
},onMouseDown:function(E){this.hide();
if(this.parentnode==null||this.parentnode=="undefined"){return 
}if(this.draggable){this.draggable.onMouseDown(E)
}},onMouseOver:function(E){if(this.parentnode==null||this.parentnode=="undefined"){return 
}},destroy:function(){B.forEach(this.events,B.disconnect);
this.events=this.node=this.handle=null
},hide:function(){B.marginBox(this.node,{l:0,t:-10000,w:0,h:0})
}});
B.declare("aipo.calendar.WeeklyScheduleDragMoveObject",[aimluck.dnd.DragMoveObject],{_rowHeight_:18,isResize:false,distance:3,lastScroll:0,onFirstMove:function(F){if(this.dragSource.TooltipObject!=null){this.dragSource.TooltipObject.uninitialize()
}var H=B.clone(this.node);
H.id="schedule-dummy-"+this.portletId;
H.style.zIndex=998;
B.style(H,"opacity",0);
var G=B.byId("scheduleGarage-"+this.portletId);
G.appendChild(H);
this.tmpDraggable=H;
B.connect(this.node,"onmousedown",this,"onMouseDown");
if(B.isIE){document.onkeydown=function(I){B.style(H,"opacity",0.3)
};
document.onkeyup=function(I){B.style(H,"opacity",0)
}
}else{B.connect(null,"onkeydown",this,"onKeyPress");
B.connect(null,"onkeyup",this,"onKeyPress")
}aimluck.dnd.DragMoveObject.prototype.onFirstMove.apply(this,arguments);
B.style(this.node,"opacity",0.5);
this.node.style.zIndex=999;
this.startY=this._pageY;
this.startAbsoluteY=B._abs(B.byId(this.node),true).y;
var E=window.navigator.userAgent.toLowerCase();
if(E.indexOf("chrome")>-1||(B.isFF&&(B.isFF>=3.6))){this.startAbsoluteY+=window.scrollY
}else{if(E.indexOf("safari")>-1){this.startAbsoluteY-=B.byId("weeklyScrollPane_"+this.portletId).scrollTop
}}this.startHeight=parseInt(B.getComputedStyle(this.node).height);
this.startTop=parseInt(B.getComputedStyle(this.node).top);
if(this.startHeight-6<this.startY-this.startAbsoluteY){this.isResize=true
}aipo.calendar.setGridArray(this.portletId,parseInt(ptConfig[this.portletId].scheduleDivDaySum));
lastScroll=B.byId("weeklyScrollPane_"+this.portletId).scrollTop
},onKeyPress:function(E){if(E.ctrlKey){B.style(this.tmpDraggable,"opacity",0.3)
}else{B.style(this.tmpDraggable,"opacity",0)
}},onMouseMove:function(L){if(this.dragSource.isDraggable==false){return 
}aimluck.dnd.DragMoveObject.prototype.onMouseMove.apply(this,arguments);
this.dragSource.schedule.isDrag=true;
if(this.dragSource.tmpHeight>3){B.style(this.node,"height",this.dragSource.tmpHeight+"px");
this.dragSource.tmpHeight=3
}var E=ptConfig[this.portletId].distance;
var G=B.byId("weeklyScrollPane_"+this.portletId).scrollTop-lastScroll;
this.leftTop.t=Math.floor((this.leftTop.t+G)/E)*E;
if(this.isResize){if(-this.startTop+this.leftTop.t+this.startHeight<0){B.style(this.node,"height","0px");
this.leftTop.t+=this.startHeight
}else{var N;
if(this.leftTop.t+this.startHeight>864){N=864-this.startTop-3
}else{N=-this.startTop+this.leftTop.t+this.startHeight
}this.leftTop.t=this.startTop;
this.leftTop.h=parseInt(N)-1
}}else{if(!this.disableY){if(this.leftTop.t<0){this.leftTop.t=0
}if(this.leftTop.t+this.startHeight>864){this.leftTop.t=864-this.startHeight-6
}}}if(!this.disableX){mouseX=aipo.calendar.getCurrentMouseX(this.portletId,L);
this.leftTop.l=mouseX.x;
this.dragSource.schedule.index=mouseX.index
}B.marginBox(this.node,this.leftTop);
var M=parseInt(B.getComputedStyle(this.node).top);
var K=parseInt(B.getComputedStyle(this.node).height)+1;
var J=M/E;
var I=Math.floor(J/12);
var H=Math.floor(J%12);
I=(I>9)?I:"0"+I;
H=(H>1)?H*(60/12):"0"+H*(60/12);
var F=this.dragSource.count;
B.byId("scheduleDivStartTime-"+F+"-"+this.portletId).innerHTML=I+":"+H;
this.dragSource.schedule.startDateHour=I;
this.dragSource.schedule.startDateMinute=H;
this.dragSource.schedule.startDate=I+":"+H;
J+=K/E;
I=Math.floor(J/12);
H=Math.floor(J%12);
I=(I>9)?I:"0"+I;
H=(H>1)?H*(60/12):"0"+H*(60/12);
B.byId("scheduleDivEndTime-"+F+"-"+this.portletId).innerHTML=I+":"+H;
this.dragSource.schedule.endDateHour=I;
this.dragSource.schedule.endDateMinute=H;
this.dragSource.schedule.endDate=I+":"+H;
B.byId("scheduleDivSepalater-"+F+"-"+this.portletId).innerHTML="-";
return 
},onMouseUp:function(F){ptConfig[this.portletId].isTooltipEnable=true;
if(B.isIE){document.onkeydown="";
document.onkeyup=""
}if(this.dragSource.schedule.isDrag!=true){B.style(this.node,"opacity",1);
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments);
if(this.dragSource){this.dragSource.onScheduleClick(F)
}return 
}var E=parseInt(B.getComputedStyle(this.node).height);
if(E<ptConfig[this.portletId].rowHeight){B.style(this.node,"height",ptConfig[this.portletId].rowHeight+"px");
this.dragSource.tmpHeight=E
}else{this.dragSource.tmpHeight=-1
}var G="";
if(F.ctrlKey){G+="&mode=insert"
}else{G+="&mode=update"
}G+="&entityid="+this.dragSource.schedule.scheduleId;
G+="&view_start="+ptConfig[this.portletId].jsonData.date[0].substring(0,10);
if(this.dragSource.schedule.repeat){G+="&edit_repeat_flag=1";
G+="&view_date="+ptConfig[this.portletId].jsonData.date[this.dragSource.tmpIndex].substring(0,10)
}G+="&start_date="+ptConfig[this.portletId].jsonData.date[this.dragSource.schedule.index].substring(0,11)+this.dragSource.schedule.startDateHour+"-"+this.dragSource.schedule.startDateMinute;
G+="&end_date="+ptConfig[this.portletId].jsonData.date[this.dragSource.schedule.index].substring(0,11)+this.dragSource.schedule.endDateHour+"-"+this.dragSource.schedule.endDateMinute;
aipo.calendar.populateWeeklySchedule(this.portletId,G);
aipo.portletReload("schedule",this.portletId);
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments);
this.dragSource.destroy()
}});
B.declare("aipo.calendar.WeeklyScheduleDraggable",[aimluck.dnd.Draggable],{DragMoveObject:aipo.calendar.WeeklyScheduleDragMoveObject,isDraggable:false,scheduleObjId:null,constructor:function(E,F){this.scheduleObjId=F.sid
},onMouseDown:function(E){ptConfig[this.portletId].isTooltipEnable=false;
if(!!aipo.calendar.dummyDivObj&&!!aipo.calendar.dummyDivObj.TooltipObject){aipo.calendar.dummyDivObj.TooltipObject.close()
}aimluck.dnd.Draggable.prototype.onMouseDown.apply(this,arguments)
},onScheduleClick:function(F){if(this.schedule.isDrag||!this.isDraggable){return 
}var E=this.schedule.ownerId;
aipo.common.showDialog(ptConfig[this.portletId].detailUrl+"&entityId="+this.schedule.scheduleId+"&view_date="+ptConfig[this.portletId].jsonData.date[this.schedule.index]+"&userid="+E,this.portletId,aipo.schedule.onLoadScheduleDetail);
aipo.schedule.tmpScroll=parseInt(B.byId("weeklyScrollPane_"+this.portletId)["scrollTop"])
},onScheduleOver:function(J){if(ptConfig[this.portletId].isTooltipEnable==false){return 
}var G=B.byId("dummy_div_"+this.portletId);
var I=B.getComputedStyle(this.node).left;
var H=B.getComputedStyle(this.node).top;
var F=B.getComputedStyle(this.node).width;
var E=B.getComputedStyle(this.node).height;
B.marginBox(G,B._getMarginBox(this.node,{l:I,t:H,w:F,h:E}));
G.style.zIndex=this.node.style.zIndex;
G.style.height=(parseInt(E)-6)+"px";
if(!aipo.calendar.dummyDivObj){aipo.calendar.dummyDivObj=new aipo.calendar.DummyDivObject(G,{pid:this.scheduleObjId,node:this.node})
}else{aipo.calendar.dummyDivObj.parentnode=this.node
}aipo.calendar.dummyDivObj.draggable=this;
if(aipo.calendar.dummyDivObj.TooltipObject){aipo.calendar.dummyDivObj.TooltipObject.destroyRecursive();
aipo.calendar.dummyDivObj.TooltipObject=null
}if(scheduleTooltipEnable){this.setupTooltip()
}},setupTooltip:function(){var E=this.schedule.scheduleId;
var F=ptConfig[this.portletId].jsonData.endDate;
aipo.calendar.dummyDivObj.TooltipObject=new aipo.widget.ToolTip({label:"<div class='indicator'>読み込み中...</div>",connectId:["dummy_div_"+this.portletId]},this.portletId,function(G,I){var H=ptConfig[this.portletId].jsonUrl.split("?")[0]+"?template=ScheduleDetailJSONScreen&view_date="+F+"&scheduleid="+E;
aipo.calendar.showTooltip(H,this.portletId,G)
})
},setDraggable:function(E){this.isDraggable=E
}});
B.declare("aipo.calendar.WeeklyTermScheduleDragMoveObject",[aimluck.dnd.DragMoveObject],{positionFrom:-1,positionTo:-1,moveIndex:0,onFirstMove:function(E){if(this.dragSource.TooltipObject!=null){this.dragSource.TooltipObject.uninitialize()
}aimluck.dnd.DragMoveObject.prototype.onFirstMove.apply(this,arguments);
B.style(this.node,"opacity",0.5);
aipo.calendar.setGridArray(this.portletId,parseInt(ptConfig[this.portletId].scheduleDivDaySum));
var G=B.clone(this.node);
G.id="schedule-dummy-"+this.portletId;
G.style.zIndex=998;
B.style(G,"opacity",0);
var F=B.byId(this.node.parentNode.id);
F.appendChild(G);
this.tmpDraggable=G;
if(B.isIE){document.onkeydown=function(H){B.style(G,"opacity",0.3)
};
document.onkeyup=function(H){B.style(G,"opacity",0)
}
}else{B.connect(null,"onkeydown",this,"onKeyPress");
B.connect(null,"onkeyup",this,"onKeyPress")
}},onKeyPress:function(E){if(E.ctrlKey){B.style(this.tmpDraggable,"opacity",0.3)
}else{B.style(this.tmpDraggable,"opacity",0)
}},onMouseMove:function(K){if(this.dragSource.isDraggable==false){return 
}aimluck.dnd.DragMoveObject.prototype.onMouseMove.apply(this,arguments);
this.dragSource.schedule.isDrag=true;
var E=ptConfig[this.portletId].distance;
var P=(B.byId("view_type_"+this.portletId)&&B.byId("top_form_"+this.portletId)&&B.byId("top_form_"+this.portletId).value=="simple")?B.byId("view_type_"+this.portletId).value:ptConfig[this.portletId].scheduleDivDaySum;
var J=aipo.calendar.getCurrentMouseX(this.portletId,K);
_tmpIndex=J.index;
if(!this.disableX){var H=this.dragSource.schedule;
var L=this.dragSource.termType;
var N=this.dragSource.scheduleNode;
var M,G;
if(L=="center"){if(this.positionFrom==-1&&_tmpIndex!=-1){this.positionFrom=_tmpIndex;
this.positionTo=this.positionFrom
}if(this.positionTo!=-1&&_tmpIndex!=-1){this.positionTo=_tmpIndex
}this.moveIndex=-this.positionFrom+this.positionTo;
G=H.indexReal+this.moveIndex;
M=H.colspanReal;
var O=P;
if(M+G>O){if(G<0){M=O
}else{M=O-G
}}else{if(G<0){M=M+G
}}if(G<0){G=0
}}else{if(L=="left"){if(this.positionFrom==-1){this.positionFrom=H.index;
this.positionTo=H.index
}if(this.positionTo!=-1&&_tmpIndex!=-1){this.positionTo=_tmpIndex
}this.moveIndex=-this.positionFrom+this.positionTo;
if(this.positionTo>=this.positionFrom+H.colspanReal){G=H.indexReal+H.rowspan-1;
M=this.positionTo-this.positionFrom-H.colspanReal+2
}else{G=this.positionTo;
M=H.rowspan+this.positionFrom-this.positionTo
}}else{if(this.positionFrom==-1){this.positionFrom=H.index;
this.positionTo=H.index
}if(this.positionTo!=-1&&_tmpIndex!=-1&&this._tmpIndex!=-1){this.positionTo=_tmpIndex
}this.moveIndex=-H.index-H.rowspan+this.positionTo+1;
if(this.positionTo<=this.positionFrom){G=this.positionTo;
M=this.positionFrom-this.positionTo+1
}else{G=H.index;
M=this.positionTo-H.index+1
}}}var F=100/P*M;
var I=100/P*G;
B.style(N,"left",I+"%");
B.style(N,"width",F+"%")
}},onMouseUp:function(I){ptConfig[this.portletId].isTooltipEnable=true;
if(B.isIE){document.onkeydown="";
document.onkeyup=""
}if(this.dragSource.schedule.isDrag!=true){B.style(this.node,"opacity",1);
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments);
return 
}var F=this.dragSource.schedule;
var L=ptConfig[this.portletId].jsonData.date[0].substring(0,10);
var G=this.dragSource.termType;
var K=this.dragSource.scheduleNode;
var E,H;
if(B.byId("top_form_"+this.portletId).value=="simple"){E=ptConfig[this.portletId].jsonData.date[0];
H=ptConfig[this.portletId].jsonData.date[0]
}if(G=="center"){E=aipo.calendar.getDate(L,F.indexReal+this.moveIndex)+"-00-00";
H=aipo.calendar.getDate(L,F.indexReal+this.moveIndex+F.colspanReal-1)+"-00-00"
}else{if(G=="left"){if(F.colspanReal-this.moveIndex>0){E=aipo.calendar.getDate(L,F.indexReal+this.moveIndex)+"-00-00";
H=aipo.calendar.getDate(L,F.indexReal+F.colspanReal-1)+"-00-00"
}else{E=aipo.calendar.getDate(L,F.indexReal+F.colspanReal-1)+"-00-00";
H=aipo.calendar.getDate(L,F.indexReal+this.moveIndex)+"-00-00"
}}else{if(F.colspanReal+this.moveIndex>0){E=aipo.calendar.getDate(L,F.indexReal)+"-00-00";
H=aipo.calendar.getDate(L,F.indexReal+F.colspanReal+this.moveIndex-1)+"-00-00"
}else{E=aipo.calendar.getDate(L,F.indexReal+F.colspanReal+this.moveIndex-1)+"-00-00";
H=aipo.calendar.getDate(L,F.indexReal)+"-00-00"
}}}this.positionFrom=-1;
this.positionTo=-1;
this.moveIndex=0;
this.tmpIndex=0;
var J="";
if(I.ctrlKey){J+="&mode=insert"
}else{J+="&mode=update"
}J+="&is_span=TRUE";
J+="&entityid="+this.dragSource.schedule.scheduleId;
J+="&view_start="+L;
J+="&start_date="+E;
J+="&end_date="+H;
aipo.calendar.populateWeeklySchedule(this.portletId,J);
aipo.portletReload("schedule",this.portletId);
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments)
}});
B.declare("aipo.calendar.WeeklyTermScheduleDraggable",[aimluck.dnd.Draggable],{DragMoveObject:aipo.calendar.WeeklyTermScheduleDragMoveObject,isDraggable:false,TooltipObject:null,scheduleObjId:null,isDraggable:false,constructor:function(E,F){this.scheduleObjId=F.sid
},onMouseDown:function(E){ptConfig[this.portletId].isTooltipEnable=false;
if(this.TooltipObject){this.TooltipObject.close()
}aimluck.dnd.Draggable.prototype.onMouseDown.apply(this,arguments)
},onScheduleClick:function(F){if(this.schedule.isDrag||!this.isDraggable){return 
}var E=this.schedule.ownerId;
aipo.common.showDialog(ptConfig[this.portletId].detailUrl+"&entityId="+this.schedule.scheduleId+"&view_date="+ptConfig[this.portletId].jsonData.date[this.schedule.index]+"&userid="+E,this.portletId,aipo.schedule.onLoadScheduleDetail);
aipo.schedule.tmpScroll=parseInt(B.byId("weeklyScrollPane_"+this.portletId)["scrollTop"])
},onScheduleOver:function(E){if(ptConfig[this.portletId].isTooltipEnable==false){return 
}if(scheduleTooltipEnable){this.setupTooltip()
}},setupTooltip:function(){var E=this.schedule.scheduleId;
var F=ptConfig[this.portletId].jsonData.endDate;
if(!this.TooltipObject){this.TooltipObject=new aipo.widget.ToolTip({label:"<div class='indicator'>読み込み中...</div>",connectId:[this.node.id]},this.portletId,function(G,I){var H=ptConfig[this.portletId].jsonUrl.split("?")[0]+"?template=ScheduleDetailJSONScreen&view_date="+F+"&scheduleid="+E;
aipo.calendar.showTooltip(H,this.portletId,G)
})
}aipo.calendar.objectlist.push(this.TooltipObject)
},setDraggable:function(E){this.isDraggable=E
}});
B.declare("aipo.calendar.WeeklyScheduleAddDragMoveObject",[aimluck.dnd.DragMoveObject],{_rowHeight_:18,positionFrom:0,positionTo:0,_isDragging:false,lastScroll:0,onMouseDown:function(E){this._isDragging=false;
aimluck.dnd.DragMoveObject.prototype.onMouseDown.apply(this,arguments)
},onFirstMove:function(F){this.startY=this.dragSource._lastY;
this.startAbsoluteY=B._abs(B.byId(this.node),true).y;
this.startX=B.getComputedStyle(this.node).left;
var E=window.navigator.userAgent.toLowerCase();
if(E.indexOf("chrome")>-1||(B.isFF&&(B.isFF>=3.6))){this.startAbsoluteY+=window.scrollY
}else{if(E.indexOf("safari")>-1){this.startAbsoluteY-=B.byId("weeklyScrollPane_"+this.portletId).scrollTop
}}lastScroll=B.byId("weeklyScrollPane_"+this.portletId).scrollTop;
aimluck.dnd.DragMoveObject.prototype.onFirstMove.apply(this,arguments)
},onMouseMove:function(J){aimluck.dnd.DragMoveObject.prototype.onMouseMove.apply(this,arguments);
this._isDragging=true;
var I=B.byId("weeklyScrollPane_"+this.portletId).scrollTop-lastScroll;
var H=Math.floor((this.startY-this.startAbsoluteY)/this._rowHeight_);
var E=Math.floor((this.startY+this.leftTop.t-this.startAbsoluteY+I)/this._rowHeight_);
var F=0;
var G=0;
if(E<H){F=E*this._rowHeight_+1;
G=(H-E+1)*this._rowHeight_;
this.positionFrom=E;
this.positionTo=H+1
}else{F=H*this._rowHeight_+1;
G=(E-H+1)*this._rowHeight_;
this.positionTo=E+1;
this.positionFrom=H
}if(F+G>864){G=864-F-this._rowHeight_;
this.positionTo=47
}this.leftTop.t=F;
this.leftTop.l=this.startX;
this.leftTop.h=G;
B.marginBox(this.node,this.leftTop);
B.style(this.node,"opacity",0.5)
},onMouseUp:function(I){if(!this._isDragging){this.onFirstMove(I);
this.onMouseMove(I)
}var E=Math.floor(this.positionFrom/2);
E=(E>9)?E:"0"+E;
var J=Math.floor(this.positionFrom%2)*30;
var G=ptConfig[this.portletId].jsonData.date[this.dragSource.index].substring(0,10);
var H=G+"-"+E+"-"+J;
E=Math.floor(this.positionTo/2);
E=(E>9)?E:"0"+E;
J=Math.floor(this.positionTo%2)*30;
var F=G+"-"+E+"-"+J;
this.node.style.top="0px";
this.node.style.height="864px";
B.style(this.node,"opacity",0);
if(this._isDragging==true){aipo.common.showDialog(ptConfig[this.portletId].formUrl+"&entityid=new&mode=form&form_start="+H+"&form_end="+F,this.portletId,aipo.schedule.onLoadScheduleDialog)
}aipo.schedule.tmpScroll=parseInt(B.byId("weeklyScrollPane_"+this.portletId)["scrollTop"]);
this._isDragging=false;
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments)
}});
B.declare("aipo.calendar.WeeklyScheduleAddDraggable",[aimluck.dnd.Draggable],{DragMoveObject:aipo.calendar.WeeklyScheduleAddDragMoveObject,constructor:function(E,F){this.index=F.idx
}});
B.declare("aipo.calendar.WeeklyTermScheduleAddDragMoveObject",[aimluck.dnd.DragMoveObject],{_rowHeight_:18,positionFrom:-1,positionTo:-1,_isDragging:false,scheduleObjId:null,onMouseDown:function(E){this._isDragging=false;
aimluck.dnd.DragMoveObject.prototype.onMouseDown.apply(this,arguments)
},onFirstMove:function(E){aimluck.dnd.DragMoveObject.prototype.onFirstMove.apply(this,arguments);
aipo.calendar.setGridArray(this.portletId,parseInt(ptConfig[this.portletId].scheduleDivDaySum))
},onMouseMove:function(K){aimluck.dnd.DragMoveObject.prototype.onMouseMove.apply(this,arguments);
this._isDragging=true;
B.style(this.node,"opacity",0.5);
var G=aipo.calendar.getCurrentMouseX(this.portletId,K);
var L=G.index;
if(this.positionFrom==-1&&L!=-1){this.positionFrom=L;
this.positionTo=this.positionFrom
}if(this.positionTo!=-1&&L!=-1){this.positionTo=L
}if(this.positionTo!=-1&&this.positionFrom!=-1){var F,E;
if(this.positionTo>this.positionFrom){E=this.positionFrom;
F=this.positionTo-this.positionFrom+1
}else{E=this.positionTo;
F=this.positionFrom-this.positionTo+1
}var I;
var J;
if(B.byId("view_type_"+this.portletId)&&B.byId("top_form_"+this.portletId).value=="simple"){var H=parseInt(B.byId("view_type_"+this.portletId).value);
I=100/H*F;
J=100/H*E
}else{I=100/ptConfig[this.portletId].scheduleDivDaySum*F;
J=100/ptConfig[this.portletId].scheduleDivDaySum*E
}B.style(this.node,"left",J+"%");
B.style(this.node,"width",I+"%")
}else{B.style(this.node,"left",0+"%");
B.style(this.node,"width",0+"%")
}},onMouseUp:function(H){if(!this._isDragging){this.onFirstMove(H);
this.onMouseMove(H)
}var I,G;
if(this.positionTo!=-1&&this.positionFrom!=-1){if(this.positionTo>this.positionFrom){I=this.positionFrom;
G=this.positionTo
}else{G=this.positionFrom;
I=this.positionTo
}var F=ptConfig[this.portletId].jsonData.date[I];
var E=ptConfig[this.portletId].jsonData.date[G];
if(this._isDragging==true){aipo.common.showDialog(ptConfig[this.portletId].formUrl+"&entityid=new&mode=form&is_span=TRUE&form_start="+F+"&form_end="+E,this.portletId,aipo.schedule.onLoadScheduleDialog)
}aipo.schedule.tmpScroll=parseInt(B.byId("weeklyScrollPane_"+this.portletId)["scrollTop"])
}this.positionFrom=-1;
this.positionTo=-1;
B.style(this.node,"left",0+"%");
B.style(this.node,"width",100+"%");
B.style(this.node,"opacity",0);
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments)
}});
B.declare("aipo.calendar.WeeklyTermScheduleAddDraggable",[aimluck.dnd.Draggable],{DragMoveObject:aipo.calendar.WeeklyTermScheduleAddDragMoveObject,constructor:function(E,F){this.index=F.idx
}});
aipo.schedule.initCalendar=function(F){for(var E=0;
E<ptConfig[F].scheduleDivDaySum;
E++){tmpDraggable=new aipo.calendar.WeeklyScheduleAddDraggable("scheduleDivAdd0"+E+"_"+F,{idx:E});
tmpDraggable.portletId=F;
tmpDraggable.index=E
}tmpDraggable=new aipo.calendar.WeeklyTermScheduleAddDraggable("termScheduleDivAdd_"+F,{idx:0});
tmpDraggable.portletId=F;
aipo.calendar.populateWeeklySchedule(F)
};
aipo.schedule.groupSelectOnchange=function(G,J,K,E){var M=function(Q,P){var O="";
E.dropDown.removeMember(B.byId("member_to-"+K));
for(var N=0;
N<Q.length;
N++){if(N!=0){O+=" "
}F+="&m_id="+Q[N].name;
O+='<span class="dispUser color'+N+'">'+Q[N].aliasName+"</span>";
aimluck.io.addOption(B.byId("member_to-"+K),Q[N].name,Q[N].aliasName,true)
}B.byId("member_to_input-"+K).innerHTML=O
};
var H=B.query(".addUser",B.byId("memberpicker-"+K));
switch(G.value){case"":G.selectedIndex=B.query("[value=pickup]",this)[0].index;
case"pickup":H.removeClass("hide");
E.dropDown.removeMember(B.byId("member_to-"+K));
E.dropDown.removeMember(B.byId("tmp_member_to-"+K));
var L=B.byId("picked_memberlist-"+K).options;
for(var I=0;
I<L.length;
I++){(function(O,N){O.selected=true
})(L[I],I)
}E.dropDown.addMember(B.byId("picked_memberlist-"+K),B.byId("tmp_member_to-"+K));
E.dropDown.addMember(B.byId("picked_memberlist-"+K),B.byId("member_to-"+K));
E.inputMemberSync();
aipo.calendar.populateWeeklySchedule(K);
B.xhrGet({portletId:K,url:B.byId("groupselect-defaulturl-"+K).value,encoding:"utf-8",handleAs:"json-comment-filtered"});
break;
default:H.addClass("hide");
var F="";
B.xhrGet({portletId:K,url:G.value,encoding:"utf-8",handleAs:"json-comment-filtered",load:M,handle:function(){aipo.calendar.populateWeeklySchedule(K,F)
}});
break
}}
}}});