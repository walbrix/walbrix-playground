<?php echo $options->getRaw('body') ?>
