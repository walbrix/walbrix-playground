module WikiPagesHelper
end
