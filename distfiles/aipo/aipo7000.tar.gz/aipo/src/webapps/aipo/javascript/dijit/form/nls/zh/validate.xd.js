dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.zh.validate"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.zh.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "zh", {"rangeMessage": "* 此值超出范围。", "invalidMessage": "* 输入的值无效。", "missingMessage": "* 此值是必需值。"});
}});