dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.ja.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.ja.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "ja", {"iframeTitle1": "編集域", "iframeTitle2": "編集域フレーム"});
}});