<?php if ($sf_user->isSNSMember()): ?>
<?php echo op_banner('side_after') ?>
<?php else: ?>
<?php echo op_banner('side_before') ?>
<?php endif ?>
