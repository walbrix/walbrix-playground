dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.ru.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.ru.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "ru", {"loadingState": "Загрузка...", "errorState": "Извините, возникла ошибка"});
}});