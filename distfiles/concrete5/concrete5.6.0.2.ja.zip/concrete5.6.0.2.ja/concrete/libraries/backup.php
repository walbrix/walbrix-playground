<?php	

defined('C5_EXECUTE') or die("Access Denied.");
class Backup extends Concrete5_Library_Backup {}