# Movable Type (r) Open Source (C) 2006-2012 Six Apart, Ltd.
# This program is distributed under the terms of the
# GNU General Public License, version 2.
#
# $Id$

# Original Copyright (c) 2004-2006 David Raynes

package MultiBlog::L10N::en_us;

use strict;

use base 'MultiBlog::L10N';
use vars qw( %Lexicon );
%Lexicon = ();

1;
