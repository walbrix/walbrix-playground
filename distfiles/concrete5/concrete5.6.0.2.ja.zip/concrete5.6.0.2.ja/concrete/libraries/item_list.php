<?php	
defined('C5_EXECUTE') or die("Access Denied.");
class ItemList extends Concrete5_Library_ItemList {}