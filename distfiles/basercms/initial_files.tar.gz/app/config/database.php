<?php
//
// Database Configuration File created by baserCMS Installation
//
class DATABASE_CONFIG {
var $baser = array(
	'driver' => 'bc_mysql',
	'persistent' => false,
	'host' => 'localhost',
	'port' => '3306',
	'login' => 'basercms',
	'password' => '',
	'database' => 'basercms',
	'schema' => '',
	'prefix' => 'bc_',
	'encoding' => 'utf8'
);
var $plugin = array(
	'driver' => 'bc_mysql',
	'persistent' => false,
	'host' => 'localhost',
	'port' => '3306',
	'login' => 'basercms',
	'password' => '',
	'database' => 'basercms',
	'schema' => '',
	'prefix' => 'bc_pg_',
	'encoding' => 'utf8'
);
}
