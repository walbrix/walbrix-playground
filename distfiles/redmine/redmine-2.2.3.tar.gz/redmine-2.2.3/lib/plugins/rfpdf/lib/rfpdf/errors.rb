module RFPDF
  module Errors
    class GenerationError < StandardError #:nodoc:
    end
  end
end