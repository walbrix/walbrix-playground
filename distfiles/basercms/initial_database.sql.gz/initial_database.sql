-- MySQL dump 10.13  Distrib 5.1.67, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: basercms
-- ------------------------------------------------------
-- Server version	5.1.67

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bc_contents`
--

DROP TABLE IF EXISTS `bc_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_contents` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) DEFAULT NULL,
  `model` varchar(50) NOT NULL,
  `model_id` int(8) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `detail` text,
  `url` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `priority` varchar(3) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_contents`
--

LOCK TABLES `bc_contents` WRITE;
/*!40000 ALTER TABLE `bc_contents` DISABLE KEYS */;
INSERT INTO `bc_contents` VALUES (1,'ページ','Page',2,'','会社案内','baserCMS inc.の会社案内ページ NEWS RELEASEbaserCMS NEWS','/about',1,'0.5','2013-04-05 10:25:35','2013-04-05 10:25:50'),(2,'ページ','Page',3,'','サービス','baserCMS inc.のサービス紹介ページ。 NEWS RELEASEbaserCMS NEWS','/service',1,'0.5','2013-04-05 10:25:35','2013-04-05 10:25:50'),(3,'ページ','Page',4,'','アイコンの使い方','50種類のアイコンを自由にカスタマイズしよう。 NEWS RELEASEbaserCMS NEWS','/icons',1,'0.5','2013-04-05 10:25:35','2013-04-05 10:25:51'),(4,'ブログ','BlogContent',1,'','ニュースリリース','Baser CMS inc. [デモ] の最新のニュースリリースをお届けします。','/news/index',1,'0.5','2013-04-05 10:25:35',NULL),(5,'メール','MailContent',1,'','お問い合わせ','* 印の項目は必須となりますので、必ず入力してください。','/contact/index',1,'0.5','2013-04-05 10:25:35',NULL),(6,'ページ','Page',1,'','Index','NEWS RELEASEbaserCMS NEWS','/index',1,'0.5','2013-04-05 10:25:35','2013-04-05 10:25:50'),(7,'ページ','Page',5,'','サイトマップ','baserCMS inc.のサイトマップページ NEWS RELEASEbaserCMS NEWS','/sitemap',1,'0.5','2013-04-05 10:25:35','2013-04-05 10:25:51');
/*!40000 ALTER TABLE `bc_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_dblogs`
--

DROP TABLE IF EXISTS `bc_dblogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_dblogs` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `user_id` int(8) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_dblogs`
--

LOCK TABLES `bc_dblogs` WRITE;
/*!40000 ALTER TABLE `bc_dblogs` DISABLE KEYS */;
INSERT INTO `bc_dblogs` VALUES (1,'新規プラグイン「twitter」を baserCMS に登録しました。',1,'2013-04-05 10:27:21','2013-04-05 10:27:21'),(2,'新規プラグイン「uploader」を baserCMS に登録しました。',1,'2013-04-05 10:27:24','2013-04-05 10:27:24');
/*!40000 ALTER TABLE `bc_dblogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_editor_templates`
--

DROP TABLE IF EXISTS `bc_editor_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_editor_templates` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `html` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_editor_templates`
--

LOCK TABLES `bc_editor_templates` WRITE;
/*!40000 ALTER TABLE `bc_editor_templates` DISABLE KEYS */;
INSERT INTO `bc_editor_templates` VALUES (1,'画像（左）とテキスト','template1.gif','画像を左に配置し、その右にテキストを配置するブロックです。','<div class=\"template-image-float-left clearfix\">\n	<div class=\"image\">ここに画像を挿入します</div>\n	<div class=\"text\">\n		<h2>見出しを挿入します。</h2>\n		<p>1段落目のテキストを挿入します。</p>\n		<p>2段落目のテキストを挿入します。</p>\n	</div>\n</div>\n<p>新しいブロックを挿入します。不要な場合はこの段落を削除します</p>',NULL,'2013-04-05 10:25:35'),(2,'画像（右）とテキスト','template2.gif','画像を右に配置し、その左にテキストを配置するブロックです。','<div class=\"template-image-float-right clearfix\">\n	<div class=\"image\">ここに画像を挿入します</div>\n	<div class=\"text\">\n		<h2>見出しを挿入します。</h2>\n		<p>1段落目のテキストを挿入します。</p>\n		<p>2段落目のテキストを挿入します。</p>\n	</div>\n</div>\n<p>新しいブロックを挿入します。不要な場合はこの段落を削除します</p>',NULL,'2013-04-05 10:25:35'),(3,'テキスト２段組','template3.gif','テキストを左右に２段組するブロックです。','<div class=\"template-two-block clearfix\">\n	<div class=\"block-left\">\n		<h2>\n			見出しを挿入します。</h2>\n		<p>\n			1段落目のテキストを挿入します。</p>\n		<p>\n			2段落目のテキストを挿入します。</p>\n	</div>\n	<div class=\"block-right\">\n		<h2>\n			見出しを挿入します。</h2>\n		<p>\n			1段落目のテキストを挿入します。</p>\n		<p>\n			2段落目のテキストを挿入します。</p>\n	</div>\n</div>\n<p>\n	新しいブロックを挿入します。不要な場合はこの段落を削除します</p>',NULL,'2013-04-05 10:25:35');
/*!40000 ALTER TABLE `bc_editor_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_favorites`
--

DROP TABLE IF EXISTS `bc_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_favorites` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `user_id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `sort` int(8) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_favorites`
--

LOCK TABLES `bc_favorites` WRITE;
/*!40000 ALTER TABLE `bc_favorites` DISABLE KEYS */;
INSERT INTO `bc_favorites` VALUES (1,1,'固定ページ管理','/admin/pages/index',1,'2013-04-05 10:25:49','2013-04-05 10:25:49'),(2,1,'新着情報管理','/admin/blog/blog_posts/index/1',2,'2013-04-05 10:25:49','2013-04-05 10:25:49'),(3,1,'お問い合わせ管理','/admin/mail/mail_fields/index/1',3,'2013-04-05 10:25:49','2013-04-05 10:25:49'),(4,1,'受信メール一覧','/admin/mail/mail_messages/index/1',4,'2013-04-05 10:25:49','2013-04-05 10:25:49'),(5,1,'コメント一覧','/admin/blog/blog_comments/index/1',5,'2013-04-05 10:25:49','2013-04-05 10:25:49'),(6,1,'クレジット','javascript:credit();',6,'2013-04-05 10:25:49','2013-04-05 10:25:49');
/*!40000 ALTER TABLE `bc_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_global_menus`
--

DROP TABLE IF EXISTS `bc_global_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_global_menus` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `no` int(3) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `menu_type` varchar(20) DEFAULT NULL,
  `sort` int(3) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_global_menus`
--

LOCK TABLES `bc_global_menus` WRITE;
/*!40000 ALTER TABLE `bc_global_menus` DISABLE KEYS */;
INSERT INTO `bc_global_menus` VALUES (1,1,'ホーム','/','default',1,1,'2013-04-05 10:25:35',NULL),(2,2,'会社案内','/about','default',2,1,'2013-04-05 10:25:35',NULL),(3,3,'サービス','/service','default',3,1,'2013-04-05 10:25:35',NULL),(4,4,'新着情報','/news/index','default',4,1,'2013-04-05 10:25:35',NULL),(5,5,'お問い合わせ','/contact/index','default',5,1,'2013-04-05 10:25:35',NULL),(6,6,'サイトマップ','/sitemap','default',7,1,'2013-04-05 10:25:35',NULL),(7,7,'アイコンの使い方','/icons','',6,1,'2013-04-05 10:25:35',NULL);
/*!40000 ALTER TABLE `bc_global_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_page_categories`
--

DROP TABLE IF EXISTS `bc_page_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_page_categories` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `parent_id` int(8) DEFAULT NULL,
  `lft` int(8) DEFAULT NULL,
  `rght` int(8) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `sort` int(8) DEFAULT NULL,
  `contents_navi` tinyint(1) NOT NULL DEFAULT '0',
  `owner_id` int(8) DEFAULT NULL,
  `layout_template` varchar(255) DEFAULT NULL,
  `content_template` varchar(255) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_page_categories`
--

LOCK TABLES `bc_page_categories` WRITE;
/*!40000 ALTER TABLE `bc_page_categories` DISABLE KEYS */;
INSERT INTO `bc_page_categories` VALUES (2,NULL,3,4,'smartphone','スマートフォン',1,0,NULL,'','',NULL,'2013-04-05 10:25:36'),(1,NULL,1,2,'mobile','モバイル',1,0,NULL,'','',NULL,'2013-04-05 10:25:36');
/*!40000 ALTER TABLE `bc_page_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pages`
--

DROP TABLE IF EXISTS `bc_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pages` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `sort` int(8) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `contents` text,
  `page_category_id` int(8) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `url` text,
  `draft` text,
  `author_id` int(8) DEFAULT NULL,
  `publish_begin` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `exclude_search` tinyint(1) DEFAULT NULL,
  `code` text,
  `unlinked_mobile` tinyint(1) DEFAULT NULL,
  `unlinked_smartphone` tinyint(1) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pages`
--

LOCK TABLES `bc_pages` WRITE;
/*!40000 ALTER TABLE `bc_pages` DISABLE KEYS */;
INSERT INTO `bc_pages` VALUES (1,1,'index','','','<div id=\"news\" class=\"clearfix\">\r\n<div class=\"news\" style=\"margin-right:28px;\">\r\n<h2 id=\"newsHead01\">NEWS RELEASE</h2>\r\n<div class=\"body\">\r\n<?php $bcBaser->blogPosts(\'news\', 5) ?>\r\n</div>\r\n</div>\r\n\r\n\r\n<div class=\"news\">\r\n<h2 id=\"newsHead02\">baserCMS NEWS</h2>\r\n<div class=\"body\">\r\n<?php $bcBaser->js(\'/feed/ajax/1\') ?>\r\n</div>\r\n</div>\r\n</div>',NULL,1,'/index','',1,NULL,NULL,0,'',0,0,NULL,'2013-04-05 10:25:35'),(2,2,'about','会社案内','baserCMS inc.の会社案内ページ','<h2 class=\"contents-head\">会社案内</h2>\r\n\r\n<h3 class=\"contents-head\">会社データ</h3>\r\n\r\n<div class=\"section\">\r\n<table class=\"row-table-01\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tr><th width=\"150\">会社名</th><td>baserCMS inc.  [デモ]</td></tr>\r\n<tr><th>設立</th><td>2009年11月</td></tr>\r\n<tr><th>所在地</th><td>福岡県福岡市博多区博多駅前（ダミー）</td></tr>\r\n<tr><th>事業内容</th><td>インターネットサービス業（ダミー）<br />\r\nWEBサイト制作事業（ダミー）<br />\r\nWEBシステム開発事業（ダミー）</td></tr>\r\n</table>\r\n</div>\r\n\r\n\r\n<h3 class=\"contents-head\">アクセスマップ</h3>\r\n<div class=\"section\">\r\n<?php $bcBaser->element(\"googlemaps\", array(\"width\" => 585)) ?>\r\n</div>',NULL,1,'/about','',1,NULL,NULL,0,'',0,0,NULL,'2013-04-05 10:25:35'),(3,3,'service','サービス','baserCMS inc.のサービス紹介ページ。','<h2 class=\"contents-head\">サービス</h2>\r\n\r\n<div class=\"section\">\r\n<p>\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\n</p>\r\n</div>\r\n\r\n<div class=\"section\">\r\n<p>\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\n</p>\r\n</div>\r\n\r\n<div class=\"section\">\r\n<p>\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\n</p>\r\n</div>',NULL,1,'/service','',1,NULL,NULL,0,'',0,0,NULL,'2013-04-05 10:25:35'),(4,4,'icons','アイコンの使い方','50種類のアイコンを自由にカスタマイズしよう。','<h2>\r\n	アイコンの使い方</h2>\r\n<h3>\r\n	50種類のアイコンを自由にカスタマイズしよう。</h3>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	まずは、<a href=\"http://basercms.net/files/extra/nada-works-png.zip\">nada-works-png.zip</a> をダウンロードして解凍します。</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	icons_ico_.pngをFireworksで開くと下記の50種類のアイコンがレイヤー分けされています。</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_001.png\', array(\'style\' => \'width: 656px; height: 250px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	カスタマイズ1：ベースの形を変える。</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_002.png\', array(\'style\' => \'width: 656px; height: 93px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	カスタマイズ2：色を変える。</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_003.png\', array(\'style\' => \'width: 656px; height: 93px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	カスタマイズ3：パスを使って変形させる。（上級者向け）<br />\r\n	パスで作成しています。自由に変形させることが可能です。</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_004.png\', array(\'style\' => \'width: 193px; height: 186px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	パターン例：各コンテンツで色を変える。同じアイコンを使用する、など</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_005.png\', array(\'style\' => \'width: 656px; height: 215px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	文字と写真を変えるだけで完成！かんたんバナーを作ろう。</h3>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	icons_banner_00.png、icons_banner_l_00.pngをFireworksで開くと各要素をレイヤー分けされています。<br />\r\n	言葉、フォント、色、画像を変更してオリジナルのバナーを作成することができます。<br />\r\n	画像は「シンボル」にて配置しています。差し替えたい画像をシンボル化し、「シンボルを入れ替え」にて差し替えてご使用ください。</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_006.png\', array(\'style\' => \'width: 656px; height: 302px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	例：言葉、フォントの変更、画像差し替え</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_007.png\', array(\'style\' => \'width: 656px; height: 278px;\')) ?></p>',NULL,1,'/icons','',1,NULL,NULL,0,'',0,0,NULL,'2013-04-05 10:25:35'),(5,5,'sitemap','サイトマップ','baserCMS inc.のサイトマップページ','<h2 class=\"contents-head\">サイトマップ</h2>\r\n<?php $bcBaser->sitemap() ?>\r\n<ul class=\"section\">\r\n	<li><?php $bcBaser->link(\"新着情報\",\"/news/index\") ?></li>\r\n	<li><?php $bcBaser->link(\"お問い合わせ\",\"/contact/index\") ?>	</li>\r\n</ul>',NULL,1,'/sitemap','',1,NULL,NULL,0,'',0,0,NULL,'2013-04-05 10:25:35'),(6,6,'index','','','<hr size=\"1\" style=\"width:100%;height:1px;margin:2px 0;padding:0;color:#CCCCCC;background:#CCCCCC;border:1px solid #CCCCCC;\" />\r\n<div style=\"text-align:center;background-color:#8ABE08;\"> <span style=\"color:white;\">メインメニュー</span> </div>\r\n<hr size=\"1\" style=\"width:100%;height:1px;margin:2px 0;padding:0;color:#CCCCCC;background:#CCCCCC;border:1px solid #CCCCCC;\" />\r\n<span style=\"color:#8ABE08\">■</span>\r\n<?php $bcBaser->link(\"ニュースリリース\",array(\"controller\"=>\"news\",\"action\"=>\"index\")) ?>\r\n<br />\r\n<span style=\"color:#8ABE08\">■</span>\r\n<?php $bcBaser->link(\"お問い合わせ\",array(\"controller\"=>\"contact\",\"action\"=>\"index\")) ?>\r\n<hr size=\"1\" style=\"width:100%;height:1px;margin:2px 0;padding:0;color:#CCCCCC;background:#CCCCCC;border:1px solid #CCCCCC;\" />\r\n<div style=\"text-align:center;background-color:#8ABE08;\"> <span style=\"color:white;\">NEWS RELEASE</span> </div>\r\n<hr size=\"1\" style=\"width:100%;height:1px;margin:2px 0;padding:0;color:#CCCCCC;background:#CCCCCC;border:1px solid #CCCCCC;\" />\r\n<?php $bcBaser->blogPosts(\'news\', 5) ?> <div>&nbsp;</div>\r\n<hr size=\"1\" style=\"width:100%;height:1px;margin:2px 0;padding:0;color:#CCCCCC;background:#CCCCCC;border:1px solid #CCCCCC;\" />\r\n<div style=\"text-align:center;background-color:#8ABE08;\"> <span style=\"color:white;\">baserCMS NEWS</span> </div>\r\n<hr size=\"1\" style=\"width:100%;height:1px;margin:2px 0;padding:0;color:#CCCCCC;background:#CCCCCC;border:1px solid #CCCCCC;\" />\r\n<?php $bcBaser->feed(1) ?>',1,1,'/mobile/index','',1,NULL,NULL,0,'',0,0,NULL,'2013-04-05 10:25:35'),(7,7,'index','','','<div id=\"news\" class=\"clearfix\">\r\n<div class=\"news\" style=\"margin-right:28px;\">\r\n<h2 id=\"newsHead01\">NEWS RELEASE</h2>\r\n<div class=\"body\">\r\n<?php $bcBaser->blogPosts(\'news\', 5) ?>\r\n</div>\r\n</div>\r\n<div class=\"news\">\r\n<h2 id=\"newsHead02\">baserCMS NEWS</h2>\r\n<div class=\"body\">\r\n<?php $bcBaser->js(\'/s/feed/ajax/1\') ?>\r\n</div>\r\n</div>\r\n</div>',2,1,'/smartphone/index','',1,NULL,NULL,0,'',0,0,NULL,'2013-04-05 10:25:35'),(8,8,'about','会社案内','baserCMS inc.の会社案内ページ','<h2 class=\"contents-head\">会社案内</h2>\r\n<h3 class=\"contents-head\">会社データ</h3>\r\n<div class=\"section\">\r\n<table class=\"row-table-01\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tr><th width=\"150\">会社名</th><td>baserCMS inc.  [デモ]</td></tr>\r\n<tr><th>設立</th><td>2009年11月</td></tr>\r\n<tr><th>所在地</th><td>福岡県福岡市博多区博多駅前（ダミー）</td></tr>\r\n<tr><th>事業内容</th><td>インターネットサービス業（ダミー）<br />\r\nWEBサイト制作事業（ダミー）<br />\r\nWEBシステム開発事業（ダミー）</td></tr>\r\n</table>\r\n</div>\r\n<h3 class=\"contents-head\">アクセスマップ</h3>\r\n<div class=\"section\">\r\n<?php $bcBaser->element(\"googlemaps\", array(\"width\" => 585)) ?>\r\n</div>',2,1,'/smartphone/about','',1,NULL,NULL,0,'',0,0,NULL,'2013-04-05 10:25:35'),(9,9,'service','サービス','baserCMS inc.のサービス紹介ページ。','<h2 class=\"contents-head\">サービス</h2>\r\n<div class=\"section\">\r\n<p>\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\n</p>\r\n</div>\r\n<div class=\"section\">\r\n<p>\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\n</p>\r\n</div>\r\n<div class=\"section\">\r\n<p>\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\nサービスの案内文がはいります。サービスの案内文がはいります。サービスの案内文がはいります。\r\n</p>\r\n</div>',2,1,'/smartphone/service','',1,NULL,NULL,0,'',0,0,NULL,'2013-04-05 10:25:35'),(10,10,'sitemap','サイトマップ','baserCMS inc.のサイトマップページ','<h2 class=\"contents-head\">サイトマップ</h2>\r\n<?php $bcBaser->sitemap() ?>\r\n<ul class=\"section sitemap\">\r\n	<li><?php $bcBaser->link(\"新着情報\",\"/s/news/index\") ?></li>\r\n	<li><?php $bcBaser->link(\"お問い合わせ\",\"/s/contact/index\") ?>	</li>\r\n</ul>',2,1,'/smartphone/sitemap','',1,NULL,NULL,0,'',0,0,NULL,'2013-04-05 10:25:35'),(11,11,'icons','アイコンの使い方','50種類のアイコンを自由にカスタマイズしよう。','<h2>\r\n	アイコンの使い方</h2>\r\n<h3>\r\n	50種類のアイコンを自由にカスタマイズしよう。</h3>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	まずは、<a href=\"http://basercms.net/files/extra/nada-works-png.zip\">nada-works-png.zip</a> をダウンロードして解凍します。</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	icons_ico_.pngをFireworksで開くと下記の50種類のアイコンがレイヤー分けされています。</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_001.png\', array(\'style\' => \'width: 656px; height: 250px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	カスタマイズ1：ベースの形を変える。</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_002.png\', array(\'style\' => \'width: 656px; height: 93px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	カスタマイズ2：色を変える。</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_003.png\', array(\'style\' => \'width: 656px; height: 93px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	カスタマイズ3：パスを使って変形させる。（上級者向け）<br />\r\n	パスで作成しています。自由に変形させることが可能です。</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_004.png\', array(\'style\' => \'width: 193px; height: 186px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	パターン例：各コンテンツで色を変える。同じアイコンを使用する、など</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_005.png\', array(\'style\' => \'width: 656px; height: 215px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	文字と写真を変えるだけで完成！かんたんバナーを作ろう。</h3>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	icons_banner_00.png、icons_banner_l_00.pngをFireworksで開くと各要素をレイヤー分けされています。<br />\r\n	言葉、フォント、色、画像を変更してオリジナルのバナーを作成することができます。<br />\r\n	画像は「シンボル」にて配置しています。差し替えたい画像をシンボル化し、「シンボルを入れ替え」にて差し替えてご使用ください。</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_006.png\', array(\'style\' => \'width: 656px; height: 302px;\')) ?></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	例：言葉、フォントの変更、画像差し替え</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p style=\"text-align: center;\">\r\n	<?php $bcBaser->img(\'icons/about_007.png\', array(\'style\' => \'width: 656px; height: 278px;\')) ?></p>',2,1,'/smartphone/icons','',1,NULL,NULL,0,'',0,0,NULL,'2013-04-05 10:25:35');
/*!40000 ALTER TABLE `bc_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_permissions`
--

DROP TABLE IF EXISTS `bc_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_permissions` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `no` int(8) DEFAULT NULL,
  `sort` int(8) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_group_id` int(8) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `auth` tinyint(1) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_permissions`
--

LOCK TABLES `bc_permissions` WRITE;
/*!40000 ALTER TABLE `bc_permissions` DISABLE KEYS */;
INSERT INTO `bc_permissions` VALUES (1,1,1,'システム管理',2,'/admin/*',0,1,NULL,'2013-04-05 10:25:35'),(2,2,2,'よく使う項目',2,'/admin/favorites/*',1,1,NULL,'2013-04-05 10:25:35'),(3,3,3,'ページ管理',2,'/admin/pages/*',1,1,NULL,'2013-04-05 10:25:35'),(4,4,4,'ページテンプレート読込・書出',2,'/admin/pages/*_page_files',0,1,NULL,'2013-04-05 10:25:35'),(5,5,5,'ページカテゴリ管理',2,'/admin/page_categories/*',1,1,NULL,'2013-04-05 10:25:35'),(6,6,6,'新着情報基本設定',2,'/admin/blog/blog_contents/edit/1',1,1,NULL,'2013-04-05 10:25:35'),(7,7,7,'新着情報記事管理',2,'/admin/blog/blog_posts/*/1/*',1,1,NULL,'2013-04-05 10:25:35'),(8,8,8,'新着情報記事プレビュー',2,'/admin/blog/preview/1/*',1,1,NULL,'2013-04-05 10:25:35'),(9,9,9,'新着情報カテゴリ管理',2,'/admin/blog/blog_categories/*/1/*',1,1,NULL,'2013-04-05 10:25:35'),(10,10,10,'新着情報コメント一覧',2,'/admin/blog/blog_comments/*/1/*',1,1,NULL,'2013-04-05 10:25:35'),(11,11,11,'ブログタグ管理',2,'/admin/blog/blog_tags/*',1,1,NULL,'2013-04-05 10:25:35'),(12,12,12,'お問い合わせ基本設定',2,'/admin/mail/mail_contents/edit/1',1,1,NULL,'2013-04-05 10:25:35'),(13,13,13,'お問い合わせ管理',2,'/admin/mail/mail_fields/*/1/*',1,1,NULL,'2013-04-05 10:25:35'),(14,14,14,'お問い合わせ受信メール一覧',2,'/admin/mail/mail_messages/*/1/*',1,1,NULL,'2013-04-05 10:25:35'),(15,15,15,'エディタテンプレート呼出',2,'/admin/editor_template/js',1,1,NULL,'2013-04-05 10:25:35');
/*!40000 ALTER TABLE `bc_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_blog_categories`
--

DROP TABLE IF EXISTS `bc_pg_blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_blog_categories` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `blog_content_id` int(8) NOT NULL,
  `no` int(8) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `parent_id` int(8) DEFAULT NULL,
  `lft` int(8) DEFAULT NULL,
  `rght` int(8) DEFAULT NULL,
  `owner_id` int(8) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_blog_categories`
--

LOCK TABLES `bc_pg_blog_categories` WRITE;
/*!40000 ALTER TABLE `bc_pg_blog_categories` DISABLE KEYS */;
INSERT INTO `bc_pg_blog_categories` VALUES (1,1,1,'release','プレスリリース',1,NULL,1,2,NULL,'2013-04-05 10:25:36',NULL);
/*!40000 ALTER TABLE `bc_pg_blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_blog_comments`
--

DROP TABLE IF EXISTS `bc_pg_blog_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_blog_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_content_id` int(8) NOT NULL,
  `blog_post_id` int(8) NOT NULL,
  `no` int(11) NOT NULL,
  `status` int(2) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `message` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_blog_comments`
--

LOCK TABLES `bc_pg_blog_comments` WRITE;
/*!40000 ALTER TABLE `bc_pg_blog_comments` DISABLE KEYS */;
INSERT INTO `bc_pg_blog_comments` VALUES (1,1,1,1,1,'baserCMS','','http://basercms.net','ホームページの開設おめでとうございます。（ダミー）','2013-04-05 10:25:36',NULL);
/*!40000 ALTER TABLE `bc_pg_blog_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_blog_configs`
--

DROP TABLE IF EXISTS `bc_pg_blog_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_blog_configs` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_blog_configs`
--

LOCK TABLES `bc_pg_blog_configs` WRITE;
/*!40000 ALTER TABLE `bc_pg_blog_configs` DISABLE KEYS */;
/*!40000 ALTER TABLE `bc_pg_blog_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_blog_contents`
--

DROP TABLE IF EXISTS `bc_pg_blog_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_blog_contents` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `layout` varchar(20) DEFAULT NULL,
  `template` varchar(20) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `list_count` int(4) DEFAULT NULL,
  `list_direction` varchar(4) DEFAULT NULL,
  `feed_count` int(4) DEFAULT NULL,
  `tag_use` tinyint(1) DEFAULT NULL,
  `comment_use` int(2) DEFAULT NULL,
  `comment_approve` int(2) DEFAULT NULL,
  `auth_captcha` tinyint(1) DEFAULT NULL,
  `widget_area` int(4) DEFAULT NULL,
  `exclude_search` tinyint(1) DEFAULT NULL,
  `eye_catch_size` text,
  `use_content` tinyint(1) DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_blog_contents`
--

LOCK TABLES `bc_pg_blog_contents` WRITE;
/*!40000 ALTER TABLE `bc_pg_blog_contents` DISABLE KEYS */;
INSERT INTO `bc_pg_blog_contents` VALUES (1,'news','新着情報','baserCMS inc. [デモ] の最新の情報をお届けします。','default','default',1,10,'DESC',10,1,1,0,1,2,0,'a:4:{s:11:\"thumb_width\";s:3:\"300\";s:12:\"thumb_height\";s:3:\"300\";s:18:\"mobile_thumb_width\";s:3:\"100\";s:19:\"mobile_thumb_height\";s:3:\"100\";}',1,'2013-04-05 10:25:36',NULL);
/*!40000 ALTER TABLE `bc_pg_blog_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_blog_posts`
--

DROP TABLE IF EXISTS `bc_pg_blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_blog_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_content_id` int(8) NOT NULL,
  `no` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` text,
  `detail` text,
  `blog_category_id` int(8) DEFAULT NULL,
  `user_id` int(8) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `posts_date` datetime DEFAULT NULL,
  `content_draft` text,
  `detail_draft` text,
  `publish_begin` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `exclude_search` tinyint(1) DEFAULT NULL,
  `eye_catch` varchar(30) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_blog_posts`
--

LOCK TABLES `bc_pg_blog_posts` WRITE;
/*!40000 ALTER TABLE `bc_pg_blog_posts` DISABLE KEYS */;
INSERT INTO `bc_pg_blog_posts` VALUES (1,1,1,'ホームページをオープンしました','本文が入ります。本文が入ります。本文が入ります。本文が入ります。本文が入ります。本文が入ります。本文が入ります。本文が入ります。本文が入ります。<br /><br />本文が入ります。本文が入ります。本文が入ります。本文が入ります。本文が入ります。本文が入ります。本文が入ります。本文が入ります。本文が入ります。<br /><br />','詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。<br /><br />詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。\r\n',1,1,1,'2013-04-05 10:25:50','','',NULL,NULL,0,'','2013-04-05 10:25:36','2013-04-05 10:25:50'),(2,1,2,'新商品を販売を開始しました。','新商品を販売を開始しました。新商品を販売を開始しました。新商品を販売を開始しました。新商品を販売を開始しました。<br /><br />新商品を販売を開始しました。新商品を販売を開始しました。新商品を販売を開始しました。新商品を販売を開始しました。<br />','詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。<br /><br />詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。<br /><br />\r\n詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。詳細が入ります。<br />\r\n<br />',1,1,1,'2013-04-05 10:25:50','','',NULL,NULL,0,'','2013-04-05 10:25:36','2013-04-05 10:25:50');
/*!40000 ALTER TABLE `bc_pg_blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_blog_posts_blog_tags`
--

DROP TABLE IF EXISTS `bc_pg_blog_posts_blog_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_blog_posts_blog_tags` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `blog_post_id` int(8) NOT NULL,
  `blog_tag_id` int(8) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_blog_posts_blog_tags`
--

LOCK TABLES `bc_pg_blog_posts_blog_tags` WRITE;
/*!40000 ALTER TABLE `bc_pg_blog_posts_blog_tags` DISABLE KEYS */;
INSERT INTO `bc_pg_blog_posts_blog_tags` VALUES (1,2,1,'2013-04-05 10:25:36',NULL);
/*!40000 ALTER TABLE `bc_pg_blog_posts_blog_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_blog_tags`
--

DROP TABLE IF EXISTS `bc_pg_blog_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_blog_tags` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_blog_tags`
--

LOCK TABLES `bc_pg_blog_tags` WRITE;
/*!40000 ALTER TABLE `bc_pg_blog_tags` DISABLE KEYS */;
INSERT INTO `bc_pg_blog_tags` VALUES (1,'新製品','2013-04-05 10:25:36',NULL);
/*!40000 ALTER TABLE `bc_pg_blog_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_contact_messages`
--

DROP TABLE IF EXISTS `bc_pg_contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_1` varchar(255) DEFAULT NULL,
  `name_2` varchar(255) DEFAULT NULL,
  `name_kana_1` varchar(255) DEFAULT NULL,
  `name_kana_2` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `email_1` varchar(255) DEFAULT NULL,
  `email_2` varchar(255) DEFAULT NULL,
  `tel_1` varchar(255) DEFAULT NULL,
  `tel_2` varchar(255) DEFAULT NULL,
  `tel_3` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `address_1` varchar(255) DEFAULT NULL,
  `address_2` varchar(255) DEFAULT NULL,
  `address_3` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `message` text,
  `root` varchar(255) DEFAULT NULL,
  `root_etc` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_contact_messages`
--

LOCK TABLES `bc_pg_contact_messages` WRITE;
/*!40000 ALTER TABLE `bc_pg_contact_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `bc_pg_contact_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_feed_configs`
--

DROP TABLE IF EXISTS `bc_pg_feed_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_feed_configs` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `feed_title_index` varchar(255) DEFAULT NULL,
  `category_index` varchar(255) DEFAULT NULL,
  `template` varchar(50) DEFAULT NULL,
  `display_number` int(3) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_feed_configs`
--

LOCK TABLES `bc_pg_feed_configs` WRITE;
/*!40000 ALTER TABLE `bc_pg_feed_configs` DISABLE KEYS */;
INSERT INTO `bc_pg_feed_configs` VALUES (1,'baserCMSニュース','','','default',5,'2013-04-05 10:25:36',NULL);
/*!40000 ALTER TABLE `bc_pg_feed_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_feed_details`
--

DROP TABLE IF EXISTS `bc_pg_feed_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_feed_details` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `feed_config_id` int(8) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `category_filter` varchar(255) DEFAULT NULL,
  `cache_time` varchar(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_feed_details`
--

LOCK TABLES `bc_pg_feed_details` WRITE;
/*!40000 ALTER TABLE `bc_pg_feed_details` DISABLE KEYS */;
INSERT INTO `bc_pg_feed_details` VALUES (1,1,'baserCMSニュース','http://basercms.net/news/index.rss','','+30 minutes','2013-04-05 10:25:36',NULL);
/*!40000 ALTER TABLE `bc_pg_feed_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_mail_configs`
--

DROP TABLE IF EXISTS `bc_pg_mail_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_mail_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(50) DEFAULT NULL,
  `site_url` varchar(255) DEFAULT NULL,
  `site_email` varchar(50) DEFAULT NULL,
  `site_tel` varchar(20) DEFAULT NULL,
  `site_fax` varchar(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_mail_configs`
--

LOCK TABLES `bc_pg_mail_configs` WRITE;
/*!40000 ALTER TABLE `bc_pg_mail_configs` DISABLE KEYS */;
INSERT INTO `bc_pg_mail_configs` VALUES (1,'baserCMS - Based Website Development Project -','http://basercms.net/','info@basercms.net','','','2013-04-05 10:25:36',NULL);
/*!40000 ALTER TABLE `bc_pg_mail_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_mail_contents`
--

DROP TABLE IF EXISTS `bc_pg_mail_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_mail_contents` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `sender_1` varchar(255) DEFAULT NULL,
  `sender_2` varchar(255) DEFAULT NULL,
  `sender_name` varchar(50) DEFAULT NULL,
  `subject_user` varchar(50) DEFAULT NULL,
  `subject_admin` varchar(50) DEFAULT NULL,
  `layout_template` varchar(20) DEFAULT NULL,
  `form_template` varchar(20) DEFAULT NULL,
  `mail_template` varchar(20) DEFAULT NULL,
  `redirect_url` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `auth_captcha` tinyint(1) DEFAULT NULL,
  `widget_area` int(4) DEFAULT NULL,
  `ssl_on` tinyint(1) DEFAULT '0',
  `exclude_search` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_mail_contents`
--

LOCK TABLES `bc_pg_mail_contents` WRITE;
/*!40000 ALTER TABLE `bc_pg_mail_contents` DISABLE KEYS */;
INSERT INTO `bc_pg_mail_contents` VALUES (1,'contact','お問い合わせ','<p><span style=\"color:#C30\">*</span> 印の項目は必須となりますので、必ず入力してください。</p>','','','baserCMS inc. [デモ]　お問い合わせ','【baserCMS】お問い合わせ頂きありがとうございます。','【baserCMS】お問い合わせを受け付けました','default','default','mail_default','http://basercms.net/',1,1,NULL,0,0,'2013-04-05 10:25:36',NULL);
/*!40000 ALTER TABLE `bc_pg_mail_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_mail_fields`
--

DROP TABLE IF EXISTS `bc_pg_mail_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_mail_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail_content_id` int(11) DEFAULT NULL,
  `no` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `field_name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `head` varchar(255) DEFAULT NULL,
  `attention` varchar(255) DEFAULT NULL,
  `before_attachment` varchar(255) DEFAULT NULL,
  `after_attachment` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `rows` int(11) DEFAULT NULL,
  `maxlength` int(11) DEFAULT NULL,
  `options` varchar(255) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  `separator` varchar(20) DEFAULT NULL,
  `default_value` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `group_field` varchar(255) DEFAULT NULL,
  `group_valid` varchar(255) DEFAULT NULL,
  `valid` varchar(255) DEFAULT NULL,
  `valid_ex` varchar(255) DEFAULT NULL,
  `auto_convert` varchar(255) DEFAULT NULL,
  `not_empty` tinyint(1) DEFAULT NULL,
  `use_field` tinyint(1) DEFAULT NULL,
  `no_send` tinyint(1) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_mail_fields`
--

LOCK TABLES `bc_pg_mail_fields` WRITE;
/*!40000 ALTER TABLE `bc_pg_mail_fields` DISABLE KEYS */;
INSERT INTO `bc_pg_mail_fields` VALUES (1,1,1,'姓漢字','name_1','text','お名前','','<small>[姓]</small>','','',8,NULL,255,'','','','','','name','name','VALID_NOT_EMPTY','','',1,1,0,1,'2013-04-05 10:25:36',NULL),(2,1,2,'名漢字','name_2','text','お名前','','<small>[名]</small>','','',8,NULL,255,'','','','','','name','name','VALID_NOT_EMPTY','','',1,1,0,2,'2013-04-05 10:25:36',NULL),(3,1,3,'姓カナ','name_kana_1','text','フリガナ','','<small>[姓]</small>','','',8,NULL,255,'','','','','','name_kana','name_kana','','','',0,1,0,3,'2013-04-05 10:25:36',NULL),(4,1,4,'名カナ','name_kana_2','text','フリガナ','','<small>[名]</small>','','',8,NULL,255,'','','','','','name_kana','name_kana','','','',0,1,0,4,'2013-04-05 10:25:36',NULL),(5,1,5,'性別','sex','radio','性別','','','','男性|女性',0,0,0,'','','','','','','','','','',0,1,0,5,'2013-04-05 10:25:36',NULL),(6,1,7,'メールアドレス','email_1','email','メールアドレス','','','<br />','',25,NULL,50,'','','','','<small>確認の為、２回入力して下さい。</small><br />','email','email','VALID_EMAIL','VALID_EMAIL_CONFIRM','',1,1,0,6,'2013-04-05 10:25:36',NULL),(7,1,8,'メールアドレス確認','email_2','text','メールアドレス（確認）','<small>[確認]</small>','','','',25,NULL,50,'','','','','','email','email','VALID_EMAIL','VALID_EMAIL_CONFIRM','',1,1,1,7,'2013-04-05 10:25:36',NULL),(8,1,9,'電話番号１','tel_1','text','電話番号','','','-','',5,0,5,'','','','','','tel','tel','','VALID_GROUP_COMPLATE','CONVERT_HANKAKU',0,1,0,8,'2013-04-05 10:25:36',NULL),(9,1,10,'電話番号２','tel_2','text','電話番号','','','-','',5,0,5,'','','','','','tel','tel','','VALID_GROUP_COMPLATE','CONVERT_HANKAKU',0,1,0,9,'2013-04-05 10:25:36',NULL),(10,1,11,'電話番号３','tel_3','text','電話番号','','','','',5,0,5,'','','','','','tel','tel','','VALID_GROUP_COMPLATE','CONVERT_HANKAKU',0,1,0,10,'2013-04-05 10:25:36',NULL),(11,1,12,'郵便番号','zip','autozip','住所','<small>[半角数字]</small><br />','〒','','address_1|address_2',10,NULL,8,'','','','','','address','','','','CONVERT_HANKAKU',0,1,0,11,'2013-04-05 10:25:36',NULL),(12,1,13,'都道府県','address_1','pref','住所','','','<br />','',0,0,0,'','','','','','address','','','','',0,1,0,12,'2013-04-05 10:25:36',NULL),(13,1,14,'市区町村・番地','address_2','text','住所','','','<br />','',30,0,200,'','','','','','address','','','','',0,1,0,13,'2013-04-05 10:25:36',NULL),(14,1,15,'建物名','address_3','text','住所','','','','',30,0,200,'','','','','','address','','','','',0,1,0,14,'2013-04-05 10:25:36',NULL),(15,1,16,'お問い合わせ項目','category','multi_check','お問い合わせ項目','','','','資料請求|問い合わせ|その他',0,0,0,'','','','','','','','','VALID_NOT_UNCHECKED','',1,1,0,15,'2013-04-05 10:25:36',NULL),(16,1,17,'お問い合わせ内容','message','textarea','お問い合わせ内容','','','','',48,12,NULL,'','','','','','','','','','',0,1,0,16,'2013-04-05 10:25:36',NULL),(17,1,18,'ルート','root','select','どうやってこのサイトをお知りになりましたか？','','','<br />','検索エンジン|web広告|紙面広告|求人案内|その他',0,0,0,'','','','','','root','','VALID_NOT_EMPTY','','',1,1,0,17,'2013-04-05 10:25:36',NULL),(18,1,19,'ルートその他','root_etc','text','','<br /><small>その他を選択された場合は内容をご入力下さい。</small>','','','',30,NULL,50,'','','','','','root','','','','',0,1,0,18,'2013-04-05 10:25:36',NULL);
/*!40000 ALTER TABLE `bc_pg_mail_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_messages`
--

DROP TABLE IF EXISTS `bc_pg_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_messages`
--

LOCK TABLES `bc_pg_messages` WRITE;
/*!40000 ALTER TABLE `bc_pg_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `bc_pg_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_twitter_configs`
--

DROP TABLE IF EXISTS `bc_pg_twitter_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_twitter_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_twitter_configs`
--

LOCK TABLES `bc_pg_twitter_configs` WRITE;
/*!40000 ALTER TABLE `bc_pg_twitter_configs` DISABLE KEYS */;
INSERT INTO `bc_pg_twitter_configs` VALUES (1,'consumer_key','Ms83i4onvRtIpuiCRCCa7A','2013-04-05 10:27:21',NULL),(2,'consumer_secret','91r0eu3uMQDQkBPzEPTcPQZqjIZR37QiCuCdFbwE','2013-04-05 10:27:21',NULL),(3,'access_token_key','','2013-04-05 10:27:21',NULL),(4,'access_token_secret','','2013-04-05 10:27:21',NULL),(5,'username','','2013-04-05 10:27:21',NULL),(6,'view_num','3','2013-04-05 10:27:21',NULL),(7,'tweet_settings','a:1:{i:0;a:7:{s:2:\"id\";i:1;s:4:\"name\";s:15:\"ブログ記事\";s:6:\"plugin\";s:4:\"blog\";s:10:\"controller\";s:10:\"blog_posts\";s:6:\"action\";s:10:\"admin_edit\";s:15:\"status_template\";s:4:\"blog\";s:6:\"status\";s:1:\"1\";}}','2013-04-05 10:27:21',NULL);
/*!40000 ALTER TABLE `bc_pg_twitter_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_uploader_categories`
--

DROP TABLE IF EXISTS `bc_pg_uploader_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_uploader_categories` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_uploader_categories`
--

LOCK TABLES `bc_pg_uploader_categories` WRITE;
/*!40000 ALTER TABLE `bc_pg_uploader_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `bc_pg_uploader_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_uploader_configs`
--

DROP TABLE IF EXISTS `bc_pg_uploader_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_uploader_configs` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_uploader_configs`
--

LOCK TABLES `bc_pg_uploader_configs` WRITE;
/*!40000 ALTER TABLE `bc_pg_uploader_configs` DISABLE KEYS */;
INSERT INTO `bc_pg_uploader_configs` VALUES (1,'large_width','500','2013-04-05 10:27:24',NULL),(2,'large_height','500','2013-04-05 10:27:24',NULL),(3,'midium_width','300','2013-04-05 10:27:24',NULL),(4,'midium_height','300','2013-04-05 10:27:24',NULL),(5,'small_width','150','2013-04-05 10:27:24',NULL),(6,'small_height','150','2013-04-05 10:27:24',NULL),(7,'small_thumb','1','2013-04-05 10:27:24',NULL),(8,'mobile_large_width','240','2013-04-05 10:27:24',NULL),(9,'mobile_large_height','240','2013-04-05 10:27:24',NULL),(10,'mobile_small_width','100','2013-04-05 10:27:24',NULL),(11,'mobile_small_height','100','2013-04-05 10:27:24',NULL),(12,'mobile_small_thumb','1','2013-04-05 10:27:24',NULL),(13,'use_permission','0','2013-04-05 10:27:24',NULL),(14,'layout_type','panel','2013-04-05 10:27:24',NULL);
/*!40000 ALTER TABLE `bc_pg_uploader_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_pg_uploader_files`
--

DROP TABLE IF EXISTS `bc_pg_uploader_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_pg_uploader_files` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `alt` text,
  `uploader_category_id` int(8) DEFAULT NULL,
  `user_id` int(8) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_pg_uploader_files`
--

LOCK TABLES `bc_pg_uploader_files` WRITE;
/*!40000 ALTER TABLE `bc_pg_uploader_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `bc_pg_uploader_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_plugin_contents`
--

DROP TABLE IF EXISTS `bc_plugin_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_plugin_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_id` int(8) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `plugin` varchar(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_plugin_contents`
--

LOCK TABLES `bc_plugin_contents` WRITE;
/*!40000 ALTER TABLE `bc_plugin_contents` DISABLE KEYS */;
INSERT INTO `bc_plugin_contents` VALUES (1,1,'news','blog','2013-04-05 10:25:35',NULL),(2,1,'contact','mail','2013-04-05 10:25:35',NULL);
/*!40000 ALTER TABLE `bc_plugin_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_plugins`
--

DROP TABLE IF EXISTS `bc_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_plugins` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `version` varchar(20) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `db_inited` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_plugins`
--

LOCK TABLES `bc_plugins` WRITE;
/*!40000 ALTER TABLE `bc_plugins` DISABLE KEYS */;
INSERT INTO `bc_plugins` VALUES (1,'blog','ブログ','2.1.0',1,1,'2013-04-05 10:25:50','2013-04-05 10:25:50'),(2,'feed','フィードリーダー','2.1.0',1,1,'2013-04-05 10:25:50','2013-04-05 10:25:50'),(3,'mail','メールフォーム','2.1.0',1,1,'2013-04-05 10:25:50','2013-04-05 10:25:50'),(4,'twitter','ツイッター','2.1.0',1,1,'2013-04-05 10:27:21','2013-04-05 10:27:21'),(5,'uploader','アップローダー','2.1.0',1,1,'2013-04-05 10:27:24','2013-04-05 10:27:24');
/*!40000 ALTER TABLE `bc_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_site_configs`
--

DROP TABLE IF EXISTS `bc_site_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_site_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_site_configs`
--

LOCK TABLES `bc_site_configs` WRITE;
/*!40000 ALTER TABLE `bc_site_configs` DISABLE KEYS */;
INSERT INTO `bc_site_configs` VALUES (1,'name','baserCMS inc. [デモ]','2013-04-05 10:25:35','2013-04-05 10:25:50'),(2,'keyword','baser,CMS,コンテンツマネジメントシステム,開発支援','2013-04-05 10:25:35','2013-04-05 10:25:50'),(3,'description','baserCMS は、CakePHPを利用し、環境準備の素早さに重点を置いた基本開発支援プロジェクトです。WEBサイトに最低限必要となるプラグイン、そしてそのプラグインを組み込みやすい管理画面、認証付きのメンバーマイページを最初から装備しています。','2013-04-05 10:25:35','2013-04-05 10:25:50'),(4,'address','福岡県','2013-04-05 10:25:35','2013-04-05 10:25:50'),(5,'theme','nada-icons','2013-04-05 10:25:35','2013-04-05 10:25:50'),(6,'email','admin@example.com','2013-04-05 10:25:35','2013-04-05 10:25:50'),(7,'widget_area','1','2013-04-05 10:25:35','2013-04-05 10:25:50'),(8,'maintenance','0','2013-04-05 10:25:35','2013-04-05 10:25:50'),(9,'mail_encode','UTF-8','2013-04-05 10:25:35','2013-04-05 10:25:50'),(10,'smtp_host','','2013-04-05 10:25:35','2013-04-05 10:25:50'),(11,'smtp_user','','2013-04-05 10:25:35','2013-04-05 10:25:50'),(12,'smtp_password','','2013-04-05 10:25:35','2013-04-05 10:25:50'),(13,'smtp_port','','2013-04-05 10:25:35','2013-04-05 10:25:50'),(14,'formal_name','baserCMS inc. [デモ]','2013-04-05 10:25:35','2013-04-05 10:25:50'),(15,'admin_list_num','10','2013-04-05 10:25:35','2013-04-05 10:25:50'),(16,'google_analytics_id',NULL,'2013-04-05 10:25:35','2013-04-05 10:25:50'),(17,'content_categories','a:0:{}','2013-04-05 10:25:35','2013-04-05 10:25:51'),(18,'content_types','a:3:{s:9:\"ブログ\";s:9:\"ブログ\";s:9:\"ページ\";s:9:\"ページ\";s:9:\"メール\";s:9:\"メール\";}','2013-04-05 10:25:35','2013-04-05 10:25:51'),(19,'root_owner_id','','2013-04-05 10:25:35','2013-04-05 10:25:50'),(20,'category_permission','','2013-04-05 10:25:35','2013-04-05 10:25:50'),(21,'admin_theme','','2013-04-05 10:25:35','2013-04-05 10:25:50'),(22,'login_credit','1','2013-04-05 10:25:35','2013-04-05 10:25:50'),(23,'first_access','','2013-04-05 10:25:35','2013-04-05 10:25:54'),(24,'editor_styles','#青見出し\nh3 {\n	color:Blue;\n}\n#赤見出し\nh3 {\n	color:Red;\n}\n#黄マーカー\nspan {\n	background-color:Yellow;\n}\n#緑マーカー\nspan {\n	background-color:Lime;\n}\n#大文字\nbig {}\n#小文字\nsmall {}\n#コード\ncode {}\n#削除文\ndel {}\n#挿入文\nins {}\n#引用\ncite {}\n#インライン\nq {}','2013-04-05 10:25:35','2013-04-05 10:25:50'),(25,'editor_enter_br','','2013-04-05 10:25:35','2013-04-05 10:25:50'),(26,'root_layout_template','default','2013-04-05 10:25:35','2013-04-05 10:25:50'),(27,'root_layout_template_mobile','default','2013-04-05 10:25:35','2013-04-05 10:25:50'),(28,'root_layout_template_smartphone','default','2013-04-05 10:25:35','2013-04-05 10:25:50'),(29,'root_content_template','default','2013-04-05 10:25:35','2013-04-05 10:25:50'),(30,'root_content_template_mobile','default','2013-04-05 10:25:35','2013-04-05 10:25:50'),(31,'root_content_template_smartphone','default','2013-04-05 10:25:35','2013-04-05 10:25:50'),(32,'linked_pages_mobile','0','2013-04-05 10:25:35','2013-04-05 10:25:50'),(33,'linked_pages_smartphone','0','2013-04-05 10:25:35','2013-04-05 10:25:50'),(34,'version','2.1.0','2013-04-05 10:25:50','2013-04-05 10:25:50');
/*!40000 ALTER TABLE `bc_site_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_user_groups`
--

DROP TABLE IF EXISTS `bc_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_user_groups` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `auth_prefix` varchar(20) DEFAULT NULL,
  `use_admin_globalmenu` tinyint(1) NOT NULL DEFAULT '1',
  `default_favorites` text,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_user_groups`
--

LOCK TABLES `bc_user_groups` WRITE;
/*!40000 ALTER TABLE `bc_user_groups` DISABLE KEYS */;
INSERT INTO `bc_user_groups` VALUES (1,'admins','システム管理','admin',1,'a:6:{i:0;a:2:{s:4:\"name\";s:21:\"固定ページ管理\";s:3:\"url\";s:18:\"/admin/pages/index\";}i:1;a:2:{s:4:\"name\";s:18:\"新着情報管理\";s:3:\"url\";s:30:\"/admin/blog/blog_posts/index/1\";}i:2;a:2:{s:4:\"name\";s:24:\"お問い合わせ管理\";s:3:\"url\";s:31:\"/admin/mail/mail_fields/index/1\";}i:3;a:2:{s:4:\"name\";s:21:\"受信メール一覧\";s:3:\"url\";s:33:\"/admin/mail/mail_messages/index/1\";}i:4;a:2:{s:4:\"name\";s:18:\"コメント一覧\";s:3:\"url\";s:33:\"/admin/blog/blog_comments/index/1\";}i:5;a:2:{s:4:\"name\";s:15:\"クレジット\";s:3:\"url\";s:20:\"javascript:credit();\";}}',NULL,'2013-04-05 10:25:37'),(2,'operators','サイト運営','admin',0,'a:5:{i:0;a:2:{s:4:\"name\";s:21:\"固定ページ管理\";s:3:\"url\";s:18:\"/admin/pages/index\";}i:1;a:2:{s:4:\"name\";s:18:\"新着情報管理\";s:3:\"url\";s:30:\"/admin/blog/blog_posts/index/1\";}i:2;a:2:{s:4:\"name\";s:24:\"お問い合わせ管理\";s:3:\"url\";s:31:\"/admin/mail/mail_fields/index/1\";}i:3;a:2:{s:4:\"name\";s:21:\"受信メール一覧\";s:3:\"url\";s:33:\"/admin/mail/mail_messages/index/1\";}i:4;a:2:{s:4:\"name\";s:18:\"コメント一覧\";s:3:\"url\";s:33:\"/admin/blog/blog_comments/index/1\";}}',NULL,'2013-04-05 10:25:36');
/*!40000 ALTER TABLE `bc_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_users`
--

DROP TABLE IF EXISTS `bc_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `real_name_1` varchar(50) DEFAULT NULL,
  `real_name_2` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_group_id` int(4) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_users`
--

LOCK TABLES `bc_users` WRITE;
/*!40000 ALTER TABLE `bc_users` DISABLE KEYS */;
INSERT INTO `bc_users` VALUES (1,'admin','aa0eda4317c957d9db214eb6fdb74d403c38cfd7','admin',NULL,'admin@example.com',1,NULL,'2013-04-05 10:25:49','2013-04-05 10:25:49');
/*!40000 ALTER TABLE `bc_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bc_widget_areas`
--

DROP TABLE IF EXISTS `bc_widget_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bc_widget_areas` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `widgets` text,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bc_widget_areas`
--

LOCK TABLES `bc_widget_areas` WRITE;
/*!40000 ALTER TABLE `bc_widget_areas` DISABLE KEYS */;
INSERT INTO `bc_widget_areas` VALUES (1,'標準サイドバー','a:1:{i:0;a:1:{s:7:\"Widget1\";a:9:{s:2:\"id\";s:1:\"1\";s:4:\"type\";s:12:\"テキスト\";s:7:\"element\";s:4:\"text\";s:6:\"plugin\";s:0:\"\";s:4:\"sort\";i:1;s:4:\"name\";s:9:\"リンク\";s:4:\"text\";s:358:\"<p style=\"margin-bottom:20px;text-align: center\"> <a href=\"http://basercms.net\" target=\"_blank\"><img src=\"http://basercms.net/img/bnr_basercms.jpg\" alt=\"コーポレートサイトにちょうどいいCMS、baserCMS\"/></a></p><p class=\"customize-navi corner10\"><small>この部分は、ウィジェットエリア管理より編集できます。</small></p>\";s:9:\"use_title\";s:1:\"1\";s:6:\"status\";s:1:\"1\";}}}',NULL,'2013-04-05 10:25:36'),(2,'ブログサイドバー','a:4:{i:0;a:1:{s:7:\"Widget1\";a:9:{s:2:\"id\";s:1:\"1\";s:4:\"type\";s:24:\"ブログカレンダー\";s:7:\"element\";s:13:\"blog_calendar\";s:6:\"plugin\";s:4:\"blog\";s:4:\"sort\";i:1;s:4:\"name\";s:24:\"ブログカレンダー\";s:15:\"blog_content_id\";s:1:\"1\";s:9:\"use_title\";s:1:\"0\";s:6:\"status\";s:1:\"1\";}}i:1;a:1:{s:7:\"Widget2\";a:10:{s:2:\"id\";s:1:\"2\";s:4:\"type\";s:30:\"ブログカテゴリー一覧\";s:7:\"element\";s:22:\"blog_category_archives\";s:6:\"plugin\";s:4:\"blog\";s:4:\"sort\";i:2;s:4:\"name\";s:21:\"カテゴリー一覧\";s:5:\"count\";s:1:\"1\";s:15:\"blog_content_id\";s:1:\"1\";s:9:\"use_title\";s:1:\"1\";s:6:\"status\";s:1:\"1\";}}i:2;a:1:{s:7:\"Widget3\";a:11:{s:2:\"id\";s:1:\"3\";s:4:\"type\";s:27:\"月別アーカイブ一覧\";s:7:\"element\";s:21:\"blog_monthly_archives\";s:6:\"plugin\";s:4:\"blog\";s:4:\"sort\";i:3;s:4:\"name\";s:27:\"月別アーカイブ一覧\";s:5:\"count\";s:2:\"12\";s:10:\"view_count\";s:1:\"1\";s:15:\"blog_content_id\";s:1:\"1\";s:9:\"use_title\";s:1:\"1\";s:6:\"status\";s:1:\"1\";}}i:3;a:1:{s:7:\"Widget4\";a:10:{s:2:\"id\";s:1:\"4\";s:4:\"type\";s:15:\"最近の投稿\";s:7:\"element\";s:19:\"blog_recent_entries\";s:6:\"plugin\";s:4:\"blog\";s:4:\"sort\";i:4;s:4:\"name\";s:15:\"最近の投稿\";s:5:\"count\";s:1:\"5\";s:15:\"blog_content_id\";s:1:\"1\";s:9:\"use_title\";s:1:\"1\";s:6:\"status\";s:1:\"1\";}}}',NULL,'2013-04-05 10:25:36');
/*!40000 ALTER TABLE `bc_widget_areas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-04-05 10:27:43
