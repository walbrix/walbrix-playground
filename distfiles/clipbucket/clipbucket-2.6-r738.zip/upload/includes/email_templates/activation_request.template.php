
					<?php 
					$body ="Hello $username,

Your Activation Code is : $avcode
<a href=$baseurl/activation.php>Click Here</a> To Goto Activation Page

Direct Activation
==========================================
<a href=$baseurl/activation.php?username=$username&avcode=$avcode>Click Here</a> or Copy & Paste the following link in your browser
$baseurl/activation.php?username=$username&avcode=$avcode
" 
					?>
					