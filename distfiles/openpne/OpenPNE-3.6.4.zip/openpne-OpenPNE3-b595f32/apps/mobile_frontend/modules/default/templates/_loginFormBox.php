<?php foreach ($forms as $form) : ?>

<?php include_login_parts('Login', $form, 'member/login'); ?>

<?php endforeach; ?>
