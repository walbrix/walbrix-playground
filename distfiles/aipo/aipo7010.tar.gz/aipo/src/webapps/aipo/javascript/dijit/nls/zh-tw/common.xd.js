dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.zh-tw.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.zh-tw.common");dojo._xdLoadFlattenedBundle("dijit", "common", "zh-tw", {"buttonCancel": "取消", "buttonSave": "儲存", "buttonOk": "確定"});
}});