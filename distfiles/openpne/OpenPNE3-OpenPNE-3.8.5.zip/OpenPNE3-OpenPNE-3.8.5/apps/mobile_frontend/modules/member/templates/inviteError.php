<?php op_mobile_page_title(__('Invite friends for %1%', array('%1%' => $op_config['sns_name']))) ?>
<?php echo __('Invite is not available.') ?>
