<?php	

defined('C5_EXECUTE') or die("Access Denied.");
class Update extends Concrete5_Library_Update {}
class ApplicationUpdate extends Concrete5_Library_ApplicationUpdate {}