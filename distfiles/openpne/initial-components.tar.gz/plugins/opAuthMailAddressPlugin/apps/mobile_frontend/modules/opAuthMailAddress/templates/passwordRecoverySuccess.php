<?php op_mobile_page_title(__('Password Recovery')) ?>

<?php echo op_include_form('passwordRecovery', $form) ?>
