dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.ru.validate"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.ru.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "ru", {"rangeMessage": "* Это значение вне диапазона.", "invalidMessage": "* Указано недопустимое значение.", "missingMessage": "* Это обязательное значение."});
}});