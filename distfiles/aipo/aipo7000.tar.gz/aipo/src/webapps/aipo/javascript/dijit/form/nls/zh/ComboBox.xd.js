dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.zh.ComboBox"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.zh.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "zh", {"previousMessage": "先前选项", "nextMessage": "更多选项"});
}});