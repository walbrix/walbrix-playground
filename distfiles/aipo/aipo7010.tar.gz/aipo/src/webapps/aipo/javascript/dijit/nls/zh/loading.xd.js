dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.zh.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.zh.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "zh", {"loadingState": "正在装入...", "errorState": "对不起，发生了错误"});
}});