dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.de.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.de.common");dojo._xdLoadFlattenedBundle("dijit", "common", "de", {"buttonCancel": "Abbrechen", "buttonSave": "Speichern", "buttonOk": "OK"});
}});