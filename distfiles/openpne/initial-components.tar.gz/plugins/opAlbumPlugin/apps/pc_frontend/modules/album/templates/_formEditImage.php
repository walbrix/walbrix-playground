<a href="<?php echo sf_image_path($image->getCoverImage()) ?>" target="_blank"><?php echo image_tag_sf_image($image->getCoverImage(), array('size' => '120x120')) ?></a><br />
%input%<br />
%delete% %delete_label%
