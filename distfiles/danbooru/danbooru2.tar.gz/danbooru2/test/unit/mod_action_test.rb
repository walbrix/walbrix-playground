require 'test_helper'

class ModActionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
