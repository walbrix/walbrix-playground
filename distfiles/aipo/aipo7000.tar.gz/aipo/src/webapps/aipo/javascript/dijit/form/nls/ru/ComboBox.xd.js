dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.ru.ComboBox"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.ru.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "ru", {"previousMessage": "Предыдущие варианты", "nextMessage": "Следующие варианты"});
}});