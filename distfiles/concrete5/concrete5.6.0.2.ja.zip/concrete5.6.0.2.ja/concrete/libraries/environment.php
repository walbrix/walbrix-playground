<?php	

defined('C5_EXECUTE') or die("Access Denied.");

final class Environment extends Concrete5_Library_Environment {}
final class EnvironmentRecord extends Concrete5_Library_Environment_Record {}