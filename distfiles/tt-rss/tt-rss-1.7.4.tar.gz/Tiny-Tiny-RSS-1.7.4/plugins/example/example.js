function example(value) {
	alert("Value saved: " + value);
}
