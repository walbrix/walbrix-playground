<?php	
defined('C5_EXECUTE') or die("Access Denied.");
/**
 * An object corresponding to a particular view of an attribute.
 *
 * @author Andrew Embler <andrew@concrete5.org>
 * @category Concrete
 * @copyright  Copyright (c) 2003-2008 Concrete5. (http://www.concrete5.org)
 * @license    http://www.concrete5.org/license/     MIT License
 *
 */
class AttributeTypeView extends Concrete5_Library_AttributeTypeView {}