dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.zh-tw.validate"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.zh-tw.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "zh-tw", {"rangeMessage": "* 此值超出範圍。", "invalidMessage": "* 輸入的值無效。", "missingMessage": "* 必須提供此值。"});
}});