<html>
  <head>
    <title>OpenID Server Endpoint</title>
    <link rel="openid.server" href="<?php echo url_for('OpenID/index', true) ?>" />
  </head>
  <body>
    <p><?php echo __('This is an OpenID Server endpoint.'); ?></p>
  </body>
</html>
