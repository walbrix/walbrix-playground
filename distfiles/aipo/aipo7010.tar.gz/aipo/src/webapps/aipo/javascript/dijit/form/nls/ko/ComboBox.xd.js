dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.ko.ComboBox"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.ko.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "ko", {"previousMessage": "이전 선택사항", "nextMessage": "기타 선택사항"});
}});