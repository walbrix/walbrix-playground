<?php
op_include_parts('informationBox', 'information_'.$gadget->getId(), array('body' => $gadget->getRawValue()->getConfig('value')))
?>
