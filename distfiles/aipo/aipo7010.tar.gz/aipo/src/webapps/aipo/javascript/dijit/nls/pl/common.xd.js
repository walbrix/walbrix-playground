dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.pl.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.pl.common");dojo._xdLoadFlattenedBundle("dijit", "common", "pl", {"buttonCancel": "Anuluj", "buttonSave": "Zapisz", "buttonOk": "OK"});
}});