<?php op_mobile_page_title(__('Password Recovery')) ?>
<center><?php echo __('Please input your new password.') ?><br></center>
<?php echo op_include_form('passowrdResetForm', $form) ?>
