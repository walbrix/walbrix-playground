dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.ko.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.ko.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "ko", {"loadingState": "로드 중...", "errorState": "죄송합니다. 오류가 발생했습니다."});
}});