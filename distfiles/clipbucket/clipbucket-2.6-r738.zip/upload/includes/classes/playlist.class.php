<?php

/**
 * This class is used to manage Playlist
 * and Quicklist for ClipBucket
 * 
 * @Author : Arslan hassan (te haur kaun o sukda :p)
 * @License: CBLA
 * @Since : Bakra Eid 2009
 */
 
 
class cbplaylist
{
	/**
	 * Database Tables
	 */
	var $dbtbl = array('user_playlists'=>'cb_user_playlists','playlist_items'=>'playlist_items');
	
	
	
	
}