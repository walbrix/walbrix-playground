<?php
Configure::write('Security.salt', 'bGh42c176207fFKW3YGbOIcj7eNj1MZ266XY8PV4');
Configure::write('Cache.disable', false);
Configure::write('Session.save', 'cake');
Configure::write('BcEnv.siteUrl', 'http://' . $_SERVER["SERVER_NAME"] . '/');
Configure::write('BcEnv.sslUrl', '');
Configure::write('BcApp.adminSsl', false);
Configure::write('BcApp.mobile', true);
Configure::write('BcApp.smartphone', true);
Cache::config('default', array('engine' => 'File'));
Configure::write('debug', 0);
Configure::write('App.baseUrl', '');
?>
