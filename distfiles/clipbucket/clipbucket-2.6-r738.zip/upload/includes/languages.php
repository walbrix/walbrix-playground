<?php

$langArray   = 
array(
'cn_ZH'	=>	'中文 (简体)',
'de'	=>	'Deutsch',
'en'	=>	'English (US)',
'es'	=>	'Español',
'fr'    =>  'Français',
'it'	=>	'Italiano',
'ja'	=>	'日本語',
'lt'	=>	'Lietuvių',
'lv'	=>	'Latviešu',
'pt_BR' =>  'Português (Brasil)',
'pt_PT'	=>	'Português (Portugal)',
'ru'	=>	'Pyccĸий',
'nl'	=>	'Dutch',
'sk'    =>  'Slovenčina',
'tr'	=>	'Türkçe',
);


asort($langArray);

?>