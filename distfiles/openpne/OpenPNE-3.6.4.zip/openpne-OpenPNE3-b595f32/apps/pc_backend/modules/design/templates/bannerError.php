<?php slot('submenu') ?>
<?php include_partial('submenu'); ?>
<?php end_slot() ?>
