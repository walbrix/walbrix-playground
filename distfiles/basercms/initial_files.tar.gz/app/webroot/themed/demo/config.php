<?php
$title = 'baserCMSデモ';
$description = 'baserCMS公式デモテーマ';
$author = 'basercms';
$url = 'http://basercms.net';
?>