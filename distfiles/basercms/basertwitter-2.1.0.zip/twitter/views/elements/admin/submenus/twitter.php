<tr>
	<th>Twitter管理メニュー</th>
	<td>
		<ul>
			<li><?php $bcBaser->link('Twitterプラグイン設定',array('action'=>'form')) ?></li>
		</ul>
	</td>
</tr>
