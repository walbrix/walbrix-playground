dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.nls.Textarea");dojo._xdLoadFlattenedBundle("dijit", "Textarea", "", {"iframeEditTitle": "edit area", "iframeFocusTitle": "edit area frame"});
}});