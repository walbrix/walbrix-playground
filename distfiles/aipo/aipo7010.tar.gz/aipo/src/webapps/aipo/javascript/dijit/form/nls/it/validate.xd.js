dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.it.validate"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.it.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "it", {"rangeMessage": "* Questo valore non è compreso nell'intervallo.", "invalidMessage": "* Il valore immesso non è valido.", "missingMessage": "* Questo valore è obbligatorio."});
}});