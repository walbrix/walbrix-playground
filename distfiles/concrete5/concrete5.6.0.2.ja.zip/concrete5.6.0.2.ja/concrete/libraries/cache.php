<?php	

final class CacheLocal extends Concrete5_Library_CacheLocal {}

final class Cache extends Concrete5_Library_Cache {}