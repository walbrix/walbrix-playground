<?php op_include_box('userAgreement', nl2br($op_config['user_agreement'])) ?>
