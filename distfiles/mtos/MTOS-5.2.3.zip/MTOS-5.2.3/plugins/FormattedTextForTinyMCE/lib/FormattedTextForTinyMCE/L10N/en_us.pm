package FormattedTextForTinyMCE::L10N::en_us;

use strict;
use warnings;

use base 'FormattedTextForTinyMCE::L10N';
use vars qw( %Lexicon );

%Lexicon = ();

1;
