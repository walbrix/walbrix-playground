<?php echo nl2br($op_config['user_agreement']) ?>
