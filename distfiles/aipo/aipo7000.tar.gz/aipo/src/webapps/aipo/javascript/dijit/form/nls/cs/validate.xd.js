dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.cs.validate"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.cs.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "cs", {"rangeMessage": "* Tato hodnota je mimo rozsah.", "invalidMessage": "* Zadaná hodnota není platná.", "missingMessage": "* Tato hodnota je vyžadována."});
}});