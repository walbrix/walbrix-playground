dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.ko.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.ko.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "ko", {"iframeTitle1": "편집 영역", "iframeTitle2": "편집 영역 프레임"});
}});