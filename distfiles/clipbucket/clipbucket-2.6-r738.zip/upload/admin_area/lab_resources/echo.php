<?php
	echo "Pakistan Zindabad!! ^_^";
?>