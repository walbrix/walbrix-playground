# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Danbooru::Application.config.secret_token = 'bd49b99b97bed9bf337d83224d315abaf5e5f48fbd20183570b6c4d81220035536e5a6683461da02f60a8f507ea74aa92fa083c577963e0f16a557ce808c2f30'
