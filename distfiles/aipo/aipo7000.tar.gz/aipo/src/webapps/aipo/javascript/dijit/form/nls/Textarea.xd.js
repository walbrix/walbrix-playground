dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "", {"iframeTitle1": "edit area", "iframeTitle2": "edit area frame"});
}});