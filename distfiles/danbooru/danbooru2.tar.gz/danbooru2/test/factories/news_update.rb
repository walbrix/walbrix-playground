FactoryGirl.define do
  factory(:news_update) do
    message "xxx"
  end
end
