dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.fr.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.fr.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "fr", {"loadingState": "Chargement...", "errorState": "Une erreur est survenue"});
}});