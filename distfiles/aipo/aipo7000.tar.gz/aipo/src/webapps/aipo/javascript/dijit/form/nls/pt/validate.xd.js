dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.pt.validate"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.pt.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "pt", {"rangeMessage": "* Esse valor está fora do intervalo.", "invalidMessage": "* O valor digitado não é válido.", "missingMessage": "* Esse valor é necessário."});
}});