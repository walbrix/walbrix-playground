package FormattedTextForTinyMCE::L10N;

use strict;
use warnings;

use base 'MT::Plugin::L10N';

1;
