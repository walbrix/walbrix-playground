<?php	

defined('C5_EXECUTE') or die("Access Denied.");

class Newsflow extends Concrete5_Library_Newsflow {}
class NewsflowSlotItem extends Concrete5_Library_NewsflowSlotItem {}
class NewsflowItem extends Concrete5_Library_NewsflowItem {}