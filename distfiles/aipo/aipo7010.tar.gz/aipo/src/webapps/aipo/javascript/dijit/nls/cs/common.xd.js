dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.cs.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.cs.common");dojo._xdLoadFlattenedBundle("dijit", "common", "cs", {"buttonCancel": "Storno", "buttonSave": "Uložit", "buttonOk": "OK"});
}});