<?php op_mobile_page_title(__('Delete your %1% account', array('%1%' => $op_config['sns_name']))) ?>
<?php echo __('You can not delete your account.') ?>
