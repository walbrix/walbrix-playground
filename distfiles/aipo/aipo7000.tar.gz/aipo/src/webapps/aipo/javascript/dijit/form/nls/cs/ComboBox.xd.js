dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.cs.ComboBox"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.cs.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "cs", {"previousMessage": "Předchozí volby", "nextMessage": "Další volby"});
}});