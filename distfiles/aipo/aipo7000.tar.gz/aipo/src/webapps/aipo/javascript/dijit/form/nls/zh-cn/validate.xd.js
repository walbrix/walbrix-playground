dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.zh-cn.validate"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.zh-cn.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "zh-cn", {"rangeMessage": "* 输入数据超出值域。", "invalidMessage": "* 非法的输入值。", "missingMessage": "* 此值是必须的。"});
}});