.. mroonga documentation master file, created by
   sphinx-quickstart on Tue Aug 03 14:53:35 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

mroonga
=======

For the release history: :doc:`news`

.. toctree::
   :maxdepth: 3
   :numbered:

   characteristic
   install
   userguide
   reference
   community
   developer

Indices
=======

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

