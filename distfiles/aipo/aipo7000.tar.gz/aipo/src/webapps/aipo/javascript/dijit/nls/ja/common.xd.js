dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.ja.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.ja.common");dojo._xdLoadFlattenedBundle("dijit", "common", "ja", {"buttonCancel": "キャンセル", "buttonSave": "保存", "buttonOk": "OK"});
}});