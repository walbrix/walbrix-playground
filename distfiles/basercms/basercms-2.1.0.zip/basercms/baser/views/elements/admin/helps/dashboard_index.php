<?php
/* SVN FILE: $Id$ */
/**
 * [ADMIN] ダッシュボードヘルプ
 *
 * PHP versions 4 and 5
 *
 * baserCMS :  Based Website Development Project <http://basercms.net>
 * Copyright 2008 - 2013, baserCMS Users Community <http://sites.google.com/site/baserusers/>
 *
 * @copyright		Copyright 2008 - 2013, baserCMS Users Community
 * @link			http://basercms.net baserCMS Project
 * @package			baser.views
 * @since			baserCMS v 2.0.0
 * @version			$Revision$
 * @modifiedby		$LastChangedBy$
 * @lastmodified	$Date$
 * @license			http://basercms.net/license/index.html
 */
?>
<p>ダッシュボードはログインした際に一番初めに来るページです。初期状態では、baserCMS公式の更新情報（baserCMSニュース）、現在のページ状況、管理画面の利用履歴（最近の動き）が表示されます。</p>