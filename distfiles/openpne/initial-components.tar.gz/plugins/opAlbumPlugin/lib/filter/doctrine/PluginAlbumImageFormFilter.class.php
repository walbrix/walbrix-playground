<?php

/**
 * PluginAlbumImage form.
 *
 * @package    filters
 * @subpackage AlbumImage *
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 6174 2007-11-27 06:22:40Z fabien $
 */
abstract class PluginAlbumImageFormFilter extends BaseAlbumImageFormFilter
{
}