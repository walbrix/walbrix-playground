<li><?php echo link_to(__('連携済みアプリケーション一覧'), 'connection_list') ?></li>
<li><?php echo link_to(__('アプリケーション登録'), 'connection_new') ?></li>
