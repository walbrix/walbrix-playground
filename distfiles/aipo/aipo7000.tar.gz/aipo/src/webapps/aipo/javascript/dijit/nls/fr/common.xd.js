dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.fr.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.fr.common");dojo._xdLoadFlattenedBundle("dijit", "common", "fr", {"buttonCancel": "Annuler", "buttonSave": "Sauvegarder", "buttonOk": "OK"});
}});