
					<?php 
					$body ="Hello $username, Welcome to $title.
You are now our member, you can now

-> Upload Videos
-> Share Videos
-> Make Friends and Send Messeges
-> Now You Have Your Own Channel

To Access Your Account Please <a href=$baseurl>Click Here</a> and login

Thank You For Joining Us,
Regards
$title Team" 
					?>
					