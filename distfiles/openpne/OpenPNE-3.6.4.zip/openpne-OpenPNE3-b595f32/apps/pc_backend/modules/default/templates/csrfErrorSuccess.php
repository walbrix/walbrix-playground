<?php echo __('CSRF attack detected.'); ?>
