dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.de.ComboBox"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.de.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "de", {"previousMessage": "Vorherige Auswahl", "nextMessage": "Weitere Auswahlmöglichkeiten"});
}});