server "sonohara.donmai.us", :web, :app, :primary => true
server "hijiribe.donmai.us", :web, :app