dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.pt.ComboBox"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.pt.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "pt", {"previousMessage": "Opções anteriores", "nextMessage": "Mais opções"});
}});