<?php op_mobile_page_title(__('Error')) ?>
<?php echo __('You can\'t access this page.') ?>
