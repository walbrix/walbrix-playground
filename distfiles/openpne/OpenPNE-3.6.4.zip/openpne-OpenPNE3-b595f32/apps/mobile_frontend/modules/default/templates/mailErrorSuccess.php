<?php op_mobile_page_title(__('Mail Send Error')) ?>
<?php echo __('Couldn\'t send E-mail. Please retry or contact to administrator.') ?>
