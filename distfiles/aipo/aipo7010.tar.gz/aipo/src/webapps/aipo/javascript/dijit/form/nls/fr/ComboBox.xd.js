dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.fr.ComboBox"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.fr.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "fr", {"previousMessage": "Choix précédents", "nextMessage": "Plus de choix"});
}});