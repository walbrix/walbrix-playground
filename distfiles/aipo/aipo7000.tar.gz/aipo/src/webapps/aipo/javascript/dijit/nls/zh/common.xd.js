dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.zh.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.zh.common");dojo._xdLoadFlattenedBundle("dijit", "common", "zh", {"buttonCancel": "取消", "buttonSave": "保存", "buttonOk": "确定"});
}});