dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.cs.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.cs.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "cs", {"loadingState": "Probíhá načítání...", "errorState": "Omlouváme se, došlo k chybě"});
}});