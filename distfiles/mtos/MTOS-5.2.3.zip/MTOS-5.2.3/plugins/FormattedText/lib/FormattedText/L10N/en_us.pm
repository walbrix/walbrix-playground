package FormattedText::L10N::en_us;

use strict;
use warnings;

use base 'FormattedText::L10N';
use vars qw( %Lexicon );

%Lexicon = ();

1;
