<?php	
defined('C5_EXECUTE') or die("Access Denied.");
class ContentImporter extends Concrete5_Library_Content_Importer {}
