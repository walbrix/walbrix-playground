<li><?php echo link_to(__('Account Management'), 'admin/manageUser') ?></li>
<li><?php echo link_to(__('Change Password'), 'admin/editPassword') ?></li>
<li><?php echo link_to(__('Change Language'), 'admin/changeLanguage') ?></li>
