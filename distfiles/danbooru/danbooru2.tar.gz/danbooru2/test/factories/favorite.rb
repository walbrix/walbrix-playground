FactoryGirl.define do
  factory(:favorite)
end
