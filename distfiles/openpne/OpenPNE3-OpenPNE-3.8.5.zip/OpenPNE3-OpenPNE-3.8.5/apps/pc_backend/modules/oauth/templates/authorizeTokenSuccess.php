<p>アプリケーションに戻って次のコードを入力してください。</p>

<div>
<code><?php echo $information->verifier; ?></code>
</div>
