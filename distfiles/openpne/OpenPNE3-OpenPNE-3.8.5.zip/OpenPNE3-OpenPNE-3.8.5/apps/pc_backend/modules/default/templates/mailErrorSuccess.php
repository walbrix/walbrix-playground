<?php echo __('Couldn\'t send E-mail. Please retry or contact to administrator.') ?>
<?php use_helper('Javascript') ?>
<p><?php echo link_to_function(__('Back to previous page'), 'history.back()') ?></p>
