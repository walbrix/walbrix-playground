dojo._xdResourceLoaded({depends:[["provide","aipo.calendar.weekly"],["require","aimluck.dnd.Draggable"],["require","aipo.widget.ToolTip"],["require","aipo.widget.MemberNormalSelectList"],["require","aipo.widget.GroupNormalSelectList"]],defineResource:function(A){if(!A._hasResource["aipo.calendar.weekly"]){A._hasResource["aipo.calendar.weekly"]=true;
A.provide("aipo.calendar.weekly");
A.require("aimluck.dnd.Draggable");
A.require("aipo.widget.ToolTip");
A.require("aipo.widget.MemberNormalSelectList");
A.require("aipo.widget.GroupNormalSelectList");
aipo.calendar.objectlist=Array();
aipo.calendar.maximum_to=30;
aipo.calendar.populateWeeklySchedule=function(F,G){var D;
var E=A.byId("member_to-"+F);
if(typeof G=="undefined"||typeof ptConfig[F].jsonData=="undefined"){D=""
}else{D=G
}var C=A.byId("secid-"+F);
if(C){D+="&secid="+C.value
}if(D.match(/ign_dup_f/)==null){if(E){var H=E.options;
to_size=H.length;
if(to_size==0){D+="&m_id="+aipo.schedule.login_id
}for(i=0;
i<to_size;
i++){H[i].selected=true;
D+="&m_id="+H[i].value
}}var B=A.byId("showAll-"+F);
if(B){D+="&s_all="+B.value
}}djConfig.usePlainJson=true;
ptConfig[F].reloadFunction=aipo.calendar.populateWeeklySchedule;
ptConfig[F].isTooltipEnable=false;
if(aipo.calendar.dummyDivObj){aipo.calendar.dummyDivObj.destroy();
aipo.calendar.dummyDivObj=null
}A.xhrGet({portletId:F,url:ptConfig[F].jsonUrl+D,encoding:"utf-8",handleAs:"json-comment-filtered",load:function(g,Z){if(aipo.calendar.reloadMonthlyCalendar!=null){aipo.calendar.reloadMonthlyCalendar()
}obj_error=A.byId("error-"+F);
A.style(obj_error,"display","none");
if("PermissionError"==g[0]){A.style(obj_error,"display","block");
obj_error.innerHTML=g[1];
obj_content=A.byId("content-"+F);
A.style(obj_content,"display","none");
obj_indicator=A.byId("indicator-"+F);
A.style(obj_indicator,"display","none");
return 
}else{if(g.errList){if("duplicate_facility"==g.errList[0]){if(confirm("既に同じ時間帯に設備が予約されています。スケジュールを登録しますか？")){var J=D+"&ign_dup_f=true";
aipo.calendar.populateWeeklySchedule(F,J);
aipo.portletReload("schedule",F);
return 
}}if("UpdateError"==g.errList[0]){A.style(obj_error,"display","block");
obj_error.innerHTML='<ul><li><span class="caution">'+g.errList[1]+"</span></li></ul>";
obj_content=A.byId("content-"+F);
A.style(obj_content,"visibility","visible");
obj_indicator=A.byId("indicator-"+F);
A.style(obj_indicator,"display","none")
}}}var a;
if(!!aipo.calendar.objectlist){var b=aipo.calendar.objectlist.length;
for(a=0;
a<b;
a++){var V=aipo.calendar.objectlist[a];
if(V.portletId==F){V.destroy()
}}}if(!aipo.errorTreatment(g,ptConfig[F].thisUrl)){return 
}ptConfig[F].jsonData=g;
var e=Array(ptConfig[F].scheduleDivDaySum);
for(var a=0;
a<ptConfig[F].scheduleDivDaySum;
a++){e[a]=Array()
}var M=0;
var f=0;
var S="";
var N="";
var X="";
var U=[];
var T,R,Q,P;
var c=g.startDate.substring(0,4)+"年"+parseInt(g.startDate.substring(5,7),10)+"月"+parseInt(g.startDate.substring(8,10),10)+"日"+g.dayOfWeek[0];
A.byId("viewWeekly-"+F).innerHTML=c;
var I="";
var Y="";
if(A.byId("top_form").value=="simple"){I="width: 100%;";
Y="width: 0%;display: none;"
}X+='<table cellspacing="0" cellpadding="0" border="0" width="100%"><tbody>';
var W=A.byId("weeklyScrollPane_"+this.portletId);
if(W.clientWidth==W.offsetWidth){A.byId("weeklySpan-"+F).style.display="none";
if(A.byId("isMac").value!=0){A.byId("weeklyHeadRightborder-"+F).style.borderRight="none";
A.byId("termDay0-"+F).style.borderRight="none"
}}A.forEach(g.termSchedule,function(h){var m="";
var q="";
if(A.byId("top_form").value=="simple"){m=' style="display: none;"';
for(k=0;
k<h.length;
k++){o=h[k];
if(o.index==0){m="";
q=" weeklyTermRightR";
break
}}}var l=A.byId("weeklyScrollPane_"+this.portletId);
if(l.clientWidth==l.offsetWidth){q=" weeklyTermRightRnone";
if(A.byId("isMac").value!=0){A.byId("weeklyHeadRightborder-"+F).style.borderRight="none";
A.byId("termDay0-"+F).style.borderRight="none"
}}var o=null;
var n=(scheduleTooltipEnable!==true&&A.byId("top_form").value=="simple")?"border-right:0":"";
if(scheduleTooltipEnable!==true&&A.byId("top_form").value=="simple"){X+="<tr"+m+'><td width="50"><div class="weeklyTermLeft" id="weeklyTermLeft"><div class="weeklyTermLeftTop">&nbsp;</div></div></td><td  colspan="2" nowrap="nowrap" width="100%" valign="top"><div class="weeklyTermRights">'
}else{X+="<tr"+m+'><td width="50"><div class="weeklyTermLeft" id="weeklyTermLeft"><div class="weeklyTermLeftTop">&nbsp;</div></div></td><td nowrap="nowrap" width="100%" valign="top"><div class="weeklyTermRights">'
}X+='<div class="weeklyTermRight weeklyTermRightL'+q+'" id="termDay0-'+f+"-"+F+'" style="left: 0%;'+I+n+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
X+='<div class="weeklyTermRight" id="termDay1-'+f+"-"+F+'" style="left: 14.2857%;'+Y+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
X+='<div class="weeklyTermRight" id="termDay2-'+f+"-"+F+'" style="left: 28.5714%;'+Y+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
X+='<div class="weeklyTermRight" id="termDay3-'+f+"-"+F+'" style="left: 42.8571%;'+Y+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
X+='<div class="weeklyTermRight" id="termDay4-'+f+"-"+F+'" style="left: 57.1429%;'+Y+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
X+='<div class="weeklyTermRight" id="termDay5-'+f+"-"+F+'" style="left: 71.4286%;'+Y+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
X+='<div class="weeklyTermRight weeklyTermRightR" id="termDay6-'+f+"-"+F+'" style="left: 85.7143%;'+Y+'"><div class="weeklyTermRightTop">&nbsp;</div></div>';
X+='<div id="termScheduleItemGarage-'+f+"-"+F+'" class="termScheduleGarage"> </div>';
var p;
if(scheduleTooltipEnable!==true&&A.byId("top_form").value=="simple"||l.clientWidth==l.offsetWidth){p="</div></td></tr>"
}else{p='</div></td><td width="18"><div class="weeklyTermTail">&nbsp;</div></td></tr>'
}if(window.navigator.userAgent.toLowerCase().indexOf("ipad")!==-1&&A.byId("top_form").value!=="simple"){p='</div></td><td width="18"><div class="weeklyTermTail">&nbsp;</div></td></tr>'
}X+=p;
f++
});
X+="</tbody></table>";
A.byId("termScheduleGarage-"+F).innerHTML=X;
A.byId("termScheduleDivAdd_"+F).style.height=(18*(f+1))+"px";
for(var a=0;
a<ptConfig[F].scheduleDivDaySum;
a++){T=A.byId("weeklyDay"+a+"-"+F);
R=A.byId("weeklyHoliday"+a+"-"+F);
Q=A.byId("weeklyRight"+a+"-"+F);
P=A.byId("termDay"+a+"-"+F);
T.innerHTML=parseInt(g.date[a].substring(8,10),10)+g.dayOfWeek[a];
R.innerHTML=g.holiday[a];
if(g.dayOfWeek[a]=="（土）"){A.addClass(T,"saturday");
A.addClass(R,"saturday");
A.addClass(Q,"saturday");
A.addClass(P,"saturday")
}else{A.removeClass(T,"saturday");
A.removeClass(R,"saturday");
A.removeClass(Q,"saturday");
A.removeClass(P,"saturday")
}if(g.dayOfWeek[a]=="（日）"){A.addClass(T,"sunday");
A.addClass(R,"sunday");
A.addClass(Q,"sunday");
A.addClass(P,"sunday")
}else{A.removeClass(T,"sunday");
A.removeClass(R,"sunday");
A.removeClass(Q,"sunday");
A.removeClass(P,"sunday")
}if(g.holiday[a]){A.addClass(T,"holiday");
A.addClass(R,"holiday");
A.addClass(Q,"holiday");
A.addClass(P,"holiday")
}else{A.removeClass(T,"holiday");
A.removeClass(R,"holiday");
A.removeClass(Q,"holiday");
A.removeClass(P,"holiday")
}}A.forEach(g.schedule,function(AA){var h=ptConfig[F].rowHeight;
var w=AA.startDateHour*h*2+AA.startDateMinute*h/30;
var z=AA.endDateHour*h*2+AA.endDateMinute*h/30-w;
if(z<=h){U[M]=z;
z=h
}else{U[M]=-1
}var p=100/ptConfig[F].scheduleDivDaySum*AA.index;
var n=100/ptConfig[F].scheduleDivDaySum*0.99;
var l=AA.name;
var o=U[M]==-1?((AA.startDateHour>9)?AA.startDate:"0"+AA.startDate):AA.name;
var u=U[M]==-1?((AA.endDateHour>9)?AA.endDate:"0"+AA.endDate):"";
var t=U[M]==-1?"-":"";
var v=AA.scheduleId;
var x="0";
var q="";
var m=A.byId("member_to-"+F);
if(m){var r=m.options;
for(a=0;
a<r.length;
a++){if(((AA.type=="U")&&(AA.ownerId==r[a].value))||((AA.type=="F")&&(AA.ownerId==r[a].value))){x=a%aipo.calendar.maximum_to
}if(AA.memberList){var s=0;
var y=0;
for(j=0;
j<AA.memberList.length;
j++){if(AA.memberList[j].charAt(0)=="f"){y++
}else{s++
}}}}var q;
if(AA.userCount>1){q="[共有]"
}if(AA.facilityCount>0){q+="[設備]"
}}if(!AA["public"]){l+='<img src="images/schedule/schedule_secret.gif" border="0" width="16" height="16" alt="非公開" title="非公開" align="top" class="icon" />'
}if(AA.duplicate){l+='<img src="images/schedule/schedule_duplicate.gif" border="0" width="16" height="16" alt="重複スケジュール" title="重複スケジュール" align="top" class="icon" />'
}if(AA.repeat){l+='<img src="images/schedule/schedule_repeat.gif" border="0" width="16" height="16" alt="繰り返し" title="繰り返し" align="top" class="icon" />'
}if(AA.tmpreserve){l+='<img src="images/schedule/schedule_tmpreserve.gif" border="0" width="16" height="16" alt="仮スケジュール" title="仮スケジュール" align="top" class="icon" />'
}S+='<div id="schedule-'+M+"-"+F+'" class="scheduleDiv color'+x+'" style="top: '+w+"px; left: "+p+"%; height: "+(z-1)+"px; width: "+n+'%; z-index: 0; visibility: hidden;"><div class="scheduleDivFirstLine color'+x+'"><span id="scheduleDivStartTime-'+M+"-"+F+'" class="scheduleDivTime color'+x+'">'+q+o+'</span><span id="scheduleDivSepalater-'+M+"-"+F+'"  class="scheduleDivSepalater color'+x+'">'+t+'</span><span id="scheduleDivEndTime-'+M+"-"+F+'" class="scheduleDivTime color'+x+'">'+u+'</span></div><div class="scheduleDivName color'+x+'">'+l+'</div><div class="scheduleDivLastLine color'+x+'"><center><div class="handleDiv color'+x+'" align="center">&nbsp;</div></center></div></div>';
M++
});
S+='<div id="dummy_div_'+F+'" class="scheduleDivAdd dummy_div" style=" position:absolute; width: 0px; height : 0px; left: 0px; top: -10000px; Filter: Alpha(Opacity=10);opacity:.10; background-color:#FFFFFF; ">&nbsp;</div>';
A.byId("scheduleGarage-"+F).innerHTML=S;
var d=null;
var L,K;
var O=[];
M=0;
A.forEach(g.schedule,function(l){L=A.byId("schedule-"+M+"-"+F);
var h=l.scheduleId;
d=new aipo.calendar.WeeklyScheduleDraggable(L,{pid:F,sid:'"schedule-'+M+"-"+F+'"',handle:'"dummy_div_-'+F+'"'});
aipo.calendar.objectlist.push(d);
if(l.member||l.loginuser||l.owner||l["public"]){d.setDraggable(true)
}else{d.setDraggable(false)
}d.schedule=l;
d.tmpIndex=l.index;
d.count=M;
d.tmpHeight=U[M];
d.position=0;
d.division=1;
d.portletId=F;
e[l.index].push(L);
if(l["public"]||l.member){A.connect(L,"onclick",d,"onScheduleClick")
}A.connect(L,"onmouseover",d,"onScheduleOver");
M++
});
for(var a=0;
a<ptConfig[F].scheduleDivDaySum;
a++){aipo.calendar.relocation(e[a].length,e[a],100/ptConfig[F].scheduleDivDaySum*a);
e[a]=Array()
}M=0;
f=0;
A.forEach(g.termSchedule,function(t){var x=null;
N="";
for(var s=0;
s<ptConfig[F].scheduleDivDaySum;
s++){tmpNode5=A.byId("termDay"+s+"-"+f+"-"+F);
if(g.dayOfWeek[s]=="（土）"){A.addClass(tmpNode5,"saturday")
}else{A.removeClass(tmpNode5,"saturday")
}if(g.dayOfWeek[s]=="（日）"){A.addClass(tmpNode5,"sunday")
}else{A.removeClass(tmpNode5,"sunday")
}if(g.holiday[s]){A.addClass(tmpNode5,"holiday")
}else{A.removeClass(tmpNode5,"holiday")
}}for(k=0;
k<t.length;
k++){x=t[k];
var m=100/ptConfig[F].scheduleDivDaySum*x.rowspan;
var o=100/ptConfig[F].scheduleDivDaySum*x.index;
var n="";
if(A.byId("top_form").value=="simple"){m=100;
n=((x.index==0)?"":"display: none;")
}var h=x.name;
var u=x.scheduleId;
var v="0";
var p="";
var l=A.byId("member_to-"+F);
if(l){var q=l.options;
for(s=0;
s<q.length;
s++){if(((x.type=="U")&&(x.ownerId==q[s].value))||((x.type=="F")&&(x.ownerId==q[s].value))){v=s%aipo.calendar.maximum_to
}if(x.memberList){var r=0;
var w=0;
for(j=0;
j<x.memberList.length;
j++){if(x.memberList[j].charAt(0)=="f"){w++
}else{r++
}}}}var p;
if(r>1){p="[共有]"
}if(w>0){p+="[設備]"
}}if(!x["public"]){h+='<img src="images/schedule/schedule_secret.gif" border="0" width="16" height="16" alt="非公開" title="非公開" align="top" class="icon" />'
}if(x.duplicate){h+='<img src="images/schedule/schedule_duplicate.gif" border="0" width="16" height="16" alt="重複スケジュール" title="重複スケジュール" align="top" class="icon" />'
}if(x.repeat){h+='<img src="images/schedule/schedule_repeat.gif" border="0" width="16" height="16" alt="繰り返し" title="繰り返し" align="top" class="icon" />'
}if(x.tmpreserve){h+='<img src="images/schedule/schedule_tmpreserve.gif" border="0" width="16" height="16" alt="仮スケジュール" title="仮スケジュール" align="top" class="icon" />'
}if(m==100){m="99.99999"
}N+='<div id="termSchedule-'+M+"-"+F+'" class="termScheduleDiv termColor'+v+'" style="left: '+o+"%; width: "+m+"%;"+n+'"><div class="termScheduleDivHandleLeft" id="termScheduleDivHandleLeft-'+M+"-"+F+'">&nbsp;</div><div class="termScheduleDivNameDiv">'+p+h+'</div><div class="termScheduleDivHandleRight" id="termScheduleDivHandleRight-'+M+"-"+F+'">&nbsp;</div></div>';
M++
}A.byId("termScheduleItemGarage-"+f+"-"+F).innerHTML=N;
f++
});
tableLeft=A.byId("weeklyTermLeft_"+F);
d=null;
M=0;
f=0;
A.forEach(g.termSchedule,function(h){var m=null;
for(k=0;
k<h.length;
k++){m=h[k];
var l=m.scheduleId;
L=A.byId("termSchedule-"+M+"-"+F);
K=A.byId("termScheduleDivHandleLeft-"+M+"-"+F);
draggable3=A.byId("termScheduleDivHandleRight-"+M+"-"+F);
d=new aipo.calendar.WeeklyTermScheduleDraggable(L,{pid:F,sid:"termSchedule-"+M+"-"+F});
aipo.calendar.objectlist.push(d);
d.schedule=m;
d.scheduleNode=L;
d.portletId=F;
d.termType="center";
A.connect(L,"onclick",d,"onScheduleClick");
L.style.zIndex=1;
if(m.indexReal>=0){tmpDraggable2=new aipo.calendar.WeeklyTermScheduleDraggable(K,{pid:F,sid:"termScheduleDivHandleLeft-"+M+"-"+F});
aipo.calendar.objectlist.push(tmpDraggable2);
tmpDraggable2.schedule=m;
tmpDraggable2.scheduleNode=L;
tmpDraggable2.portletId=F;
tmpDraggable2.termType="left";
if(m.member||m.loginuser||m.owner||m["public"]){tmpDraggable2.setDraggable(true)
}else{tmpDraggable2.setDraggable(false)
}}else{A.style(K,"cursor","pointer");
K.style.zIndex=1
}A.connect(K,"onclick",d,"onScheduleClick");
if(m.indexReal+m.colspanReal<=ptConfig[F].scheduleDivDaySum){tmpDraggable3=new aipo.calendar.WeeklyTermScheduleDraggable(draggable3,{pid:F,sid:"termScheduleDivHandleRight-"+M+"-"+F});
aipo.calendar.objectlist.push(tmpDraggable3);
tmpDraggable3.schedule=m;
tmpDraggable3.scheduleNode=L;
tmpDraggable3.portletId=F;
tmpDraggable3.termType="right";
if(m.member||m.loginuser||m.owner||m["public"]){tmpDraggable3.setDraggable(true)
}else{tmpDraggable3.setDraggable(false)
}}else{A.style(draggable3,"cursor","pointer");
draggable3.style.zIndex=1
}A.connect(draggable3,"onclick",d,"onScheduleClick");
A.connect(L,"onmouseover",d,"onScheduleOver");
if(m.member||m.loginuser||m.owner||m["public"]){d.setDraggable(true)
}else{d.setDraggable(false)
}M++
}f++
});
obj_content=A.byId("content-"+F);
A.style(obj_content,"visibility","visible");
obj_indicator=A.byId("indicator-"+F);
A.style(obj_indicator,"display","none");
if(!ptConfig[F].isScroll){A.byId("weeklyScrollPane_"+F).scrollTop=ptConfig[F].contentScrollTop;
ptConfig[F].isScroll=true
}ptConfig[F].isTooltipEnable=true
}})
};
aipo.calendar.relocation=function(J,B,Q){var G,E;
var I=0.99;
var R=100/7;
var K=0;
var N=0;
var P=0;
var M=0;
var L=new Array(J);
var F=new Array(J);
var D=new Array(J);
var O=1;
var C=0;
if(A.byId("top_form").value=="simple"){O=7.2
}B.sort(aipo.calendar.sortByRegion);
for(G=0;
G<J;
G++){B[G].style.zIndex=G+1
}for(G=0;
G<J;
G=K){K=aipo.calendar.overlapSchedule(B,G,G,++K,J);
if(P<parseInt(A.getComputedStyle(B[G]).top)){M=G;
P=parseInt(A.getComputedStyle(B[M]).top);
N=0
}for(E=M;
E<K;
E++){var H=parseInt(A.getComputedStyle(B[E]).top)+parseInt(A.getComputedStyle(B[E]).height)
}if(P<H){P=H
}for(E=M;
E<K;
E++){F[E]=aipo.calendar.positionLeft(B,F,M,E,0);
if(F[E]>N){N=F[E]
}}for(E=M;
E<K;
E++){D[E]=aipo.calendar.positionRight(B,F,N,M,E)
}for(E=M;
E<K;
E++){L[E]=N
}}for(G=0;
G<J;
G++){if(L[G]!=0){if(F[G]<F[G+1]){A.style(B[G],"width",(R*2/(L[G]+1))*0.8*I*O+"%")
}else{if(D[G]==0){A.style(B[G],"width",(R-(R/(L[G]+1))*F[G])*I*O+"%")
}else{A.style(B[G],"width",(R-(R/(L[G]+1))*F[G]-(R*2/(L[G]+1))*0.2-(R/(L[G]+1))*(D[G]-1))*I*O+"%")
}}}else{A.style(B[G],"width",R*I*O+"%")
}A.style(B[G],"left",(Q+((R/(L[G]+1))*F[G]))*O+"%");
A.style(B[G],"visibility","visible")
}};
aipo.calendar.overlapSchedule=function(E,C,I,H,D){var G=parseInt(A.getComputedStyle(E[C]).top)+parseInt(A.getComputedStyle(E[C]).height);
var F=parseInt(A.getComputedStyle(E[I]).top)+parseInt(A.getComputedStyle(E[I]).height);
var B;
if(E[H]){B=parseInt(A.getComputedStyle(E[H]).top)
}else{B="NaN"
}if((H>D-1)||(G<B)||(F<B)){return H
}else{H=aipo.calendar.overlapSchedule(E,C,H,++H,D)
}H=aipo.calendar.overlapSchedule(E,C,I,H,D);
return H
};
aipo.calendar.positionLeft=function(G,F,I,H,C){var B=parseInt(A.getComputedStyle(G[H]).top);
for(i=I;
i<H;
i++){var E=parseInt(A.getComputedStyle(G[i]).top);
var D=E+parseInt(A.getComputedStyle(G[i]).height);
if((E<=B)&&(D>B)&&(F[i]==C)){C=aipo.calendar.positionLeft(G,F,I,H,++C)
}}return C
};
aipo.calendar.positionRight=function(B,F,H,E,I){var G=0;
var D=parseInt(A.getComputedStyle(B[I]).top);
for(i=E;
i<I;
i++){var C=parseInt(A.getComputedStyle(B[i]).top);
var J=C+parseInt(A.getComputedStyle(B[i]).height);
if((C<=D)&&(J>D)&&(F[i]>F[I])&&((H-F[i]+1)>G)){G=H-F[i]+1
}}return G
};
aipo.calendar.sortByRegion=function(D,C){var G=parseInt(A.getComputedStyle(D).top);
var F=parseInt(A.getComputedStyle(C).top);
var B=G+parseInt(A.getComputedStyle(D).height);
var E=B+parseInt(A.getComputedStyle(C).height);
if(G==F){return E-B
}else{return G-F
}};
aipo.calendar.getDate=function(B,C){tmpYear=parseInt(B.substring(0,4),10);
tmpMonth=parseInt(B.substring(5,7),10);
tmpDay=parseInt(B.substring(8,10),10);
if(C>0){do{tmpMonthDays=aipo.calendar.getDay(tmpYear,tmpMonth);
if(tmpDay+C<=tmpMonthDays){tmpDay=tmpDay+C;
if((tmpMonth<10)&&(tmpDay<10)){date=tmpYear+"-0"+tmpMonth+"-0"+tmpDay
}else{if((tmpMonth<10)&&!(tmpDay<10)){date=tmpYear+"-0"+tmpMonth+"-"+tmpDay
}else{if(!(tmpMonth<10)&&(tmpDay<10)){date=tmpYear+"-"+tmpMonth+"-0"+tmpDay
}else{date=tmpYear+"-"+tmpMonth+"-"+tmpDay
}}}C=-1
}else{C=C-(tmpMonthDays-tmpDay)-1;
if(tmpMonth==12){tmpYear++;
tmpMonth=1
}else{tmpMonth++
}tmpDay=1
}}while(C>=0)
}else{if(C<0){do{if(tmpDay+C>0){tmpDay=tmpDay+C;
if((tmpMonth<10)&&(tmpDay<10)){date=tmpYear+"-0"+tmpMonth+"-0"+tmpDay
}else{if((tmpMonth<10)&&!(tmpDay<10)){date=tmpYear+"-0"+tmpMonth+"-"+tmpDay
}else{if(!(tmpMonth<10)&&(tmpDay<10)){date=tmpYear+"-"+tmpMonth+"-0"+tmpDay
}else{date=tmpYear+"-"+tmpMonth+"-"+tmpDay
}}}C=1
}else{if(tmpMonth==1){tmpYear--;
tmpMonth=12
}else{tmpMonth--
}tmpMonthDays=aipo.calendar.getDay(tmpYear,tmpMonth);
C=C+tmpDay;
tmpDay=tmpMonthDays
}}while(C<=0)
}else{date=B
}}return date
};
aipo.calendar.getDay=function(B,C){if(C==2){if(!(B%4)&&((B%100)||!(B%400))){return 29
}else{return 28
}}else{if(C==4||C==6||C==9||C==11){return 30
}else{return 31
}}};
aipo.calendar.setGridArray=function(D,C){var B=0;
if(aipo.calendar.gridArray){delete (aipo.calendar.gridArray)
}aipo.calendar.gridArray=new Array(C);
for(i=0;
i<C;
i++){B=A._abs(A.byId("weeklyDay"+i+"-"+D),true).x;
aipo.calendar.gridArray[i]=B
}};
aipo.calendar.getCurrentMouseX=function(E){if(aipo.calendar.gridArray==null){return{index:-1,x:0}
}var C=aipo.calendar.gridArray[0];
var G=0;
var D;
if(E.pageX>C){var B=parseInt(aipo.calendar.gridArray.length)-1;
for(D=B;
D>-1;
D--){if(E.pageX>aipo.calendar.gridArray[D]){G=D;
break
}}}else{G=0
}var F=aipo.calendar.gridArray[G]-C;
return{index:G,x:F}
};
aipo.calendar.onCloseMemberpicker=function(B){aipo.calendar.populateWeeklySchedule(B)
};
aipo.calendar.showTooltip=function(E,G,B){var F="";
var C="";
var D="";
var I="";
var H=function(K){var J=function(L){switch(L){case"<":return"&lt;";
case">":return"&gt;";
case"&":return"&amp;";
case"'":return"&#39;";
case'"':return"&quot;"
}return"?"
};
return String(K).replace(/[<>&"']/g,J)
};
A.style(B,"display","block");
A.xhrGet({portletId:G,url:E,encoding:"utf-8",handleAs:"json-comment-filtered",load:function(O,M){if(!O.id){A.style(B,"display","none");
return 
}if(!O.isSpan){F='<span style="font-size: 0.90em;">'+O.date+"</span><br/>"
}if(O.memberList){var L=O.memberList.length;
for(var J=0;
J<L;
J++){C+="<li>"+H(O.memberList[J].aliasName.value)+"</li>"
}}if(O.facilityList){var K=O.facilityList.length;
for(var J=0;
J<K;
J++){D+="<li>"+H(O.facilityList[J].facilityName.value)+"</li>"
}}if(O.place!=""){I='<span style="font-size: 0.90em;">場所</span><br/><ul><li>'+O.place+"</li></ul>"
}if(C!=""){C='<span style="font-size: 0.90em;">参加者</span><br/><ul>'+C+"</ul>"
}if(D!=""){D='<span style="font-size: 0.90em;">設備</span><br/><ul>'+D+"</ul>"
}var N="<h4>"+O.name+"</h4>"+F+C+D+I;
B.innerHTML=N
}})
};
A.declare("aipo.calendar.DummyDivObject",null,{portletId:null,parentnode:null,draggable:null,TooltipObject:null,constructor:function(B,C){this.portletId=C.pid;
this.parentnode=C.node;
this.node=A.byId(B);
this.events=[A.connect(this.node,"onmousedown",this,"onMouseDown"),A.connect(this.node,"onmouseover",this,"onMouseOver"),]
},onMouseDown:function(B){this.hide();
if(this.parentnode==null||this.parentnode=="undefined"){return 
}if(this.draggable){this.draggable.onMouseDown(B)
}},onMouseOver:function(B){if(this.parentnode==null||this.parentnode=="undefined"){return 
}},destroy:function(){A.forEach(this.events,A.disconnect);
this.events=this.node=this.handle=null
},hide:function(){A.marginBox(this.node,{l:0,t:-10000,w:0,h:0})
}});
A.declare("aipo.calendar.WeeklyScheduleDragMoveObject",[aimluck.dnd.DragMoveObject],{_rowHeight_:18,isResize:false,distance:3,lastScroll:0,onFirstMove:function(C){if(this.dragSource.TooltipObject!=null){this.dragSource.TooltipObject.uninitialize()
}var E=A.clone(this.node);
E.id="schedule-dummy-"+this.portletId;
E.style.zIndex=998;
A.style(E,"opacity",0);
var D=A.byId("scheduleGarage-"+this.portletId);
D.appendChild(E);
this.tmpDraggable=E;
A.connect(this.node,"onmousedown",this,"onMouseDown");
if(A.isIE){document.onkeydown=function(F){A.style(E,"opacity",0.3)
};
document.onkeyup=function(F){A.style(E,"opacity",0)
}
}else{A.connect(null,"onkeydown",this,"onKeyPress");
A.connect(null,"onkeyup",this,"onKeyPress")
}aimluck.dnd.DragMoveObject.prototype.onFirstMove.apply(this,arguments);
A.style(this.node,"opacity",0.5);
this.node.style.zIndex=999;
this.startY=this._pageY;
this.startAbsoluteY=A._abs(A.byId(this.node),true).y;
var B=window.navigator.userAgent.toLowerCase();
if(B.indexOf("chrome")>-1||(A.isFF&&(A.isFF>=3.6))){this.startAbsoluteY+=window.scrollY
}else{if(B.indexOf("safari")>-1){this.startAbsoluteY-=A.byId("weeklyScrollPane_"+this.portletId).scrollTop
}}this.startHeight=parseInt(A.getComputedStyle(this.node).height);
this.startTop=parseInt(A.getComputedStyle(this.node).top);
if(this.startHeight-6<this.startY-this.startAbsoluteY){this.isResize=true
}aipo.calendar.setGridArray(this.portletId,parseInt(ptConfig[this.portletId].scheduleDivDaySum));
lastScroll=A.byId("weeklyScrollPane_"+this.portletId).scrollTop
},onKeyPress:function(B){if(B.ctrlKey){A.style(this.tmpDraggable,"opacity",0.3)
}else{A.style(this.tmpDraggable,"opacity",0)
}},onMouseMove:function(I){if(this.dragSource.isDraggable==false){return 
}aimluck.dnd.DragMoveObject.prototype.onMouseMove.apply(this,arguments);
this.dragSource.schedule.isDrag=true;
if(this.dragSource.tmpHeight>3){A.style(this.node,"height",this.dragSource.tmpHeight+"px");
this.dragSource.tmpHeight=3
}var B=ptConfig[this.portletId].distance;
var D=A.byId("weeklyScrollPane_"+this.portletId).scrollTop-lastScroll;
this.leftTop.t=Math.floor((this.leftTop.t+D)/B)*B;
if(this.isResize){if(-this.startTop+this.leftTop.t+this.startHeight<0){A.style(this.node,"height","0px");
this.leftTop.t+=this.startHeight
}else{var K;
if(this.leftTop.t+this.startHeight>864){K=864-this.startTop-3
}else{K=-this.startTop+this.leftTop.t+this.startHeight
}this.leftTop.t=this.startTop;
this.leftTop.h=parseInt(K)-1
}}else{if(!this.disableY){if(this.leftTop.t<0){this.leftTop.t=0
}if(this.leftTop.t+this.startHeight>864){this.leftTop.t=864-this.startHeight-6
}}}if(!this.disableX){mouseX=aipo.calendar.getCurrentMouseX(I);
this.leftTop.l=mouseX.x;
if(A.byId("top_form").value=="simple"){this.leftTop.l=0
}this.dragSource.schedule.index=mouseX.index
}A.marginBox(this.node,this.leftTop);
var J=parseInt(A.getComputedStyle(this.node).top);
var H=parseInt(A.getComputedStyle(this.node).height)+1;
var G=J/B;
var F=Math.floor(G/12);
var E=Math.floor(G%12);
F=(F>9)?F:"0"+F;
E=(E>1)?E*(60/12):"0"+E*(60/12);
var C=this.dragSource.count;
A.byId("scheduleDivStartTime-"+C+"-"+this.portletId).innerHTML=F+":"+E;
this.dragSource.schedule.startDateHour=F;
this.dragSource.schedule.startDateMinute=E;
this.dragSource.schedule.startDate=F+":"+E;
G+=H/B;
F=Math.floor(G/12);
E=Math.floor(G%12);
F=(F>9)?F:"0"+F;
E=(E>1)?E*(60/12):"0"+E*(60/12);
A.byId("scheduleDivEndTime-"+C+"-"+this.portletId).innerHTML=F+":"+E;
this.dragSource.schedule.endDateHour=F;
this.dragSource.schedule.endDateMinute=E;
this.dragSource.schedule.endDate=F+":"+E;
A.byId("scheduleDivSepalater-"+C+"-"+this.portletId).innerHTML="-";
return 
},onMouseUp:function(C){ptConfig[this.portletId].isTooltipEnable=true;
if(A.byId("top_form").value=="simple"){this.dragSource.schedule.index=0
}if(A.isIE){document.onkeydown="";
document.onkeyup=""
}if(this.dragSource.schedule.isDrag!=true){A.style(this.node,"opacity",1);
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments);
if(this.dragSource){this.dragSource.onScheduleClick(C)
}return 
}var B=parseInt(A.getComputedStyle(this.node).height);
if(B<ptConfig[this.portletId].rowHeight){A.style(this.node,"height",ptConfig[this.portletId].rowHeight+"px");
this.dragSource.tmpHeight=B
}else{this.dragSource.tmpHeight=-1
}var D="";
if(C.ctrlKey){D+="&mode=insert"
}else{D+="&mode=update"
}D+="&entityid="+this.dragSource.schedule.scheduleId;
D+="&view_start="+ptConfig[this.portletId].jsonData.date[0].substring(0,10);
if(this.dragSource.schedule.repeat){D+="&edit_repeat_flag=1";
D+="&view_date="+ptConfig[this.portletId].jsonData.date[this.dragSource.tmpIndex].substring(0,10)
}D+="&start_date="+ptConfig[this.portletId].jsonData.date[this.dragSource.schedule.index].substring(0,11)+this.dragSource.schedule.startDateHour+"-"+this.dragSource.schedule.startDateMinute;
D+="&end_date="+ptConfig[this.portletId].jsonData.date[this.dragSource.schedule.index].substring(0,11)+this.dragSource.schedule.endDateHour+"-"+this.dragSource.schedule.endDateMinute;
aipo.calendar.populateWeeklySchedule(this.portletId,D);
aipo.portletReload("schedule",this.portletId);
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments);
this.dragSource.destroy()
}});
A.declare("aipo.calendar.WeeklyScheduleDraggable",[aimluck.dnd.Draggable],{DragMoveObject:aipo.calendar.WeeklyScheduleDragMoveObject,isDraggable:false,scheduleObjId:null,constructor:function(B,C){this.scheduleObjId=C.sid
},onMouseDown:function(B){ptConfig[this.portletId].isTooltipEnable=false;
if(!!aipo.calendar.dummyDivObj&&!!aipo.calendar.dummyDivObj.TooltipObject){aipo.calendar.dummyDivObj.TooltipObject.close()
}aimluck.dnd.Draggable.prototype.onMouseDown.apply(this,arguments)
},onScheduleClick:function(C){if(this.schedule.isDrag||!this.isDraggable){return 
}var B=this.schedule.ownerId;
aipo.common.showDialog(ptConfig[this.portletId].detailUrl+"&entityId="+this.schedule.scheduleId+"&view_date="+ptConfig[this.portletId].jsonData.date[this.schedule.index]+"&userid="+B,this.portletId,aipo.schedule.onLoadScheduleDetail);
aipo.schedule.tmpScroll=parseInt(A.byId("weeklyScrollPane_"+this.portletId)["scrollTop"])
},onScheduleOver:function(G){if(ptConfig[this.portletId].isTooltipEnable==false){return 
}var D=A.byId("dummy_div_"+this.portletId);
var F=A.getComputedStyle(this.node).left;
var E=A.getComputedStyle(this.node).top;
var C=A.getComputedStyle(this.node).width;
var B=A.getComputedStyle(this.node).height;
A.marginBox(D,A._getMarginBox(this.node,{l:F,t:E,w:C,h:B}));
D.style.zIndex=this.node.style.zIndex;
D.style.height=(parseInt(B)-6)+"px";
if(!aipo.calendar.dummyDivObj){aipo.calendar.dummyDivObj=new aipo.calendar.DummyDivObject(D,{pid:this.scheduleObjId,node:this.node})
}else{aipo.calendar.dummyDivObj.parentnode=this.node
}aipo.calendar.dummyDivObj.draggable=this;
if(aipo.calendar.dummyDivObj.TooltipObject){aipo.calendar.dummyDivObj.TooltipObject.destroyRecursive();
aipo.calendar.dummyDivObj.TooltipObject=null
}if(scheduleTooltipEnable){this.setupTooltip()
}},setupTooltip:function(){var B=this.schedule.scheduleId;
var C=ptConfig[this.portletId].jsonData.endDate;
aipo.calendar.dummyDivObj.TooltipObject=new aipo.widget.ToolTip({label:"<div class='indicator'>読み込み中...</div>",connectId:["dummy_div_"+this.portletId]},this.portletId,function(D,F){var E=ptConfig[this.portletId].jsonUrl.split("?")[0]+"?template=ScheduleDetailJSONScreen&view_date="+C+"&scheduleid="+B;
aipo.calendar.showTooltip(E,this.portletId,D)
})
},setDraggable:function(B){this.isDraggable=B
}});
A.declare("aipo.calendar.WeeklyTermScheduleDragMoveObject",[aimluck.dnd.DragMoveObject],{positionFrom:-1,positionTo:-1,moveIndex:0,onFirstMove:function(B){if(this.dragSource.TooltipObject!=null){this.dragSource.TooltipObject.uninitialize()
}aimluck.dnd.DragMoveObject.prototype.onFirstMove.apply(this,arguments);
A.style(this.node,"opacity",0.5);
aipo.calendar.setGridArray(this.portletId,parseInt(ptConfig[this.portletId].scheduleDivDaySum));
var D=A.clone(this.node);
D.id="schedule-dummy-"+this.portletId;
D.style.zIndex=998;
A.style(D,"opacity",0);
var C=A.byId(this.node.parentNode.id);
C.appendChild(D);
this.tmpDraggable=D;
if(A.isIE){document.onkeydown=function(E){A.style(D,"opacity",0.3)
};
document.onkeyup=function(E){A.style(D,"opacity",0)
}
}else{A.connect(null,"onkeydown",this,"onKeyPress");
A.connect(null,"onkeyup",this,"onKeyPress")
}},onKeyPress:function(B){if(B.ctrlKey){A.style(this.tmpDraggable,"opacity",0.3)
}else{A.style(this.tmpDraggable,"opacity",0)
}},onMouseMove:function(H){if(this.dragSource.isDraggable==false){return 
}aimluck.dnd.DragMoveObject.prototype.onMouseMove.apply(this,arguments);
this.dragSource.schedule.isDrag=true;
var B=ptConfig[this.portletId].distance;
var G=aipo.calendar.getCurrentMouseX(H);
_tmpIndex=G.index;
if(!this.disableX){var E=this.dragSource.schedule;
var I=this.dragSource.termType;
var K=this.dragSource.scheduleNode;
var J,D;
if(I=="center"){if(this.positionFrom==-1&&_tmpIndex!=-1){this.positionFrom=_tmpIndex;
this.positionTo=this.positionFrom
}if(this.positionTo!=-1&&_tmpIndex!=-1){this.positionTo=_tmpIndex
}this.moveIndex=-this.positionFrom+this.positionTo;
D=E.indexReal+this.moveIndex;
J=E.colspanReal;
var L=ptConfig[this.portletId].scheduleDivDaySum;
if(J+D>L){if(D<0){J=L
}else{J=L-D
}}else{if(D<0){J=J+D
}}if(D<0){D=0
}}else{if(I=="left"){if(this.positionFrom==-1){this.positionFrom=E.index;
this.positionTo=E.index
}if(this.positionTo!=-1&&_tmpIndex!=-1){this.positionTo=_tmpIndex
}this.moveIndex=-this.positionFrom+this.positionTo;
if(this.positionTo>=this.positionFrom+E.colspanReal){D=E.indexReal+E.rowspan-1;
J=this.positionTo-this.positionFrom-E.colspanReal+2
}else{D=this.positionTo;
J=E.rowspan+this.positionFrom-this.positionTo
}}else{if(this.positionFrom==-1){this.positionFrom=E.index;
this.positionTo=E.index
}if(this.positionTo!=-1&&_tmpIndex!=-1&&this._tmpIndex!=-1){this.positionTo=_tmpIndex
}this.moveIndex=-E.index-E.rowspan+this.positionTo+1;
if(this.positionTo<=this.positionFrom){D=this.positionTo;
J=this.positionFrom-this.positionTo+1
}else{D=E.index;
J=this.positionTo-E.index+1
}}}var C=100/ptConfig[this.portletId].scheduleDivDaySum*J;
var F=100/ptConfig[this.portletId].scheduleDivDaySum*D;
if(A.byId("top_form").value=="simple"){C=100*J;
F=100*D
}A.style(K,"left",F+"%");
A.style(K,"width",C+"%")
}},onMouseUp:function(F){ptConfig[this.portletId].isTooltipEnable=true;
if(A.isIE){document.onkeydown="";
document.onkeyup=""
}if(this.dragSource.schedule.isDrag!=true){A.style(this.node,"opacity",1);
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments);
return 
}var C=this.dragSource.schedule;
var I=ptConfig[this.portletId].jsonData.date[0].substring(0,10);
var D=this.dragSource.termType;
var H=this.dragSource.scheduleNode;
var B,E;
if(D=="center"){B=aipo.calendar.getDate(I,C.indexReal+this.moveIndex)+"-00-00";
E=aipo.calendar.getDate(I,C.indexReal+this.moveIndex+C.colspanReal-1)+"-00-00"
}else{if(D=="left"){if(C.colspanReal-this.moveIndex>0){B=aipo.calendar.getDate(I,C.indexReal+this.moveIndex)+"-00-00";
E=aipo.calendar.getDate(I,C.indexReal+C.colspanReal-1)+"-00-00"
}else{B=aipo.calendar.getDate(I,C.indexReal+C.colspanReal-1)+"-00-00";
E=aipo.calendar.getDate(I,C.indexReal+this.moveIndex)+"-00-00"
}}else{if(C.colspanReal+this.moveIndex>0){B=aipo.calendar.getDate(I,C.indexReal)+"-00-00";
E=aipo.calendar.getDate(I,C.indexReal+C.colspanReal+this.moveIndex-1)+"-00-00"
}else{B=aipo.calendar.getDate(I,C.indexReal+C.colspanReal+this.moveIndex-1)+"-00-00";
E=aipo.calendar.getDate(I,C.indexReal)+"-00-00"
}}}if(A.byId("top_form").value=="simple"){B=ptConfig[this.portletId].jsonData.date[0];
E=ptConfig[this.portletId].jsonData.date[0]
}this.positionFrom=-1;
this.positionTo=-1;
this.moveIndex=0;
this.tmpIndex=0;
var G="";
if(F.ctrlKey){G+="&mode=insert"
}else{G+="&mode=update"
}G+="&is_span=TRUE";
G+="&entityid="+this.dragSource.schedule.scheduleId;
G+="&view_start="+I;
G+="&start_date="+B;
G+="&end_date="+E;
aipo.calendar.populateWeeklySchedule(this.portletId,G);
aipo.portletReload("schedule",this.portletId);
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments)
}});
A.declare("aipo.calendar.WeeklyTermScheduleDraggable",[aimluck.dnd.Draggable],{DragMoveObject:aipo.calendar.WeeklyTermScheduleDragMoveObject,isDraggable:false,TooltipObject:null,scheduleObjId:null,isDraggable:false,constructor:function(B,C){this.scheduleObjId=C.sid
},onMouseDown:function(B){ptConfig[this.portletId].isTooltipEnable=false;
if(this.TooltipObject){this.TooltipObject.close()
}aimluck.dnd.Draggable.prototype.onMouseDown.apply(this,arguments)
},onScheduleClick:function(C){if(this.schedule.isDrag||!this.isDraggable){return 
}var B=this.schedule.ownerId;
aipo.common.showDialog(ptConfig[this.portletId].detailUrl+"&entityId="+this.schedule.scheduleId+"&view_date="+ptConfig[this.portletId].jsonData.date[this.schedule.index]+"&userid="+B,this.portletId,aipo.schedule.onLoadScheduleDetail);
aipo.schedule.tmpScroll=parseInt(A.byId("weeklyScrollPane_"+this.portletId)["scrollTop"])
},onScheduleOver:function(B){if(ptConfig[this.portletId].isTooltipEnable==false){return 
}if(scheduleTooltipEnable){this.setupTooltip()
}},setupTooltip:function(){var B=this.schedule.scheduleId;
var C=ptConfig[this.portletId].jsonData.endDate;
if(!this.TooltipObject){this.TooltipObject=new aipo.widget.ToolTip({label:"<div class='indicator'>読み込み中...</div>",connectId:[this.node.id]},this.portletId,function(D,F){var E=ptConfig[this.portletId].jsonUrl.split("?")[0]+"?template=ScheduleDetailJSONScreen&view_date="+C+"&scheduleid="+B;
aipo.calendar.showTooltip(E,this.portletId,D)
})
}aipo.calendar.objectlist.push(this.TooltipObject)
},setDraggable:function(B){this.isDraggable=B
}});
A.declare("aipo.calendar.WeeklyScheduleAddDragMoveObject",[aimluck.dnd.DragMoveObject],{_rowHeight_:18,positionFrom:0,positionTo:0,_isDragging:false,lastScroll:0,onMouseDown:function(B){this._isDragging=false;
aimluck.dnd.DragMoveObject.prototype.onMouseDown.apply(this,arguments)
},onFirstMove:function(C){this.startY=this.dragSource._lastY;
this.startAbsoluteY=A._abs(A.byId(this.node),true).y;
this.startX=A.getComputedStyle(this.node).left;
var B=window.navigator.userAgent.toLowerCase();
if(B.indexOf("chrome")>-1||(A.isFF&&(A.isFF>=3.6))){this.startAbsoluteY+=window.scrollY
}else{if(B.indexOf("safari")>-1){this.startAbsoluteY-=A.byId("weeklyScrollPane_"+this.portletId).scrollTop
}}lastScroll=A.byId("weeklyScrollPane_"+this.portletId).scrollTop;
aimluck.dnd.DragMoveObject.prototype.onFirstMove.apply(this,arguments)
},onMouseMove:function(G){aimluck.dnd.DragMoveObject.prototype.onMouseMove.apply(this,arguments);
this._isDragging=true;
var F=A.byId("weeklyScrollPane_"+this.portletId).scrollTop-lastScroll;
var E=Math.floor((this.startY-this.startAbsoluteY)/this._rowHeight_);
var B=Math.floor((this.startY+this.leftTop.t-this.startAbsoluteY+F)/this._rowHeight_);
var C=0;
var D=0;
if(B<E){C=B*this._rowHeight_+1;
D=(E-B+1)*this._rowHeight_;
this.positionFrom=B;
this.positionTo=E+1
}else{C=E*this._rowHeight_+1;
D=(B-E+1)*this._rowHeight_;
this.positionTo=B+1;
this.positionFrom=E
}if(C+D>864){D=864-C-this._rowHeight_;
this.positionTo=47
}this.leftTop.t=C;
this.leftTop.l=this.startX;
this.leftTop.h=D;
A.marginBox(this.node,this.leftTop);
A.style(this.node,"opacity",0.5)
},onMouseUp:function(F){if(!this._isDragging){this.onFirstMove(F);
this.onMouseMove(F)
}var B=Math.floor(this.positionFrom/2);
B=(B>9)?B:"0"+B;
var G=Math.floor(this.positionFrom%2)*30;
var D=ptConfig[this.portletId].jsonData.date[this.dragSource.index].substring(0,10);
var E=D+"-"+B+"-"+G;
B=Math.floor(this.positionTo/2);
B=(B>9)?B:"0"+B;
G=Math.floor(this.positionTo%2)*30;
var C=D+"-"+B+"-"+G;
this.node.style.top="0px";
this.node.style.height="864px";
A.style(this.node,"opacity",0);
if(this._isDragging==true){aipo.common.showDialog(ptConfig[this.portletId].formUrl+"&entityid=new&mode=form&form_start="+E+"&form_end="+C,this.portletId,aipo.schedule.onLoadScheduleDialog)
}aipo.schedule.tmpScroll=parseInt(A.byId("weeklyScrollPane_"+this.portletId)["scrollTop"]);
this._isDragging=false;
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments)
}});
A.declare("aipo.calendar.WeeklyScheduleAddDraggable",[aimluck.dnd.Draggable],{DragMoveObject:aipo.calendar.WeeklyScheduleAddDragMoveObject,constructor:function(B,C){this.index=C.idx
}});
A.declare("aipo.calendar.WeeklyTermScheduleAddDragMoveObject",[aimluck.dnd.DragMoveObject],{_rowHeight_:18,positionFrom:-1,positionTo:-1,_isDragging:false,scheduleObjId:null,onMouseDown:function(B){this._isDragging=false;
aimluck.dnd.DragMoveObject.prototype.onMouseDown.apply(this,arguments)
},onFirstMove:function(B){aimluck.dnd.DragMoveObject.prototype.onFirstMove.apply(this,arguments);
aipo.calendar.setGridArray(this.portletId,parseInt(ptConfig[this.portletId].scheduleDivDaySum))
},onMouseMove:function(G){aimluck.dnd.DragMoveObject.prototype.onMouseMove.apply(this,arguments);
this._isDragging=true;
A.style(this.node,"opacity",0.5);
var D=aipo.calendar.getCurrentMouseX(G);
var H=D.index;
if(this.positionFrom==-1&&H!=-1){this.positionFrom=H;
this.positionTo=this.positionFrom
}if(this.positionTo!=-1&&H!=-1){this.positionTo=H
}if(this.positionTo!=-1&&this.positionFrom!=-1){var C,B;
if(this.positionTo>this.positionFrom){B=this.positionFrom;
C=this.positionTo-this.positionFrom+1
}else{B=this.positionTo;
C=this.positionFrom-this.positionTo+1
}var E=100/ptConfig[this.portletId].scheduleDivDaySum*C;
var F=100/ptConfig[this.portletId].scheduleDivDaySum*B;
if(A.byId("top_form").value=="simple"){E=0;
F=0
}A.style(this.node,"left",F+"%");
A.style(this.node,"width",E+"%")
}else{A.style(this.node,"left",0+"%");
A.style(this.node,"width",0+"%")
}},onMouseUp:function(E){if(!this._isDragging){this.onFirstMove(E);
this.onMouseMove(E)
}var F,D;
if(this.positionTo!=-1&&this.positionFrom!=-1){if(this.positionTo>this.positionFrom){F=this.positionFrom;
D=this.positionTo
}else{D=this.positionFrom;
F=this.positionTo
}if(A.byId("top_form").value=="simple"){F=0;
D=0
}var C=ptConfig[this.portletId].jsonData.date[F];
var B=ptConfig[this.portletId].jsonData.date[D];
if(this._isDragging==true){aipo.common.showDialog(ptConfig[this.portletId].formUrl+"&entityid=new&mode=form&is_span=TRUE&form_start="+C+"&form_end="+B,this.portletId,aipo.schedule.onLoadScheduleDialog)
}aipo.schedule.tmpScroll=parseInt(A.byId("weeklyScrollPane_"+this.portletId)["scrollTop"])
}this.positionFrom=-1;
this.positionTo=-1;
A.style(this.node,"left",0+"%");
A.style(this.node,"width",100+"%");
A.style(this.node,"opacity",0);
aimluck.dnd.DragMoveObject.prototype.onMouseUp.apply(this,arguments)
}});
A.declare("aipo.calendar.WeeklyTermScheduleAddDraggable",[aimluck.dnd.Draggable],{DragMoveObject:aipo.calendar.WeeklyTermScheduleAddDragMoveObject,constructor:function(B,C){this.index=C.idx
}})
}}});