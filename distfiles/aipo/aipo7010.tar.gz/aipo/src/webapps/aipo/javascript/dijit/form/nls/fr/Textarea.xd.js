dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.fr.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.fr.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "fr", {"iframeTitle1": "zone d'édition", "iframeTitle2": "cadre de la zone d'édition"});
}});