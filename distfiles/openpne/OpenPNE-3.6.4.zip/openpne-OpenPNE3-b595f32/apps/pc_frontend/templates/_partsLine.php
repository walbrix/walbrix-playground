<?php $options->setDefault('single', true) ?>
<?php echo $options->getRaw('line') ?>
