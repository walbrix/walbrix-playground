module PostVotesHelper
end
