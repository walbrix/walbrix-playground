<?php	
defined('C5_EXECUTE') or die("Access Denied.");
class LogEntry extends Concrete5_Library_LogEntry {}
class Log extends Concrete5_Library_Log {}