/* JavaScript for Special:MovePage */

jQuery( function( $ ) {
	$( '#wpReason, #wpNewTitleMain' ).byteLimit();
});
