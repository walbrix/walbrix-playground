/**
 * Portugese language functions
 */

mediaWiki.language.digitTransformTable = {
    '.' : ',',
    ',' : ' '
};
