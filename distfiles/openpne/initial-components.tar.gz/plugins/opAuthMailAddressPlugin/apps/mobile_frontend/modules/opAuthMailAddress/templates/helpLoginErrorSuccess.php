<?php op_mobile_page_title(__('Do you forget your password?')) ?>
<?php echo __('Please click the following button to start the password recovery process.'); ?><br>
<center>
<?php echo link_to(__('Go to Password Recovery Page'), 'opAuthMailAddress/passwordRecovery') ?>
</center>
