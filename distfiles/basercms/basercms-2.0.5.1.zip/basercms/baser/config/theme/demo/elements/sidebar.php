<?php
/**
 * サイドバー
 */
?>


<div id="beta">
	<?php $bcBaser->widgetArea() ?>
</div>
