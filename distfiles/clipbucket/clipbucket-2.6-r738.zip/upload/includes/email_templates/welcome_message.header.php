
					<?php 
					$subj ="Welcome $username to $title" 
					?>
					