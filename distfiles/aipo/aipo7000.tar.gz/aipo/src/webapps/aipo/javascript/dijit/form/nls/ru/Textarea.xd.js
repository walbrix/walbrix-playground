dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.ru.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.ru.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "ru", {"iframeTitle1": "область редактирования", "iframeTitle2": "фрейм области редактирования"});
}});