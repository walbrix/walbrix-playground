dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.zh-tw.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.zh-tw.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "zh-tw", {"loadingState": "載入中...", "errorState": "抱歉，發生錯誤"});
}});