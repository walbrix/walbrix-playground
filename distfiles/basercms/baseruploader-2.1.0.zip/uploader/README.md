baserUploader
==========
File Uploader On baserCMS
Copyright 2008 - 2012, baserCMS Users Community  

Documentation
-------------

- See [baserCMS Official](http://basercms.net/)
- See [baserCMS Users Community](http://sites.google.com/site/baserusers/)
- See [baserCMS Users Forum](http://forum.basercms.net/)
- See [baserCMS Uploader Development Project](http://project.e-catchup.jp/projects/baseruploader) 
- See [CakePHP - the rapid development PHP framework](http://cakephp.jp)

License
-------

Lincensed under the MIT lincense since version 2.0