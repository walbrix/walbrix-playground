FactoryGirl.define do
  factory(:comment_vote) do
    score 1
  end
end