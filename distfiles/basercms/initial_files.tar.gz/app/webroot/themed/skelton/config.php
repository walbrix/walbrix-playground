<?php
$title = 'スケルトン';
$description = '必要なコーディングだけを行ったスケルトンテーマです。一からテーマを制作する場合に便利です。';
$author = 'basercms';
$url = 'http://basercms.net';