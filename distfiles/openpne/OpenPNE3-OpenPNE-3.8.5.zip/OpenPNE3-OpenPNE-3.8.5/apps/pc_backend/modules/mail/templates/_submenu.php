<li><?php echo link_to(__('Configuration of E-mail Notifications'), '@mail_config') ?></li>
<li><?php echo link_to(__('Edit Templates of E-mail Notification'), '@mail_template') ?></li>
