dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.hu.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.hu.common");dojo._xdLoadFlattenedBundle("dijit", "common", "hu", {"buttonCancel": "Mégse", "buttonSave": "Mentés", "buttonOk": "OK"});
}});