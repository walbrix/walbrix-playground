FactoryGirl.define do
  factory(:post_appeal) do
    reason "xxx"
  end
end
