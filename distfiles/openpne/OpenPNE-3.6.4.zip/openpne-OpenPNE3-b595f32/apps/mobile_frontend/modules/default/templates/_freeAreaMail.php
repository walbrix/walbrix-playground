<?php if ($gadget->getConfig('title')): ?>
―――――――――――――――――――――――――――――
◆<?php echo $gadget->getConfig('title') ?>◆
<?php endif; ?>
―――――――――――――――――――――――――――――

<?php echo $gadget->getConfig('value') ?>

