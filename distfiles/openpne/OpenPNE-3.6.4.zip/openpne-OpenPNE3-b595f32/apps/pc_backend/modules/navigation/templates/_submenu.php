<li><?php echo link_to(__('PC frontend'), 'navigation/list') ?></li>
<li><?php echo link_to(__('Mobile frontend'), 'navigation/list?app=mobile') ?></li>
<li><?php echo link_to(__('Administration'), 'navigation/list?app=backend') ?></li>
