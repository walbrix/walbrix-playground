<table width="100%">
<tr><td align="center" bgcolor="<?php echo $op_color["core_color_2"] ?>">
<font color="<?php echo $op_color["core_color_18"] ?>"><a name="top"><?php echo $title ?></a></font><br>
</td></tr>
<?php if (isset($subtitle) && $subtitle !== ''): ?>
<tr><td align="center" bgcolor="<?php echo $op_color["core_color_3"] ?>">
<font color="<?php echo $op_color["core_color_24"] ?>"><a name="top"><?php echo $subtitle ?></a></font><br>
</td></tr>
<?php endif; ?>
</table>
