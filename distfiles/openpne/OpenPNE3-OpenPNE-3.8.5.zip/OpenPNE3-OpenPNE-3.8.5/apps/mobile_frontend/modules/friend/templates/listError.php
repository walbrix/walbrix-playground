<?php op_mobile_page_title(__('%Friend% list')) ?>
<?php echo __('%Friend% does not exist.') ?>
