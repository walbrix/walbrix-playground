dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.it.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.it.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "it", {"loadingState": "Caricamento in corso...", "errorState": "Si è verificato un errore"});
}});