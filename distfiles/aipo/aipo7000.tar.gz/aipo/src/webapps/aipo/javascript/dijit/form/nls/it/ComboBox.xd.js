dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.it.ComboBox"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.it.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "it", {"previousMessage": "Scelte precedenti", "nextMessage": "Altre scelte"});
}});