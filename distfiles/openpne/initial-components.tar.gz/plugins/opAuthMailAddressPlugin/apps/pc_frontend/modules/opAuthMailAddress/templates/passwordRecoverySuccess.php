<?php echo op_include_form('passwordRecovery', $form, array('title' => __('Password Recovery'))) ?>
