dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.pt.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.pt.common");dojo._xdLoadFlattenedBundle("dijit", "common", "pt", {"buttonCancel": "Cancelar ", "buttonSave": "Salvar", "buttonOk": "OK"});
}});