dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.common");dojo._xdLoadFlattenedBundle("dijit", "common", "", {"buttonCancel": "Cancel", "buttonSave": "Save", "buttonOk": "OK"});
}});