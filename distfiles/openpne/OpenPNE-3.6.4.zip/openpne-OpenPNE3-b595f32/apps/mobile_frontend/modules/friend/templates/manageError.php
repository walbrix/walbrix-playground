<?php op_mobile_page_title(__('Manage %friend%')) ?>
<?php echo __('%Friend% does not exist.') ?>
