<?php op_mobile_page_title(__('Error')) ?>
<?php echo __('CSRF attack detected.'); ?>
