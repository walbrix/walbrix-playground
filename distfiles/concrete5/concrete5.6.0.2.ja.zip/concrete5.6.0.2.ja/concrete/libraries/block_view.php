<?php	
defined('C5_EXECUTE') or die("Access Denied.");
class BlockView extends Concrete5_Library_BlockView {}