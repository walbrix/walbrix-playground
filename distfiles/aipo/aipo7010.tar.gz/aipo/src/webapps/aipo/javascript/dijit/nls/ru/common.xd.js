dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.ru.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.ru.common");dojo._xdLoadFlattenedBundle("dijit", "common", "ru", {"buttonCancel": "Отмена", "buttonSave": "Сохранить", "buttonOk": "ОК"});
}});