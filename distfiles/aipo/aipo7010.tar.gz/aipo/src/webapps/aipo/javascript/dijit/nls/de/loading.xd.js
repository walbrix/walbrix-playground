dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.de.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.de.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "de", {"loadingState": "Wird geladen...", "errorState": "Es ist ein Fehler aufgetreten."});
}});