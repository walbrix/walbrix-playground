<?php
	require_once "mobile-functions.php";

	logout_user();

	header("Location: index.php");
?>
