dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.ko.common"]],
defineResource: function(dojo){dojo.provide("dijit.nls.ko.common");dojo._xdLoadFlattenedBundle("dijit", "common", "ko", {"buttonCancel": "취소", "buttonSave": "저장", "buttonOk": "확인"});
}});