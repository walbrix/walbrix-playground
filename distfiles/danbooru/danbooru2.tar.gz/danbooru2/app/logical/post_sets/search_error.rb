module PostSets
  class SearchError < Exception
  end
end