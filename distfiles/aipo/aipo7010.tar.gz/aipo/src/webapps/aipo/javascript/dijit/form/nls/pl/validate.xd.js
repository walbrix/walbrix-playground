dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.pl.validate"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.pl.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "pl", {"rangeMessage": "* Ta wartość jest spoza zakresu.", "invalidMessage": "* Wprowadzona wartość nie jest poprawna.", "missingMessage": "* Ta wartość jest wymagana."});
}});