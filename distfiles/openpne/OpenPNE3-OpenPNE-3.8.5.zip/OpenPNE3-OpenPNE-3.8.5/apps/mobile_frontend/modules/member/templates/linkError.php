<?php op_mobile_page_title(__('Error')) ?>
<?php echo __('This member is already %my_friend%.'); ?>

