<?php op_mobile_page_title($member->getName()) ?>
<?php echo __('%Community% does not exist.') ?>
