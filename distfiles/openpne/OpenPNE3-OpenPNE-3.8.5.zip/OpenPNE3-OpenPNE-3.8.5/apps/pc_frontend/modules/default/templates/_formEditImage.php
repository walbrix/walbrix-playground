<a href="<?php echo sf_image_path($image->getFile()) ?>" target="_blank"><?php echo op_image_tag_sf_image($image->getFile(), array('size' => '120x120')) ?></a><br />
%input%<br />
%delete% %delete_label%
