dojo.provide("aipo.cellular");
aipo.cellular.displayIndicator=function(A,B){var C=dojo.byId(A+B);
if(C){dojo.style(C,"display","")
}};