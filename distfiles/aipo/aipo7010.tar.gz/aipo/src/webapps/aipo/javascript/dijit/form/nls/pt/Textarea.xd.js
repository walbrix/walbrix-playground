dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.pt.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.pt.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "pt", {"iframeTitle1": "área de edição", "iframeTitle2": "quadro da área de edição"});
}});