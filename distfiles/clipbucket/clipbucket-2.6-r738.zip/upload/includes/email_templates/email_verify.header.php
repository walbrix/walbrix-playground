
					<?php 
					$subj ="$uname's Account Activation" 
					?>
					