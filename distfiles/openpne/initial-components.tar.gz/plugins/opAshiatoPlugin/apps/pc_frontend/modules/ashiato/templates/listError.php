<?php include_box('noAshiato', __('Pageview logs'), __('no other Pageview logs')) ?>

<?php use_helper('Javascript') ?>
<?php op_include_line('backLink', link_to_function(__('Back to previous page'), 'history.back()')) ?>
