dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.zh-tw.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.zh-tw.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "zh-tw", {"iframeTitle1": "編輯區", "iframeTitle2": "編輯區框"});
}});