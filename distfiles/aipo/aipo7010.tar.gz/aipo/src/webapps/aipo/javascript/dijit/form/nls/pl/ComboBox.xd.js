dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.pl.ComboBox"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.pl.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "pl", {"previousMessage": "Poprzednie wybory", "nextMessage": "Więcej wyborów"});
}});