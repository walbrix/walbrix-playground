<?php op_mobile_page_title(__('Pageview logs')) ?>
<?php echo __('no other Pageview logs') ?>
