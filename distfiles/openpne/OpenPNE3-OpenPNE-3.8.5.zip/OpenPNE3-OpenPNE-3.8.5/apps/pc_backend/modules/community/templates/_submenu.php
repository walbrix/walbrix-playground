<li><?php echo link_to(__('%Community% List'), 'community/list') ?></li>
<li><?php echo link_to(__('%Community% Category Configuration'), 'community/categoryList') ?></li>
<li><?php echo link_to(__('Default %community% Configuration'), 'community/defaultCommunityList') ?></li>
