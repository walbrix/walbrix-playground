.. highlightlang:: none

Community
=========

There are some places for sharing groonga and mroonga information. We welcome you to join our community.

Mailing List
------------

There are mailing lists for discussion about groonga and mroonga.

For English speaker
  `groonga-talk@lists.sourceforge.net <http://lists.sourceforge.net/mailman/listinfo/groonga-talk>`_

For Japanese speaker
  `groonga-dev@lists.sourceforge.jp <http://lists.sourceforge.jp/mailman/listinfo/groonga-dev>`_
