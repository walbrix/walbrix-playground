dojo._xdResourceLoaded({
depends: [["provide", "dijit.nls.loading"]],
defineResource: function(dojo){dojo.provide("dijit.nls.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "", {"loadingState": "Loading...", "errorState": "Sorry, an error occurred"});
}});