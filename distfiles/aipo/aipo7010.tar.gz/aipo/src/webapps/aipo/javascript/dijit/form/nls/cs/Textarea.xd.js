dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.cs.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.cs.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "cs", {"iframeTitle1": "oblast úprav", "iframeTitle2": "rámec oblasti úprav"});
}});