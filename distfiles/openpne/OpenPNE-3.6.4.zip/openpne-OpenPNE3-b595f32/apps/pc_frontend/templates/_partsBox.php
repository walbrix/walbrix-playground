<div class="body">
<?php include_customizes($id, 'bodyTop') ?>
<?php echo $options->getRaw('body') ?>
<?php include_customizes($id, 'bodyBottom') ?>
</div>
