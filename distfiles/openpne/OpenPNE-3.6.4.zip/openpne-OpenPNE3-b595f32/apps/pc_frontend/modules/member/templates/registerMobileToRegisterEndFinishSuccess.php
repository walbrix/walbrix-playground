<?php op_include_box('finish', __('When mobile information registration is done, the member registration is completed.').'<br />'.__('Sent a mail for your mobile e-mail address. Begin your registration from a URL in the mail.'), array('title' => __('Mobile E-mail Address Registration Completed'))); ?>

