dojo._xdResourceLoaded({
depends: [["provide", "dijit.form.nls.zh.Textarea"]],
defineResource: function(dojo){dojo.provide("dijit.form.nls.zh.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "zh", {"iframeTitle1": "编辑区", "iframeTitle2": "编辑区框架"});
}});